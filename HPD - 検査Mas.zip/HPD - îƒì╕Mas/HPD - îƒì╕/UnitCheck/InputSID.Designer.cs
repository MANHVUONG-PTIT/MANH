﻿namespace Simulator
{
    partial class InputSID
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StartBtn = new System.Windows.Forms.Button();
            this.SerialNoLabel = new System.Windows.Forms.Label();
            this.LotLabel = new System.Windows.Forms.Label();
            this.LotText = new System.Windows.Forms.TextBox();
            this.SerialNoText = new System.Windows.Forms.TextBox();
            this.UpBtn = new System.Windows.Forms.Button();
            this.DownBtn = new System.Windows.Forms.Button();
            this.PatternLabel = new System.Windows.Forms.Label();
            this.PatternBox = new System.Windows.Forms.ComboBox();
            this.LanguageBox = new System.Windows.Forms.ComboBox();
            this.LanguageLabel = new System.Windows.Forms.Label();
            this.UnitLabel = new System.Windows.Forms.Label();
            this.UnitBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // StartBtn
            // 
            this.StartBtn.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.StartBtn.Location = new System.Drawing.Point(337, 81);
            this.StartBtn.Margin = new System.Windows.Forms.Padding(4);
            this.StartBtn.Name = "StartBtn";
            this.StartBtn.Size = new System.Drawing.Size(154, 75);
            this.StartBtn.TabIndex = 4;
            this.StartBtn.Text = "Start [F1]";
            this.StartBtn.UseVisualStyleBackColor = true;
            this.StartBtn.Click += new System.EventHandler(this.StartBtn_Click);
            // 
            // SerialNoLabel
            // 
            this.SerialNoLabel.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.SerialNoLabel.Location = new System.Drawing.Point(12, 96);
            this.SerialNoLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.SerialNoLabel.Name = "SerialNoLabel";
            this.SerialNoLabel.Size = new System.Drawing.Size(80, 20);
            this.SerialNoLabel.TabIndex = 6;
            this.SerialNoLabel.Text = "SerialNo";
            this.SerialNoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LotLabel
            // 
            this.LotLabel.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.LotLabel.Location = new System.Drawing.Point(12, 16);
            this.LotLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LotLabel.Name = "LotLabel";
            this.LotLabel.Size = new System.Drawing.Size(80, 20);
            this.LotLabel.TabIndex = 5;
            this.LotLabel.Text = "Lot";
            this.LotLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LotText
            // 
            this.LotText.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.LotText.Location = new System.Drawing.Point(103, 12);
            this.LotText.Margin = new System.Windows.Forms.Padding(4);
            this.LotText.Name = "LotText";
            this.LotText.Size = new System.Drawing.Size(119, 23);
            this.LotText.TabIndex = 0;
            // 
            // SerialNoText
            // 
            this.SerialNoText.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.SerialNoText.Location = new System.Drawing.Point(103, 93);
            this.SerialNoText.Margin = new System.Windows.Forms.Padding(4);
            this.SerialNoText.Name = "SerialNoText";
            this.SerialNoText.Size = new System.Drawing.Size(119, 23);
            this.SerialNoText.TabIndex = 1;
            // 
            // UpBtn
            // 
            this.UpBtn.Font = new System.Drawing.Font("ＭＳ ゴシック", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.UpBtn.Location = new System.Drawing.Point(230, 81);
            this.UpBtn.Margin = new System.Windows.Forms.Padding(4);
            this.UpBtn.Name = "UpBtn";
            this.UpBtn.Size = new System.Drawing.Size(86, 23);
            this.UpBtn.TabIndex = 2;
            this.UpBtn.Text = "UP [F5]";
            this.UpBtn.UseVisualStyleBackColor = true;
            this.UpBtn.Click += new System.EventHandler(this.UpBtn_Click);
            // 
            // DownBtn
            // 
            this.DownBtn.Font = new System.Drawing.Font("ＭＳ ゴシック", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.DownBtn.Location = new System.Drawing.Point(230, 104);
            this.DownBtn.Margin = new System.Windows.Forms.Padding(4);
            this.DownBtn.Name = "DownBtn";
            this.DownBtn.Size = new System.Drawing.Size(86, 23);
            this.DownBtn.TabIndex = 3;
            this.DownBtn.Text = "DWN[F6]";
            this.DownBtn.UseVisualStyleBackColor = true;
            this.DownBtn.Click += new System.EventHandler(this.DownBtn_Click);
            // 
            // PatternLabel
            // 
            this.PatternLabel.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.PatternLabel.Location = new System.Drawing.Point(12, 136);
            this.PatternLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.PatternLabel.Name = "PatternLabel";
            this.PatternLabel.Size = new System.Drawing.Size(80, 20);
            this.PatternLabel.TabIndex = 7;
            this.PatternLabel.Text = "Pattern";
            this.PatternLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // PatternBox
            // 
            this.PatternBox.FormattingEnabled = true;
            this.PatternBox.Location = new System.Drawing.Point(103, 136);
            this.PatternBox.Name = "PatternBox";
            this.PatternBox.Size = new System.Drawing.Size(213, 24);
            this.PatternBox.TabIndex = 8;
            // 
            // LanguageBox
            // 
            this.LanguageBox.FormattingEnabled = true;
            this.LanguageBox.Location = new System.Drawing.Point(423, 14);
            this.LanguageBox.Name = "LanguageBox";
            this.LanguageBox.Size = new System.Drawing.Size(68, 24);
            this.LanguageBox.TabIndex = 10;
            this.LanguageBox.TextChanged += new System.EventHandler(this.LanguageBox_TextChanged);
            // 
            // LanguageLabel
            // 
            this.LanguageLabel.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.LanguageLabel.Location = new System.Drawing.Point(334, 15);
            this.LanguageLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.LanguageLabel.Name = "LanguageLabel";
            this.LanguageLabel.Size = new System.Drawing.Size(80, 20);
            this.LanguageLabel.TabIndex = 9;
            this.LanguageLabel.Text = "Language";
            this.LanguageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // UnitLabel
            // 
            this.UnitLabel.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.UnitLabel.Location = new System.Drawing.Point(12, 56);
            this.UnitLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.UnitLabel.Name = "UnitLabel";
            this.UnitLabel.Size = new System.Drawing.Size(80, 20);
            this.UnitLabel.TabIndex = 11;
            this.UnitLabel.Text = "Inspect";
            this.UnitLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // UnitBox
            // 
            this.UnitBox.FormattingEnabled = true;
            this.UnitBox.Location = new System.Drawing.Point(103, 52);
            this.UnitBox.Name = "UnitBox";
            this.UnitBox.Size = new System.Drawing.Size(119, 24);
            this.UnitBox.TabIndex = 13;
            // 
            // InputSID
            // 
            this.AcceptButton = this.StartBtn;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.LightYellow;
            this.ClientSize = new System.Drawing.Size(504, 169);
            this.Controls.Add(this.UnitBox);
            this.Controls.Add(this.UnitLabel);
            this.Controls.Add(this.LanguageBox);
            this.Controls.Add(this.LanguageLabel);
            this.Controls.Add(this.PatternBox);
            this.Controls.Add(this.PatternLabel);
            this.Controls.Add(this.DownBtn);
            this.Controls.Add(this.UpBtn);
            this.Controls.Add(this.SerialNoText);
            this.Controls.Add(this.LotText);
            this.Controls.Add(this.StartBtn);
            this.Controls.Add(this.SerialNoLabel);
            this.Controls.Add(this.LotLabel);
            this.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "InputSID";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProductName  CheckerName";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.InputSID_FormClosing);
            this.Load += new System.EventHandler(this.InputSID_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.InputSID_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button StartBtn;
        private System.Windows.Forms.Label SerialNoLabel;
        private System.Windows.Forms.Label LotLabel;
        private System.Windows.Forms.TextBox LotText;
        private System.Windows.Forms.TextBox SerialNoText;
        private System.Windows.Forms.Button UpBtn;
        private System.Windows.Forms.Button DownBtn;
        private System.Windows.Forms.Label PatternLabel;
        private System.Windows.Forms.ComboBox PatternBox;
        private System.Windows.Forms.ComboBox LanguageBox;
        private System.Windows.Forms.Label LanguageLabel;
        private System.Windows.Forms.Label UnitLabel;
        private System.Windows.Forms.ComboBox UnitBox;
    }
}