﻿namespace Simulator
{
    partial class MainForm
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.LotLabel = new System.Windows.Forms.Label();
            this.SerialNoLabel = new System.Windows.Forms.Label();
            this.LotText = new System.Windows.Forms.Label();
            this.SerialNoText = new System.Windows.Forms.Label();
            this.StartBtn = new System.Windows.Forms.Button();
            this.ResultLabel = new System.Windows.Forms.Label();
            this.ResultText = new System.Windows.Forms.Label();
            this.DebugCheckBox = new System.Windows.Forms.CheckBox();
            this.TaskGrid = new System.Windows.Forms.DataGridView();
            this.StopBtn = new System.Windows.Forms.Button();
            this.ResetBtn = new System.Windows.Forms.Button();
            this.EndBtn = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.PatternNameLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.InfomationLabel = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.panel3 = new System.Windows.Forms.Panel();
            this.KinsyuInfoGrid = new System.Windows.Forms.DataGridView();
            this.InfomationTextBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Info2_1_1 = new System.Windows.Forms.Label();
            this.Info2_2_4 = new System.Windows.Forms.Label();
            this.Info2_2_5 = new System.Windows.Forms.Label();
            this.Info2_2_3 = new System.Windows.Forms.Label();
            this.Info2_3_8 = new System.Windows.Forms.Label();
            this.Info2_2_6 = new System.Windows.Forms.Label();
            this.Info2_3_7 = new System.Windows.Forms.Label();
            this.Info2_2_2 = new System.Windows.Forms.Label();
            this.Info2_2_1 = new System.Windows.Forms.Label();
            this.Info2_2_8 = new System.Windows.Forms.Label();
            this.Info2_1_6 = new System.Windows.Forms.Label();
            this.Info2_3_6 = new System.Windows.Forms.Label();
            this.Info2_1_5 = new System.Windows.Forms.Label();
            this.Info2_2_7 = new System.Windows.Forms.Label();
            this.Info2_3_1 = new System.Windows.Forms.Label();
            this.Info2_1_8 = new System.Windows.Forms.Label();
            this.Info2_1_4 = new System.Windows.Forms.Label();
            this.Info2_3_5 = new System.Windows.Forms.Label();
            this.Info2_3_2 = new System.Windows.Forms.Label();
            this.Info2_1_7 = new System.Windows.Forms.Label();
            this.Info2_1_3 = new System.Windows.Forms.Label();
            this.Info2_3_3 = new System.Windows.Forms.Label();
            this.Info2_3_4 = new System.Windows.Forms.Label();
            this.Info2_1_2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Info1_1 = new System.Windows.Forms.Label();
            this.Info1_3 = new System.Windows.Forms.Label();
            this.Info1_2 = new System.Windows.Forms.Label();
            this.DebugGroupBox = new System.Windows.Forms.GroupBox();
            this.EndCountClearButton = new System.Windows.Forms.Button();
            this.CommDebugFormShowButton = new System.Windows.Forms.Button();
            this.ForceStopButton = new System.Windows.Forms.Button();
            this.DownloadButton = new System.Windows.Forms.Button();
            this.LogReadButton = new System.Windows.Forms.Button();
            this.SingleButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.StepButton = new System.Windows.Forms.Button();
            this.InitialSettingGroupBox = new System.Windows.Forms.GroupBox();
            this.InitSettingButton = new System.Windows.Forms.Button();
            this.PatternSettingGroupBox = new System.Windows.Forms.GroupBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.PatternSettingButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.TaskGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KinsyuInfoGrid)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.DebugGroupBox.SuspendLayout();
            this.InitialSettingGroupBox.SuspendLayout();
            this.PatternSettingGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // LotLabel
            // 
            this.LotLabel.Location = new System.Drawing.Point(8, 12);
            this.LotLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LotLabel.Name = "LotLabel";
            this.LotLabel.Size = new System.Drawing.Size(80, 22);
            this.LotLabel.TabIndex = 0;
            this.LotLabel.Text = "Lot";
            this.LotLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // SerialNoLabel
            // 
            this.SerialNoLabel.Location = new System.Drawing.Point(8, 41);
            this.SerialNoLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SerialNoLabel.Name = "SerialNoLabel";
            this.SerialNoLabel.Size = new System.Drawing.Size(80, 21);
            this.SerialNoLabel.TabIndex = 1;
            this.SerialNoLabel.Text = "SerialNo";
            this.SerialNoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // LotText
            // 
            this.LotText.BackColor = System.Drawing.Color.White;
            this.LotText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LotText.Location = new System.Drawing.Point(91, 8);
            this.LotText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LotText.Name = "LotText";
            this.LotText.Size = new System.Drawing.Size(90, 26);
            this.LotText.TabIndex = 2;
            this.LotText.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // SerialNoText
            // 
            this.SerialNoText.BackColor = System.Drawing.Color.White;
            this.SerialNoText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SerialNoText.Location = new System.Drawing.Point(91, 36);
            this.SerialNoText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.SerialNoText.Name = "SerialNoText";
            this.SerialNoText.Size = new System.Drawing.Size(90, 26);
            this.SerialNoText.TabIndex = 3;
            this.SerialNoText.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // StartBtn
            // 
            this.StartBtn.Location = new System.Drawing.Point(193, 7);
            this.StartBtn.Name = "StartBtn";
            this.StartBtn.Size = new System.Drawing.Size(128, 54);
            this.StartBtn.TabIndex = 4;
            this.StartBtn.Text = "Start [F1]";
            this.StartBtn.UseVisualStyleBackColor = true;
            this.StartBtn.Click += new System.EventHandler(this.StartBtn_Click);
            // 
            // ResultLabel
            // 
            this.ResultLabel.Location = new System.Drawing.Point(335, 23);
            this.ResultLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ResultLabel.Name = "ResultLabel";
            this.ResultLabel.Size = new System.Drawing.Size(99, 22);
            this.ResultLabel.TabIndex = 5;
            this.ResultLabel.Text = "Result";
            this.ResultLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ResultText
            // 
            this.ResultText.BackColor = System.Drawing.Color.White;
            this.ResultText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ResultText.Font = new System.Drawing.Font("MS Gothic", 32.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.ResultText.ForeColor = System.Drawing.Color.Black;
            this.ResultText.Location = new System.Drawing.Point(440, 1);
            this.ResultText.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ResultText.Name = "ResultText";
            this.ResultText.Size = new System.Drawing.Size(92, 61);
            this.ResultText.TabIndex = 6;
            this.ResultText.Text = "-";
            this.ResultText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DebugCheckBox
            // 
            this.DebugCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DebugCheckBox.Location = new System.Drawing.Point(353, 70);
            this.DebugCheckBox.Name = "DebugCheckBox";
            this.DebugCheckBox.Size = new System.Drawing.Size(179, 22);
            this.DebugCheckBox.TabIndex = 10;
            this.DebugCheckBox.Text = "more information";
            this.DebugCheckBox.UseVisualStyleBackColor = true;
            this.DebugCheckBox.CheckedChanged += new System.EventHandler(this.DebugCheckBox_CheckedChanged);
            // 
            // TaskGrid
            // 
            this.TaskGrid.AllowUserToAddRows = false;
            this.TaskGrid.AllowUserToDeleteRows = false;
            this.TaskGrid.AllowUserToResizeRows = false;
            this.TaskGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.TaskGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.TaskGrid.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.TaskGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.TaskGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TaskGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.TaskGrid.GridColor = System.Drawing.Color.Black;
            this.TaskGrid.Location = new System.Drawing.Point(4, 93);
            this.TaskGrid.MultiSelect = false;
            this.TaskGrid.Name = "TaskGrid";
            this.TaskGrid.ReadOnly = true;
            this.TaskGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.TaskGrid.RowTemplate.Height = 21;
            this.TaskGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TaskGrid.Size = new System.Drawing.Size(529, 181);
            this.TaskGrid.TabIndex = 0;
            this.TaskGrid.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.TaskGrid_CellPainting);
            this.TaskGrid.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.TaskGrid_RowPostPaint);
            this.TaskGrid.SelectionChanged += new System.EventHandler(this.TaskGrid_SelectionChanged);
            this.TaskGrid.DoubleClick += new System.EventHandler(this.TaskGrid_DoubleClick);
            this.TaskGrid.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TaskGrid_KeyDown);
            this.TaskGrid.Resize += new System.EventHandler(this.TaskGrid_Resize);
            // 
            // StopBtn
            // 
            this.StopBtn.Location = new System.Drawing.Point(230, 7);
            this.StopBtn.Name = "StopBtn";
            this.StopBtn.Size = new System.Drawing.Size(128, 54);
            this.StopBtn.TabIndex = 10;
            this.StopBtn.Text = "Stop [F2]";
            this.StopBtn.UseVisualStyleBackColor = true;
            this.StopBtn.Click += new System.EventHandler(this.StopBtn_Click);
            // 
            // ResetBtn
            // 
            this.ResetBtn.Location = new System.Drawing.Point(254, 7);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(128, 54);
            this.ResetBtn.TabIndex = 11;
            this.ResetBtn.Text = "Reset [F3]";
            this.ResetBtn.UseVisualStyleBackColor = true;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // EndBtn
            // 
            this.EndBtn.Location = new System.Drawing.Point(275, 7);
            this.EndBtn.Name = "EndBtn";
            this.EndBtn.Size = new System.Drawing.Size(128, 54);
            this.EndBtn.TabIndex = 12;
            this.EndBtn.Text = "End [ESC]";
            this.EndBtn.UseVisualStyleBackColor = true;
            this.EndBtn.Click += new System.EventHandler(this.EndBtn_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel1MinSize = 0;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.DebugGroupBox);
            this.splitContainer1.Panel2.Controls.Add(this.InitialSettingGroupBox);
            this.splitContainer1.Panel2.Controls.Add(this.PatternSettingGroupBox);
            this.splitContainer1.Panel2MinSize = 0;
            this.splitContainer1.Size = new System.Drawing.Size(899, 535);
            this.splitContainer1.SplitterDistance = 536;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 13;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.PatternNameLabel);
            this.splitContainer2.Panel1.Controls.Add(this.TaskGrid);
            this.splitContainer2.Panel1.Controls.Add(this.EndBtn);
            this.splitContainer2.Panel1.Controls.Add(this.LotLabel);
            this.splitContainer2.Panel1.Controls.Add(this.ResetBtn);
            this.splitContainer2.Panel1.Controls.Add(this.label4);
            this.splitContainer2.Panel1.Controls.Add(this.StopBtn);
            this.splitContainer2.Panel1.Controls.Add(this.DebugCheckBox);
            this.splitContainer2.Panel1.Controls.Add(this.ResultLabel);
            this.splitContainer2.Panel1.Controls.Add(this.SerialNoLabel);
            this.splitContainer2.Panel1.Controls.Add(this.ResultText);
            this.splitContainer2.Panel1.Controls.Add(this.StartBtn);
            this.splitContainer2.Panel1.Controls.Add(this.LotText);
            this.splitContainer2.Panel1.Controls.Add(this.SerialNoText);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.InfomationLabel);
            this.splitContainer2.Panel2.Controls.Add(this.panel4);
            this.splitContainer2.Panel2.Controls.Add(this.panel3);
            this.splitContainer2.Panel2.Controls.Add(this.panel2);
            this.splitContainer2.Panel2.Controls.Add(this.panel1);
            this.splitContainer2.Size = new System.Drawing.Size(536, 535);
            this.splitContainer2.SplitterDistance = 275;
            this.splitContainer2.SplitterWidth = 1;
            this.splitContainer2.TabIndex = 19;
            // 
            // PatternNameLabel
            // 
            this.PatternNameLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PatternNameLabel.BackColor = System.Drawing.Color.White;
            this.PatternNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PatternNameLabel.Location = new System.Drawing.Point(149, 70);
            this.PatternNameLabel.Name = "PatternNameLabel";
            this.PatternNameLabel.Size = new System.Drawing.Size(127, 22);
            this.PatternNameLabel.TabIndex = 37;
            this.PatternNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(8, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 19);
            this.label4.TabIndex = 15;
            this.label4.Text = "Tasks";
            // 
            // InfomationLabel
            // 
            this.InfomationLabel.Location = new System.Drawing.Point(8, 0);
            this.InfomationLabel.Name = "InfomationLabel";
            this.InfomationLabel.Size = new System.Drawing.Size(268, 24);
            this.InfomationLabel.TabIndex = 16;
            this.InfomationLabel.Text = "Information";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.progressBar1);
            this.panel4.Location = new System.Drawing.Point(291, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(228, 13);
            this.panel4.TabIndex = 49;
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar1.Location = new System.Drawing.Point(0, 1);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(228, 10);
            this.progressBar1.TabIndex = 16;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.KinsyuInfoGrid);
            this.panel3.Controls.Add(this.InfomationTextBox);
            this.panel3.Location = new System.Drawing.Point(23, 161);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(499, 107);
            this.panel3.TabIndex = 48;
            // 
            // KinsyuInfoGrid
            // 
            this.KinsyuInfoGrid.AllowUserToAddRows = false;
            this.KinsyuInfoGrid.AllowUserToDeleteRows = false;
            this.KinsyuInfoGrid.AllowUserToResizeRows = false;
            this.KinsyuInfoGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.KinsyuInfoGrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.KinsyuInfoGrid.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.KinsyuInfoGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.KinsyuInfoGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KinsyuInfoGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.KinsyuInfoGrid.Enabled = false;
            this.KinsyuInfoGrid.GridColor = System.Drawing.Color.Black;
            this.KinsyuInfoGrid.Location = new System.Drawing.Point(2, 2);
            this.KinsyuInfoGrid.MultiSelect = false;
            this.KinsyuInfoGrid.Name = "KinsyuInfoGrid";
            this.KinsyuInfoGrid.ReadOnly = true;
            this.KinsyuInfoGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.KinsyuInfoGrid.RowHeadersVisible = false;
            this.KinsyuInfoGrid.RowTemplate.Height = 21;
            this.KinsyuInfoGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.KinsyuInfoGrid.Size = new System.Drawing.Size(308, 102);
            this.KinsyuInfoGrid.TabIndex = 17;
            // 
            // InfomationTextBox
            // 
            this.InfomationTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InfomationTextBox.BackColor = System.Drawing.Color.White;
            this.InfomationTextBox.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.InfomationTextBox.Location = new System.Drawing.Point(311, 0);
            this.InfomationTextBox.Multiline = true;
            this.InfomationTextBox.Name = "InfomationTextBox";
            this.InfomationTextBox.ReadOnly = true;
            this.InfomationTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.InfomationTextBox.Size = new System.Drawing.Size(185, 107);
            this.InfomationTextBox.TabIndex = 45;
            this.InfomationTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TaskGrid_KeyDown);
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.Info2_1_1);
            this.panel2.Controls.Add(this.Info2_2_4);
            this.panel2.Controls.Add(this.Info2_2_5);
            this.panel2.Controls.Add(this.Info2_2_3);
            this.panel2.Controls.Add(this.Info2_3_8);
            this.panel2.Controls.Add(this.Info2_2_6);
            this.panel2.Controls.Add(this.Info2_3_7);
            this.panel2.Controls.Add(this.Info2_2_2);
            this.panel2.Controls.Add(this.Info2_2_1);
            this.panel2.Controls.Add(this.Info2_2_8);
            this.panel2.Controls.Add(this.Info2_1_6);
            this.panel2.Controls.Add(this.Info2_3_6);
            this.panel2.Controls.Add(this.Info2_1_5);
            this.panel2.Controls.Add(this.Info2_2_7);
            this.panel2.Controls.Add(this.Info2_3_1);
            this.panel2.Controls.Add(this.Info2_1_8);
            this.panel2.Controls.Add(this.Info2_1_4);
            this.panel2.Controls.Add(this.Info2_3_5);
            this.panel2.Controls.Add(this.Info2_3_2);
            this.panel2.Controls.Add(this.Info2_1_7);
            this.panel2.Controls.Add(this.Info2_1_3);
            this.panel2.Controls.Add(this.Info2_3_3);
            this.panel2.Controls.Add(this.Info2_3_4);
            this.panel2.Controls.Add(this.Info2_1_2);
            this.panel2.Location = new System.Drawing.Point(24, 92);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(498, 69);
            this.panel2.TabIndex = 47;
            // 
            // Info2_1_1
            // 
            this.Info2_1_1.BackColor = System.Drawing.Color.White;
            this.Info2_1_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_1.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_1.Location = new System.Drawing.Point(1, 1);
            this.Info2_1_1.Name = "Info2_1_1";
            this.Info2_1_1.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_1.TabIndex = 20;
            this.Info2_1_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_4
            // 
            this.Info2_2_4.BackColor = System.Drawing.Color.White;
            this.Info2_2_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_4.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_4.Location = new System.Drawing.Point(187, 23);
            this.Info2_2_4.Name = "Info2_2_4";
            this.Info2_2_4.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_4.TabIndex = 31;
            this.Info2_2_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_5
            // 
            this.Info2_2_5.BackColor = System.Drawing.Color.White;
            this.Info2_2_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_5.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_5.Location = new System.Drawing.Point(249, 23);
            this.Info2_2_5.Name = "Info2_2_5";
            this.Info2_2_5.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_5.TabIndex = 32;
            this.Info2_2_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_3
            // 
            this.Info2_2_3.BackColor = System.Drawing.Color.White;
            this.Info2_2_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_3.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_3.Location = new System.Drawing.Point(125, 23);
            this.Info2_2_3.Name = "Info2_2_3";
            this.Info2_2_3.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_3.TabIndex = 30;
            this.Info2_2_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_8
            // 
            this.Info2_3_8.BackColor = System.Drawing.Color.White;
            this.Info2_3_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_8.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_8.Location = new System.Drawing.Point(435, 45);
            this.Info2_3_8.Name = "Info2_3_8";
            this.Info2_3_8.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_8.TabIndex = 44;
            this.Info2_3_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_6
            // 
            this.Info2_2_6.BackColor = System.Drawing.Color.White;
            this.Info2_2_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_6.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_6.Location = new System.Drawing.Point(311, 23);
            this.Info2_2_6.Name = "Info2_2_6";
            this.Info2_2_6.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_6.TabIndex = 33;
            this.Info2_2_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_7
            // 
            this.Info2_3_7.BackColor = System.Drawing.Color.White;
            this.Info2_3_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_7.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_7.Location = new System.Drawing.Point(373, 45);
            this.Info2_3_7.Name = "Info2_3_7";
            this.Info2_3_7.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_7.TabIndex = 43;
            this.Info2_3_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_2
            // 
            this.Info2_2_2.BackColor = System.Drawing.Color.White;
            this.Info2_2_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_2.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_2.Location = new System.Drawing.Point(63, 23);
            this.Info2_2_2.Name = "Info2_2_2";
            this.Info2_2_2.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_2.TabIndex = 29;
            this.Info2_2_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_1
            // 
            this.Info2_2_1.BackColor = System.Drawing.Color.White;
            this.Info2_2_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_1.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_1.Location = new System.Drawing.Point(1, 23);
            this.Info2_2_1.Name = "Info2_2_1";
            this.Info2_2_1.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_1.TabIndex = 28;
            this.Info2_2_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_8
            // 
            this.Info2_2_8.BackColor = System.Drawing.Color.White;
            this.Info2_2_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_8.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_8.Location = new System.Drawing.Point(435, 23);
            this.Info2_2_8.Name = "Info2_2_8";
            this.Info2_2_8.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_8.TabIndex = 35;
            this.Info2_2_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_6
            // 
            this.Info2_1_6.BackColor = System.Drawing.Color.White;
            this.Info2_1_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_6.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_6.Location = new System.Drawing.Point(311, 1);
            this.Info2_1_6.Name = "Info2_1_6";
            this.Info2_1_6.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_6.TabIndex = 25;
            this.Info2_1_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_6
            // 
            this.Info2_3_6.BackColor = System.Drawing.Color.White;
            this.Info2_3_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_6.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_6.Location = new System.Drawing.Point(311, 45);
            this.Info2_3_6.Name = "Info2_3_6";
            this.Info2_3_6.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_6.TabIndex = 42;
            this.Info2_3_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_5
            // 
            this.Info2_1_5.BackColor = System.Drawing.Color.White;
            this.Info2_1_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_5.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_5.Location = new System.Drawing.Point(249, 1);
            this.Info2_1_5.Name = "Info2_1_5";
            this.Info2_1_5.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_5.TabIndex = 24;
            this.Info2_1_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_7
            // 
            this.Info2_2_7.BackColor = System.Drawing.Color.White;
            this.Info2_2_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_7.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_7.Location = new System.Drawing.Point(373, 23);
            this.Info2_2_7.Name = "Info2_2_7";
            this.Info2_2_7.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_7.TabIndex = 34;
            this.Info2_2_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_1
            // 
            this.Info2_3_1.BackColor = System.Drawing.Color.White;
            this.Info2_3_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_1.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_1.Location = new System.Drawing.Point(1, 45);
            this.Info2_3_1.Name = "Info2_3_1";
            this.Info2_3_1.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_1.TabIndex = 37;
            this.Info2_3_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_8
            // 
            this.Info2_1_8.BackColor = System.Drawing.Color.White;
            this.Info2_1_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_8.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_8.Location = new System.Drawing.Point(435, 1);
            this.Info2_1_8.Name = "Info2_1_8";
            this.Info2_1_8.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_8.TabIndex = 27;
            this.Info2_1_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_4
            // 
            this.Info2_1_4.BackColor = System.Drawing.Color.White;
            this.Info2_1_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_4.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_4.Location = new System.Drawing.Point(187, 1);
            this.Info2_1_4.Name = "Info2_1_4";
            this.Info2_1_4.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_4.TabIndex = 23;
            this.Info2_1_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_5
            // 
            this.Info2_3_5.BackColor = System.Drawing.Color.White;
            this.Info2_3_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_5.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_5.Location = new System.Drawing.Point(249, 45);
            this.Info2_3_5.Name = "Info2_3_5";
            this.Info2_3_5.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_5.TabIndex = 41;
            this.Info2_3_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_2
            // 
            this.Info2_3_2.BackColor = System.Drawing.Color.White;
            this.Info2_3_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_2.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_2.Location = new System.Drawing.Point(63, 45);
            this.Info2_3_2.Name = "Info2_3_2";
            this.Info2_3_2.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_2.TabIndex = 38;
            this.Info2_3_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_7
            // 
            this.Info2_1_7.BackColor = System.Drawing.Color.White;
            this.Info2_1_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_7.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_7.Location = new System.Drawing.Point(373, 1);
            this.Info2_1_7.Name = "Info2_1_7";
            this.Info2_1_7.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_7.TabIndex = 26;
            this.Info2_1_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_3
            // 
            this.Info2_1_3.BackColor = System.Drawing.Color.White;
            this.Info2_1_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_3.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_3.Location = new System.Drawing.Point(125, 1);
            this.Info2_1_3.Name = "Info2_1_3";
            this.Info2_1_3.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_3.TabIndex = 22;
            this.Info2_1_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_3
            // 
            this.Info2_3_3.BackColor = System.Drawing.Color.White;
            this.Info2_3_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_3.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_3.Location = new System.Drawing.Point(125, 45);
            this.Info2_3_3.Name = "Info2_3_3";
            this.Info2_3_3.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_3.TabIndex = 39;
            this.Info2_3_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_4
            // 
            this.Info2_3_4.BackColor = System.Drawing.Color.White;
            this.Info2_3_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_4.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_4.Location = new System.Drawing.Point(187, 45);
            this.Info2_3_4.Name = "Info2_3_4";
            this.Info2_3_4.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_4.TabIndex = 40;
            this.Info2_3_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_2
            // 
            this.Info2_1_2.BackColor = System.Drawing.Color.White;
            this.Info2_1_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_2.Font = new System.Drawing.Font("MS Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_2.Location = new System.Drawing.Point(63, 1);
            this.Info2_1_2.Name = "Info2_1_2";
            this.Info2_1_2.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_2.TabIndex = 21;
            this.Info2_1_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.Info1_1);
            this.panel1.Controls.Add(this.Info1_3);
            this.panel1.Controls.Add(this.Info1_2);
            this.panel1.Location = new System.Drawing.Point(24, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(498, 68);
            this.panel1.TabIndex = 46;
            // 
            // Info1_1
            // 
            this.Info1_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Info1_1.BackColor = System.Drawing.Color.White;
            this.Info1_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info1_1.Location = new System.Drawing.Point(1, 1);
            this.Info1_1.Name = "Info1_1";
            this.Info1_1.Size = new System.Drawing.Size(495, 21);
            this.Info1_1.TabIndex = 18;
            this.Info1_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info1_3
            // 
            this.Info1_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Info1_3.BackColor = System.Drawing.Color.White;
            this.Info1_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info1_3.Location = new System.Drawing.Point(1, 45);
            this.Info1_3.Name = "Info1_3";
            this.Info1_3.Size = new System.Drawing.Size(495, 21);
            this.Info1_3.TabIndex = 36;
            this.Info1_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info1_2
            // 
            this.Info1_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Info1_2.BackColor = System.Drawing.Color.White;
            this.Info1_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info1_2.Location = new System.Drawing.Point(1, 23);
            this.Info1_2.Name = "Info1_2";
            this.Info1_2.Size = new System.Drawing.Size(495, 21);
            this.Info1_2.TabIndex = 19;
            this.Info1_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // DebugGroupBox
            // 
            this.DebugGroupBox.Controls.Add(this.EndCountClearButton);
            this.DebugGroupBox.Controls.Add(this.CommDebugFormShowButton);
            this.DebugGroupBox.Controls.Add(this.ForceStopButton);
            this.DebugGroupBox.Controls.Add(this.DownloadButton);
            this.DebugGroupBox.Controls.Add(this.LogReadButton);
            this.DebugGroupBox.Controls.Add(this.SingleButton);
            this.DebugGroupBox.Controls.Add(this.ResetButton);
            this.DebugGroupBox.Controls.Add(this.StepButton);
            this.DebugGroupBox.Location = new System.Drawing.Point(9, 9);
            this.DebugGroupBox.Name = "DebugGroupBox";
            this.DebugGroupBox.Size = new System.Drawing.Size(344, 305);
            this.DebugGroupBox.TabIndex = 30;
            this.DebugGroupBox.TabStop = false;
            this.DebugGroupBox.Text = "Debug button and infomation";
            // 
            // EndCountClearButton
            // 
            this.EndCountClearButton.Location = new System.Drawing.Point(176, 133);
            this.EndCountClearButton.Name = "EndCountClearButton";
            this.EndCountClearButton.Size = new System.Drawing.Size(159, 30);
            this.EndCountClearButton.TabIndex = 37;
            this.EndCountClearButton.Text = "Result clear";
            this.EndCountClearButton.UseVisualStyleBackColor = true;
            this.EndCountClearButton.Click += new System.EventHandler(this.EndCountClearButton_Click);
            // 
            // CommDebugFormShowButton
            // 
            this.CommDebugFormShowButton.Location = new System.Drawing.Point(11, 133);
            this.CommDebugFormShowButton.Name = "CommDebugFormShowButton";
            this.CommDebugFormShowButton.Size = new System.Drawing.Size(159, 30);
            this.CommDebugFormShowButton.TabIndex = 36;
            this.CommDebugFormShowButton.Text = "Comm form show";
            this.CommDebugFormShowButton.UseVisualStyleBackColor = true;
            this.CommDebugFormShowButton.Click += new System.EventHandler(this.CommDebugFormShowButton_Click);
            // 
            // ForceStopButton
            // 
            this.ForceStopButton.Location = new System.Drawing.Point(176, 25);
            this.ForceStopButton.Name = "ForceStopButton";
            this.ForceStopButton.Size = new System.Drawing.Size(159, 30);
            this.ForceStopButton.TabIndex = 35;
            this.ForceStopButton.Text = "Forced outage";
            this.ForceStopButton.UseVisualStyleBackColor = true;
            this.ForceStopButton.Click += new System.EventHandler(this.ForceStopButton_Click);
            // 
            // DownloadButton
            // 
            this.DownloadButton.Location = new System.Drawing.Point(176, 97);
            this.DownloadButton.Name = "DownloadButton";
            this.DownloadButton.Size = new System.Drawing.Size(159, 30);
            this.DownloadButton.TabIndex = 34;
            this.DownloadButton.Text = "Download";
            this.DownloadButton.UseVisualStyleBackColor = true;
            this.DownloadButton.Click += new System.EventHandler(this.DownloadButton_Click);
            // 
            // LogReadButton
            // 
            this.LogReadButton.Location = new System.Drawing.Point(11, 97);
            this.LogReadButton.Name = "LogReadButton";
            this.LogReadButton.Size = new System.Drawing.Size(159, 30);
            this.LogReadButton.TabIndex = 33;
            this.LogReadButton.Text = "Log read";
            this.LogReadButton.UseVisualStyleBackColor = true;
            this.LogReadButton.Click += new System.EventHandler(this.LogReadButton_Click);
            // 
            // SingleButton
            // 
            this.SingleButton.Location = new System.Drawing.Point(176, 61);
            this.SingleButton.Name = "SingleButton";
            this.SingleButton.Size = new System.Drawing.Size(159, 30);
            this.SingleButton.TabIndex = 32;
            this.SingleButton.Text = "Select run";
            this.SingleButton.UseVisualStyleBackColor = true;
            this.SingleButton.Click += new System.EventHandler(this.SingleButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.Location = new System.Drawing.Point(11, 61);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(159, 30);
            this.ResetButton.TabIndex = 31;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // StepButton
            // 
            this.StepButton.Location = new System.Drawing.Point(11, 25);
            this.StepButton.Name = "StepButton";
            this.StepButton.Size = new System.Drawing.Size(159, 30);
            this.StepButton.TabIndex = 30;
            this.StepButton.Text = "Step run";
            this.StepButton.UseVisualStyleBackColor = true;
            this.StepButton.Click += new System.EventHandler(this.StepButton_Click);
            // 
            // InitialSettingGroupBox
            // 
            this.InitialSettingGroupBox.Controls.Add(this.InitSettingButton);
            this.InitialSettingGroupBox.Location = new System.Drawing.Point(6, 320);
            this.InitialSettingGroupBox.Name = "InitialSettingGroupBox";
            this.InitialSettingGroupBox.Size = new System.Drawing.Size(344, 63);
            this.InitialSettingGroupBox.TabIndex = 29;
            this.InitialSettingGroupBox.TabStop = false;
            this.InitialSettingGroupBox.Text = "Initial settings edit";
            // 
            // InitSettingButton
            // 
            this.InitSettingButton.Location = new System.Drawing.Point(12, 22);
            this.InitSettingButton.Name = "InitSettingButton";
            this.InitSettingButton.Size = new System.Drawing.Size(138, 30);
            this.InitSettingButton.TabIndex = 25;
            this.InitSettingButton.Text = "Setting";
            this.InitSettingButton.UseVisualStyleBackColor = true;
            this.InitSettingButton.Click += new System.EventHandler(this.InitSettingButton_Click);
            // 
            // PatternSettingGroupBox
            // 
            this.PatternSettingGroupBox.Controls.Add(this.button9);
            this.PatternSettingGroupBox.Controls.Add(this.button8);
            this.PatternSettingGroupBox.Controls.Add(this.button7);
            this.PatternSettingGroupBox.Controls.Add(this.button6);
            this.PatternSettingGroupBox.Controls.Add(this.button5);
            this.PatternSettingGroupBox.Controls.Add(this.button2);
            this.PatternSettingGroupBox.Controls.Add(this.button1);
            this.PatternSettingGroupBox.Controls.Add(this.PatternSettingButton);
            this.PatternSettingGroupBox.Location = new System.Drawing.Point(6, 389);
            this.PatternSettingGroupBox.Name = "PatternSettingGroupBox";
            this.PatternSettingGroupBox.Size = new System.Drawing.Size(344, 134);
            this.PatternSettingGroupBox.TabIndex = 26;
            this.PatternSettingGroupBox.TabStop = false;
            this.PatternSettingGroupBox.Text = "Pattern edit";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(242, 94);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(96, 30);
            this.button9.TabIndex = 32;
            this.button9.Text = "Paste";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(140, 94);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(96, 30);
            this.button8.TabIndex = 31;
            this.button8.Text = "Copy";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(242, 58);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(96, 30);
            this.button7.TabIndex = 30;
            this.button7.Text = "Del Cmd";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(140, 58);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(96, 30);
            this.button6.TabIndex = 29;
            this.button6.Text = "Edit Cmd";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Visible = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.button5.Location = new System.Drawing.Point(12, 58);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(122, 30);
            this.button5.TabIndex = 28;
            this.button5.Text = "Save";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Visible = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(242, 22);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(96, 30);
            this.button2.TabIndex = 27;
            this.button2.Text = "Del Row";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(140, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(96, 30);
            this.button1.TabIndex = 26;
            this.button1.Text = "Add Row";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // PatternSettingButton
            // 
            this.PatternSettingButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.PatternSettingButton.Location = new System.Drawing.Point(12, 22);
            this.PatternSettingButton.Name = "PatternSettingButton";
            this.PatternSettingButton.Size = new System.Drawing.Size(122, 30);
            this.PatternSettingButton.TabIndex = 25;
            this.PatternSettingButton.Text = "Start edit";
            this.PatternSettingButton.UseVisualStyleBackColor = false;
            this.PatternSettingButton.Click += new System.EventHandler(this.PatternSettingButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.LightYellow;
            this.ClientSize = new System.Drawing.Size(899, 535);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("MS Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "検査①";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.TaskGrid)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KinsyuInfoGrid)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.DebugGroupBox.ResumeLayout(false);
            this.InitialSettingGroupBox.ResumeLayout(false);
            this.PatternSettingGroupBox.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LotLabel;
        private System.Windows.Forms.Label SerialNoLabel;
        private System.Windows.Forms.Label LotText;
        private System.Windows.Forms.Label SerialNoText;
        private System.Windows.Forms.Button StartBtn;
        private System.Windows.Forms.Label ResultLabel;
        private System.Windows.Forms.Label ResultText;
        private System.Windows.Forms.DataGridView TaskGrid;
        private System.Windows.Forms.CheckBox DebugCheckBox;
        private System.Windows.Forms.Button StopBtn;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.Button EndBtn;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button PatternSettingButton;
        private System.Windows.Forms.GroupBox PatternSettingGroupBox;
        private System.Windows.Forms.GroupBox InitialSettingGroupBox;
        private System.Windows.Forms.Button InitSettingButton;
        private System.Windows.Forms.DataGridView KinsyuInfoGrid;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.GroupBox DebugGroupBox;
        private System.Windows.Forms.Button CommDebugFormShowButton;
        private System.Windows.Forms.Button ForceStopButton;
        private System.Windows.Forms.Button DownloadButton;
        private System.Windows.Forms.Button LogReadButton;
        private System.Windows.Forms.Button SingleButton;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button StepButton;
        private System.Windows.Forms.Label Info2_1_7;
        private System.Windows.Forms.Label Info2_1_6;
        private System.Windows.Forms.Label Info2_1_5;
        private System.Windows.Forms.Label Info2_1_4;
        private System.Windows.Forms.Label Info2_1_3;
        private System.Windows.Forms.Label Info2_1_2;
        private System.Windows.Forms.Label Info2_1_1;
        private System.Windows.Forms.Label Info1_2;
        private System.Windows.Forms.Label Info1_1;
        private System.Windows.Forms.TextBox InfomationTextBox;
        private System.Windows.Forms.Label Info2_3_8;
        private System.Windows.Forms.Label Info2_3_7;
        private System.Windows.Forms.Label Info2_3_6;
        private System.Windows.Forms.Label Info2_3_5;
        private System.Windows.Forms.Label Info2_3_4;
        private System.Windows.Forms.Label Info2_3_3;
        private System.Windows.Forms.Label Info2_3_2;
        private System.Windows.Forms.Label Info2_3_1;
        private System.Windows.Forms.Label Info1_3;
        private System.Windows.Forms.Label Info2_2_8;
        private System.Windows.Forms.Label Info2_2_7;
        private System.Windows.Forms.Label Info2_2_6;
        private System.Windows.Forms.Label Info2_2_5;
        private System.Windows.Forms.Label Info2_2_4;
        private System.Windows.Forms.Label Info2_2_3;
        private System.Windows.Forms.Label Info2_2_2;
        private System.Windows.Forms.Label Info2_2_1;
        private System.Windows.Forms.Label Info2_1_8;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label InfomationLabel;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button EndCountClearButton;
        private System.Windows.Forms.Label PatternNameLabel;
    }
}

