﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Simulator
{
    static class Program
    {
        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            //ロック(EXE名でロックされます)
            //System.Threading.Mutex mutex = SgNet.COM.Process_s.MutexStart(System.IO.Path.GetFileNameWithoutExtension(Application.ExecutablePath), 0);
            ////System.Threading.Mutex mutex = SgNet.COM.Process_s.MutexStart("MutexKey", 0);
            //if (mutex != null)
            //{
                //フォームの起動　　※下記は最初からMain関数に書かれているコード　実際にはコメントアウトしないでね
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new InputSID());

                //ロック解除
                //SgNet.COM.Process_s.MutexEnd(mutex);
            //}
            //else
            //{
            //    //起動している
            //    SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + "\\MsgString.ini", "Msg", "6", "This application has been already started.");
            //}
            //SgNet.COM.Application_s.Exit();
        }
    }
}
