﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class SensCondition
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public SensCondition(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                string portinfo = CmdP.Parameter;               //パラメータの欄から文字列を取得する
                string[] portData = portinfo.Split(',');        //カンマ区切りで分割して配列に格納する
                if (portData.Length != 3)
                {
                    err = true;
                    switch (OwnerP.Lang)
                    {
                        case "CN":
                            OwnerP.ChangeInfo(0, 0, "参数异常", System.Drawing.Color.Red);
                            break;
                        case "JP":
                            OwnerP.ChangeInfo(0, 0, "パラメータ異常", System.Drawing.Color.Red);
                            break;
                    }
                    break;
                }

                byte addr = byte.Parse(portData[0]);
                byte bit = byte.Parse(portData[1]);
                byte active = byte.Parse(portData[2]);

                int now = 0;

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);   //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                //ポートリードコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASportread);       //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                if (err == false)
                {
                    byte[] ReceiveData;
                    bool Firstflg = false;
                    int keeptimes = 0;
                    while (true)
                    {
                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);      //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);                //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);             //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);                 //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }
                        if (Firstflg == false)
                        {
                            now = ReceiveData[addr] & bit;
                            Firstflg = true;
                        }
                        if (now != (ReceiveData[addr] & bit))   //対象ポートデータが変化した
                        {
                            now = ReceiveData[addr] & bit;      //状態を更新
                            keeptimes = 0;                      //連続一致回数クリア
                        }
                        else
                        {
                            keeptimes++;
                            if (keeptimes >= 3) { break; }      //規定回数連続一致で終了（３回に設定））
                        }
                    }

                    if (recv != null)           //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                    {
                        //ＲＡＳ継続動作終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);           //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);                 //送信
                        if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);        //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                if ((active == 0) && (now != 0))
                {
                    err = true;
                    OwnerP.ChangeInfo(0, 0, "センサ状態異常（透光確認時）", System.Drawing.Color.Red);
                }
                if ((active != 0) && (now == 0))
                {
                    err = true;
                    OwnerP.ChangeInfo(0, 0, "センサ状態異常（遮光確認時）", System.Drawing.Color.Red);
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
