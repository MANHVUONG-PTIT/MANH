﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;
using System.Diagnostics;

namespace Simulator
{
    public class CmdCommon
    {
        static public Cmd ReadCmdXML(String path)
        {
            Cmd cmd = (Cmd)SgNet.COM.File_s.Xml_s.Load(path, typeof(Cmd));
            if (cmd == null)
            {
                String error = SgNet.COM.Debug_s.LastErrorString;
                SequenceClass sqc = (SequenceClass)SgNet.COM.File_s.Xml_s.Load(path, typeof(SequenceClass));
                if (sqc == null)
                {
                    SgNet.COM.MessageBox_s.ShowError(path + "\n\n" + error);
                    return null;
                }
                else
                {
                    cmd = new Cmd();
                    cmd.SequenceP = sqc;
                }
            }
            cmd.FileName = SgNet.COM.File_s.Path2FileNameWithoutEx(path);
            if (cmd.SequenceName == "") cmd.SequenceName = cmd.FileName;
            return cmd;
        }
        static public bool WriteCmdXML(String path, Cmd cmd)
        {

            bool ret = SgNet.COM.File_s.Xml_s.Save(cmd, path);
            return ret;
        }
        static public List<PatternRow> GetPattern(bool patternSaveFlg, DataGridView dgv, int gridPatternNo, int countCol, int endCountCol, int resultCol, int valueCol)
        {
            int i = 0;
            int c = 0;
            List<PatternRow> ptn = new List<PatternRow>();
            switch (gridPatternNo)
            {
                case 0://=Command,Comment,Result,                 ﾕﾆｯﾄSimを想定
                case 2://=Command,Comment,Value,Result            ﾕﾆｯﾄSim・品証ﾂｰﾙを想定
                case 4://=Command,money0,money1,・・・,Result     ﾗﾝﾆﾝｸﾞSimを想定
                    for (i = 0; i < dgv.RowCount; i++)
                    {
                        if (dgv[0, i].Tag != null)
                        {
                            ptn.Add(new PatternRow(i, new PatternCell(0, (Cmd)dgv[0,i].Tag), ""));
                            if (!patternSaveFlg)
                            {
                                switch(gridPatternNo)
                                {
                                    case 0:
                                    case 4:
                                        ptn[ptn.Count - 1].Result = (dgv[resultCol, i].Value != null ? dgv[resultCol, i].Value.ToString() : "");
                                        break;
                                    case 2:
                                        ptn[ptn.Count - 1].Value = (dgv[valueCol, i].Value != null ? dgv[valueCol, i].Value.ToString() : "");
                                        ptn[ptn.Count - 1].Result = (dgv[resultCol, i].Value != null ? dgv[resultCol, i].Value.ToString() : "");
                                        break;
                                }
                            }
                        }
                    }
                    break;
                case 1://=Command,Comment,End,Count               ﾕﾆｯﾄSimを想定
                case 3://=Command,Comment,Value,End,Count         ﾕﾆｯﾄSimを想定
                case 5://=Command,money0,money1,・・・,End,Count  ﾗﾝﾆﾝｸﾞSimを想定
                    for (i = 0; i < dgv.RowCount; i++)
                    {
                        if (dgv[0, i].Tag != null)
                        {
                            ptn.Add(new PatternRow(i, new PatternCell(0, (Cmd)dgv[0, i].Tag), (dgv[countCol, i].Value != null ? dgv[countCol, i].Value.ToString() : "")));
                            if (!patternSaveFlg)
                            {
                                switch (gridPatternNo)
                                {
                                    case 1:
                                    case 5:
                                        ptn[ptn.Count - 1].EndCount = (dgv[endCountCol, i].Value != null ? dgv[endCountCol, i].Value.ToString() : "");
                                        break;
                                    case 3:
                                        ptn[ptn.Count - 1].Value = (dgv[valueCol, i].Value != null ? dgv[valueCol, i].Value.ToString() : "");
                                        ptn[ptn.Count - 1].EndCount = (dgv[endCountCol, i].Value != null ? dgv[endCountCol, i].Value.ToString() : "");
                                        break;
                                }
                            }
                        }
                    }
                    break;
                case 6://=Cmd1,・・・,Cmd8,End,Count              ﾗﾝﾆﾝｸﾞSimを想定
                    for (i = 0; i < dgv.RowCount; i++)
                    {
                        List<PatternCell> lst = new List<PatternCell>();
                        for (c = 0; c < 8; c++)
                        {
                            if (dgv[c, i].Tag != null)
                            {
                                lst.Add(new PatternCell(c, (Cmd)dgv[c, i].Tag));
                            }
                        }
                        if (lst.Count > 0)
                        {
                            ptn.Add(new PatternRow(i, lst, (dgv[countCol, i].Value != null ? dgv[countCol, i].Value.ToString() : "")));
                            if (!patternSaveFlg)
                            {
                                ptn[ptn.Count - 1].EndCount = (dgv[endCountCol, i].Value != null ? dgv[endCountCol, i].Value.ToString() : "");
                            }
                        }
                    }
                    break;
            }
            return ptn;
        }
        static public List<PatternRow> ReadPatternXML(String path)
        {
            Pattern ptns = (Pattern)SgNet.COM.File_s.Xml_s.Load(path, typeof(Pattern));
            if (ptns == null) return null;
            return ptns.ptn;
        }
        static public bool WritePatternXML(String path, List<PatternRow> ptn)
        {
            Pattern ptns = new Pattern();
            ptns.ptn = ptn;
            bool ret = SgNet.COM.File_s.Xml_s.Save(ptns, path);
            return ret;
        }
    }
    [Serializable()]
    public class Pattern
    {
        public List<PatternRow> ptn;
    }
    [Serializable()]
    public class PatternRow
    {
        public int RowNo = 0;
        public List<PatternCell> RowData = new List<PatternCell>();
        public String Value = "";
        public String Result = "";
        public String EndCount = "";
        public String Count = "";
        public PatternRow()
        {
        }
        public PatternRow(int rowNo, PatternCell data, String count)
        {
            RowNo = rowNo;
            RowData.Add(data);
            Count = count;
        }
        public PatternRow(int rowNo, List<PatternCell> rowData, String count)
        {
            RowNo = rowNo;
            RowData = rowData;
            Count = count;
        }
    }

    [Serializable()]
    public class PatternCell
    {
        public int ColNo = 0;
        public Cmd CmdData = null;
        public PatternCell()
        {
        }
        public PatternCell(int colNo, Cmd cmd)
        {
            ColNo = colNo;
            CmdData = cmd;
        }
    }

    [Serializable()]
    public class Cmd //このクラスがメイン
    {
        public String FileName = "";
        public String SequenceName = "";
        public String Comment = "";
        public String Parameter = "";
        public SequenceClass SequenceP = new SequenceClass();
        public List<String> Maisu = new List<String>();
    }
    [Serializable()]
    public class SequenceClass
    {
        //デリゲートの宣言
        public delegate void DelegateCompleteMessage(bool errFlg);
        public delegate bool DelegateCmdSend(String CmdName, int EndWaitRule, int RequestID, String DLL_Status, String EventMessage_ErrorCodeID, String EventMessage_MessageID);
        public delegate void DelegateMessageEvent(int UnitRowNo, String MessageString, String MessageColor, String DLL_Status, String EventMessage_ErrorCodeID, String EventMessage_MessageID);
        public delegate void DelegateCmdMessage_Change(String CmdMessage);

        //イベントの宣言
        public event DelegateCompleteMessage CompleteMessage;
        public event DelegateCmdSend CmdSend;
        public event DelegateMessageEvent MessageEvent;
        public event DelegateCmdMessage_Change CmdMessage_Change;

        //デリゲートの他クラスからの起動
        public void CompleteMessage_Sub(bool errFlg) { CompleteMessage(errFlg); }
        public bool CmdSend_Sub(String CmdName, int EndWaitRule, int RequestID, String DLL_Status, String EventMessage_ErrorCodeID, String EventMessage_MessageID) { return CmdSend(CmdName, EndWaitRule, RequestID, DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID); }
        public void MessageEvent_Sub(int UnitRowNo, String MessageString, String MessageColor, String DLL_Status, String EventMessage_ErrorCodeID, String EventMessage_MessageID) { MessageEvent(UnitRowNo, MessageString, MessageColor, DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID); }
        public void CmdMessage_Change_Sub(String CmdMessage) { CmdMessage_Change(CmdMessage); }

        public int RunNo = 0;   //現在の実行番号
        //※public宣言しないとシリアライズできないからしてるが、絶対にこれを触るな！！
        public List<CmdClass> list = new List<CmdClass>();//実行コマンドリスト

        public bool Before2Hidouki = false;
        public bool Before1Hidouki = false;
        private int OwnerRequestID = 0;
        private String OwnerDLL_Status = "";
        private String OwnerEventMessage_ErrorCodeID = "";
        private String OwnerEventMessage_MessageID = "";
        public int GetOwnerRequestID() { return OwnerRequestID; }
        public String GetOwnerDLL_Status() { return OwnerDLL_Status; }
        public String GetOwnerEventMessage_ErrorCodeID() { return OwnerEventMessage_ErrorCodeID; }
        public String GetOwnerEventMessage_MessageID() { return OwnerEventMessage_MessageID; }
        private String SequenceName = "";

        ~SequenceClass()
        {
            Dispose();
        }
        public void Dispose()
        {
            list.Clear();
            GC.Collect();
        }
        //コマンドクラスの追加
        public void CmdClassAdd(CmdClass cmd)
        {
            list.Add(cmd);
        }
        //コマンドクラスの削除
        public void CmdClassDelete(int index)
        {
            list.RemoveAt(index);
        }
        //コマンドクラスの順番入れ替え
        public void CmdClassChange(int oldIndex, int newIndex)
        {
            CmdClass p = GetCmdClass(oldIndex);
            list.RemoveAt(oldIndex);
            list.Insert(newIndex, p);
        }
        //コマンドクラスのアドレス取得
        public CmdClass GetCmdClass(int index)
        {
            return list[index];
        }
        //コマンドクラスのアドレス取得
        public int GetCmdClassCount()
        {
            return list.Count;
        }
        //ｼｰｹﾝｽ名の取得
        public String GetSequenceName()
        {
            return SequenceName;
        }
        //ｼｰｹﾝｽ名のセット
        public void SetSequenceName(String sequenceName)
        {
            SequenceName = sequenceName;
        }
        //初期化する（使わないと思う）
        public void InitialSequence()
        {
            RunNo = 0;
            for (int a = 0; a < list.Count; a++)
            {
                list[a].SendRequestID = 0;
                list[a].StepNo = 0;
            }
        }
        /// <summary>
        /// コマンドを送信した後には必ず、これで送信RequestIDをｾｯﾄしておくこと
        /// </summary>
        /// <param name="RequestID">送信したRequestID</param>
        public void SendNotify(int RequestID)
        {
            if (RunNo >= list.Count)
            {
                //最後までシーケンスが終わっている場合は、なにもしない
            }
            else
            {
                list[RunNo].SendRequestID = RequestID;
            }
        }
        /// <summary>
        /// 状態を与えることで現在のステップ番号に対して、次の処理が行われるのかどうかなどがイベントで通知される
        /// この関数がシーケンス動作を行う上での一番メインの関数
        /// </summary>
        /// <param name="RequestID">返ってきたEventMessageのdwRequestID</param>
        /// <param name="DLL_Status">現在のDLLステータス</param>
        /// <param name="EventMessage_ErrorCodeID">返ってきたEventMessageのdwErrorCodeを文字列変換したもの</param>
        /// <param name="EventMessage_MessageID">返ってきたEventMessageのdwMessageIDを文字列変換したもの</param>
        public void ChangeStatus(bool doukiCmdFlg, int RequestID, String DLL_Status, String EventMessage_ErrorCodeID, String EventMessage_MessageID)
        {
            OwnerRequestID = RequestID;
            OwnerDLL_Status = DLL_Status;
            OwnerEventMessage_ErrorCodeID = EventMessage_ErrorCodeID;
            OwnerEventMessage_MessageID = EventMessage_MessageID;

            if (RunNo >= list.Count)
            {
                //最後までシーケンスが終わっている場合は、終了イベント
                CompleteMessage(false);
            }
            else
            {
                if (list[RunNo].StepNo == 0)
                {
                    //実行前なのでBeforeIF条件で状況待ち
                    list[RunNo].CheckEvent(doukiCmdFlg, this, RunNo, 0, RequestID, DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID);
                }
                else
                {
                    if (list[RunNo].StepNo == 2)
                    {
                        //KeizokuInfoIfでコマンドが実行された
                        //とりあえずlist[RunNo].StepNo = 1に戻す。
                        //もしかしたら後で改造が必要かも？（単純に１ではすぐに実行しちゃうかも？）
                        list[RunNo].StepNo = 1;
                    }
                    //まずはMessageIfで調査
                    list[RunNo].CheckEvent(doukiCmdFlg, this, RunNo, 1, RequestID, DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID);
                    //次にErrorEndInfoIfで調査
                    if (list[RunNo].CheckEvent(doukiCmdFlg, this, RunNo, 2, RequestID, DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID) != true)
                    {
                        //次に継続条件にKeizokuInfoIfで調査
                        if (list[RunNo].CheckEvent(doukiCmdFlg, this, RunNo, 3, RequestID, DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID) != true)
                        {
                            //最後にEndInfoIfで調査
                            list[RunNo].CheckEvent(doukiCmdFlg, this, RunNo, 4, RequestID, DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID);
                        }
                    }
                }
            }
        }
    }
    [Serializable()]
    public class CmdClass
    {
        public int SendRequestID = 0;//実行時の送信Request番号
        public int StepNo = 0;       //0=BeforeIfを使う　1=EndInfoIf/ErrorEndInfoIf/MessageIf/KeizokuInfoIfを使う   2=KeizokuInfoIfでコマンドが実行された　　3=終了している
        public List<IfClass> BeforeIf = new List<IfClass>();    //コマンドを実行するための前提条件
        public List<IfClass> KeizokuInfoIf = new List<IfClass>();//コマンドを継続するための条件
        public List<IfClass> EndInfoIf = new List<IfClass>();    //コマンドを正常終了するための条件
        public List<IfClass> ErrorEndInfoIf = new List<IfClass>();//コマンドを異常終了するための条件
        public List<IfClass> MessageIf = new List<IfClass>();    //コマンドの状態遷移で表示するためのメッセージ
        public String HyoujiName = "コマンド名";  //パターン作成時に分かりやすいような仮の名前です。ここでしか使われません

        public CmdClass()
        {

        }

        public CmdClass(CmdClass source)
        {
            SendRequestID = source.SendRequestID;
            StepNo = source.StepNo;

            int a = 0;
            for (a = 0; a < source.BeforeIf.Count; a++)
            {
                BeforeIf.Add(new IfClass(source.BeforeIf[a]));
            }
            for (a = 0; a < source.KeizokuInfoIf.Count; a++)
            {
                KeizokuInfoIf.Add(new IfClass(source.KeizokuInfoIf[a]));
            }
            for (a = 0; a < source.EndInfoIf.Count; a++)
            {
                EndInfoIf.Add(new IfClass(source.EndInfoIf[a]));
            }
            for (a = 0; a < source.ErrorEndInfoIf.Count; a++)
            {
                ErrorEndInfoIf.Add(new IfClass(source.ErrorEndInfoIf[a]));
            }
            for (a = 0; a < source.MessageIf.Count; a++)
            {
                MessageIf.Add(new IfClass(source.MessageIf[a]));
            }

            HyoujiName = source.HyoujiName;
        }

        ~CmdClass()
        {
            Dispose();
        }
        public void Dispose()
        {
            BeforeIf.Clear();
            KeizokuInfoIf.Clear();
            EndInfoIf.Clear();
            ErrorEndInfoIf.Clear();
            MessageIf.Clear();
        }
        /// <summary>
        /// 条件式から次の実行を行うかどうかの判断を行う
        /// 戻り値　true=条件に合って次にシーケンスが移った　 false=条件に合わず無視された
        /// </summary>
        /// <param name="Owner">SequenceClassのオーナー</param>
        /// <param name="RunNo">実行された時の番号記憶用</param>
        /// <param name="CheckNo">>0=BeforeIf 1=MessageIf 2=ErrorEndInfoIf 3=KeizokunfoIf 4=EndInfoIfを使用</param>
        /// <param name="RequestID">返ってきたEventMessageのdwRequestID</param>
        /// <param name="DLL_Status">現在のDLLステータス</param>
        /// <param name="EventMessage_ErrorCodeID">返ってきたEventMessageのdwErrorCodeを文字列変換したもの</param>
        /// <param name="EventMessage_MessageID">返ってきたEventMessageのdwMessageIDを文字列変換したもの</param>
        /// <returns></returns>
        public bool CheckEvent(bool doukiCmdFlg, SequenceClass OwnerP, int RunNo, int CheckNo, int RequestID, String DLL_Status, String EventMessage_ErrorCodeID, String EventMessage_MessageID)
        {
            Trace.WriteLine("RunNo=" + RunNo.ToString() + " CheckNo=" + CheckNo.ToString() + " SendRequestID=" + SendRequestID + " RequestID=" + RequestID + " DLL_Status=" + DLL_Status + " ErrorCodeID=" + EventMessage_ErrorCodeID + " MessageID=" + EventMessage_MessageID);
            bool ret = false;
            List<IfClass> p = (CheckNo == 0 ? BeforeIf : (CheckNo == 1 ? MessageIf : (CheckNo == 2 ? ErrorEndInfoIf : (CheckNo == 3 ? KeizokuInfoIf : EndInfoIf))));
            //まず現状の条件に当てはまるかどうかを見てみる
            if (p.Count == 0)
            {
                //条件設定がない場合、とりあえずぬける
                //if (CheckNo==0 || CheckNo==4)//0=BeforeIf 4=EndInfoIf
                //{
                //    Trace.WriteLine("パターン設定が間違えています");
                //    OwnerP.MessageEvent_Sub( 2, "パターン設定が間違えています" + (CheckNo==0?"実施条件がない！！つまり実施コマンドがない。":"終了条件の設定がないため終われない！！"),
                //                    "Red", DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID);
                //}
                //else
                {
                    //1=MessageIf 2=ErrorEndInfoIf 3=KeizokuInfoIf
                    //ここでCheckNo=4　//終了条件の時かつ同期コマンド完了処理を実施する
                    if (doukiCmdFlg == true && CheckNo == 4)
                    {
                        //RunNoをカウントアップ
                        OwnerP.RunNo = RunNo + 1;
                        //まだ次のコマンドがある場合は、次のコマンドを実行　ない場合は上位に完了通知
                        if (OwnerP.RunNo >= OwnerP.GetCmdClassCount())
                        {
                            //次のコマンドがない場合は、上位に完了通知イベント
                            Trace.WriteLine("ｼｰｹﾝｽ完了");
                            OwnerP.CompleteMessage_Sub(false);
                        }
                        else
                        {
                            Trace.WriteLine("次のコマンド実行");
                            //次のコマンドがある場合は、次のコマンドを実行
                            OwnerP.ChangeStatus(false, OwnerP.GetOwnerRequestID(), OwnerP.GetOwnerDLL_Status(), /*OwnerP.GetOwner*/EventMessage_ErrorCodeID/*()*/, /*OwnerP.GetOwner*/EventMessage_MessageID/*()*/);
                        }
                        return true;
                    }
                }
                return false;
            }
            else
            {
                bool endCmdFlg = false;
                bool endCmdErrorFlg = false;
                //条件は数分実行
                for (int a = 0; a < p.Count; a++)//条件OR式のﾁｪｯｸ
                {
                    bool r = false;
                    //条件クラスのループで条件が満たされているかどうかチェックする
                    if (p[a].StatusInfoList.Count == 0)
                    {
                        //条件設定がない場合は条件が満たされたと考える
                        r = true;
                        Trace.WriteLine("条件設定がないので条件が満たされた");
                    }
                    else
                    {
                        bool r2 = true;
                        //条件があっても、RunRule が　//0=条件達成時のみ実行　1=とにかく実行 2=不一致なら実施せず終了
                        if (p[a].RunRule == 0 || p[a].RunRule == 2)
                        {
                            for (int b = 0; b < p[a].StatusInfoList.Count; b++)//条件AND式のﾁｪｯｸ
                            {
                                if (r2 == false) break;
                                //どちらのメッセージを使うか？
                                if (p[a].StatusInfoList[b].UseInfo == 0)
                                {
                                    //CheckNo = 0なら送信だからそもそもIDをみてもしょうがないので無視
                                    //UseRequestID = 1;             //0=リクエストID=0も有効  1=対応のリクエストIDのみ有効
                                    //RequestIDは0か送ったやつと一致か？
                                    if (SendRequestID != 0 && ((p[a].StatusInfoList[b].UseRequestID == 0 ? (RequestID != 0) : true) && RequestID != SendRequestID))
                                    {
                                        r2 = false;
                                    }
                                    else
                                    {
                                        //EventMessage_ErrorCodeID = "";//WindowsメッセージのイベントのLParamのErrorCodeID
                                        //EventMessage_MessageID = "";  //WindowsメッセージのイベントのLParamのMessage
                                        if (p[a].StatusInfoList[b].EventMessage_ErrorCodeID != EventMessage_ErrorCodeID ||
                                            p[a].StatusInfoList[b].EventMessage_MessageID != EventMessage_MessageID)
                                        {
                                            r2 = false;
                                        }
                                    }
                                }
                                else if (p[a].StatusInfoList[b].UseInfo == 1)
                                {
                                    //ErrorCodeはすべてひっかける
                                    if (EventMessage_ErrorCodeID.IndexOf("GLY_ERROR") == -1)
                                    {
                                        //含まれない
                                        r2 = false;
                                        //break;
                                    }
                                    else
                                    {
                                        Trace.WriteLine("ErrorCodeIDにエラーが含まれる");
                                    }
                                }
                                else if (p[a].StatusInfoList[b].UseInfo == 2)
                                {
                                    //DLL_Status = "";              //DLLのステータスを使用
                                    if (p[a].StatusInfoList[b].DLL_Status != DLL_Status)
                                    {
                                        r2 = false;
                                    }
                                }
                            }
                        }
                        else if (p[a].RunRule == 1)
                        {
                            //強制実行
                            r2 = true;
                            Trace.WriteLine("強制実行");
                        }
                        //条件はすべて満たされた
                        if (r2 == true)
                        {
                            r = true;
                        }
                    }
                    //条件が満たされていた場合
                    if (r == true)
                    {
                        switch (CheckNo)
                        {
                            case 0://Before
                                StepNo = 1; //StepNo = 0 ⇒ 1
                                //もしEndWaitRule = 1ならここで終了となる
                                if (p[a].EndWaitRule != 0)
                                {
                                    StepNo = 3; //StepNo = 1 ⇒ 3
                                    endCmdFlg = true;
                                }
                                break;
                            case 1://MessageIf
                                //StepNo = 1; //StepNo = 1 ⇒ 1
                                break;
                            case 2://ErrorEndInfoIf
                                //StepNo = 1; //StepNo = 1 ⇒ 1
                                endCmdErrorFlg = true;
                                break;
                            case 3://KeizokuInfoIf
                                StepNo = 2; //StepNo = 1 ⇒ 1
                                break;
                            case 4://EndInfoIf
                                StepNo = 3; //StepNo = 1 ⇒ 3
                                endCmdFlg = true;
                                break;
                        }

                        Trace.WriteLine("条件は満たされた Sleep=" + p[a].StopTimer.ToString() + "ms");

                        ret = true; //1個でも実行されたら完了になる
                        //設定による時間待ち
                        int start = System.Environment.TickCount;          // ミリ秒単位で経過時間を取得
                        while ((System.Environment.TickCount - start) < p[a].StopTimer)
                        {
                            System.Windows.Forms.Application.DoEvents();
                            System.Threading.Thread.Sleep(1);
                        }
                        Trace.WriteLine("Sleep終了");

                        //まずはメッセージが設定されていればメッセージ表示
                        if (p[a].MessageString != "" || p[a].MessageColor != "")
                        {
                            //ただし下記のGLY_WriteTraceコマンドのときは送らない
                            if (p[a].CmdName.IndexOf("GLY_WriteTrace") == -1)
                            {
                                OwnerP.MessageEvent_Sub(p[a].UnitRowNo, p[a].MessageString, p[a].MessageColor,
                                                    DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID);
                            }
                            else
                            {
                                OwnerP.CmdMessage_Change_Sub(p[a].MessageString);
                            }
                        }
                        //コマンドが指定されていればコマンド実行し、StepNoのカウントアップ及び、条件によっては上位のRunNoのカウントアップ
                        if (p[a].CmdName != "")
                        {
                            Trace.WriteLine("コマンド送信 : " + p[a].CmdName);
                            int doukiCmd = p[a].EndWaitRule;
                            OwnerP.Before2Hidouki = OwnerP.Before1Hidouki;
                            OwnerP.Before1Hidouki = (doukiCmd == 1 ? false : true);
                            bool result = OwnerP.CmdSend_Sub(p[a].CmdName, p[a].EndWaitRule, RequestID, DLL_Status, EventMessage_ErrorCodeID, EventMessage_MessageID);
                            if (!result)
                            {
                                endCmdErrorFlg = true;
                            }
                            else
                            {
                                //もしここで、同期ﾌﾗｸﾞがたっていて、2個目以降の処理で、かつ1つ前に非同期処理が入っているならば速攻でリターンする
                                if (doukiCmd == 1 && OwnerP.Before2Hidouki) return true;
                                //もしCheckNo=0で終了条件がないならばすぐにreturn
                                if (CheckNo == 0 && EndInfoIf.Count == 0) return true;
                            }
                        }
                        else
                        {
                        }
                        break;
                    }
                    else
                    {
                        Trace.WriteLine("条件はみたされていない");
                        //不一致なら実施せず終了だった場合
                        if (p[a].RunRule == 2)
                        {
                            Trace.WriteLine("不一致なので実施せず終了 : " + p[a].CmdName);
                            StepNo = 3; //StepNo = 1 ⇒ 3
                            endCmdFlg = true;
                        }
                    }
                }
                //ここを通るのはcase 2://ErrorEndInfoIfの時のみ
                if (endCmdErrorFlg == true)
                {
                    Trace.WriteLine("エラー有り。画面エラー更新イベント送信");
                    OwnerP.CompleteMessage_Sub(true);
                }
                //ここを通るのはcase 4://EndInfoIfの時とRunRule=2不一致なら実施せず終了のみ
                else if (endCmdFlg == true)
                {
                    //RunNoをカウントアップ
                    OwnerP.RunNo = RunNo + 1;
                    //まだ次のコマンドがある場合は、次のコマンドを実行　ない場合は上位に完了通知
                    if (OwnerP.RunNo >= OwnerP.GetCmdClassCount())
                    {
                        //次のコマンドがない場合は、上位に完了通知イベント
                        Trace.WriteLine("ｼｰｹﾝｽ完了");
                        OwnerP.CompleteMessage_Sub(false);
                    }
                    else
                    {
                        Trace.WriteLine("次のコマンド実行");
                        //次のコマンドがある場合は、次のコマンドを実行
                        OwnerP.ChangeStatus(false, OwnerP.GetOwnerRequestID(), OwnerP.GetOwnerDLL_Status(), /*OwnerP.GetOwner*/EventMessage_ErrorCodeID/*()*/, /*OwnerP.GetOwner*/EventMessage_MessageID/*()*/);
                    }
                }
            }
            return ret;
        }
    }
    [Serializable()]
    public class IfClass
    {
        public List<IfStatusInfo> StatusInfoList = new List<IfStatusInfo>();//実行する条件(登録された条件すべてが満たされた場合に下記のコマンドが実行される)
        public int StopTimer = 0;
        public String HyoujiName = "条件";   //パターン作成時に分かりやすいような仮の名前です。ここでしか使われません
        public int RunRule = 1;              //0=条件達成時のみ実行　1=とにかく実行　2=条件不一致で実施せず次へ
        public int UnitRowNo = 2;         //画面の0=ユニット情報のところ　1=エラー情報のところ　2=その他のところ　に表示
        public String MessageString = "";    //上記条件に当てはまった時のメッセージ
        public String MessageColor = "";     //上記条件に当てはまった時のメッセージの色
        //      public int RunFlg = 0;               //0=下記のコマンドが1回実行されている　1=下記のコマンドは実行されていない
        public String CmdName = "";          //実行するコマンド名
        public int EndWaitRule = 0;          //0=非同期　　　1=同期

        public IfClass()
        {
        }

        public IfClass(IfClass source)
        {
            int a = 0;
            for (a = 0; a < source.StatusInfoList.Count; a++)
            {
                StatusInfoList.Add(new IfStatusInfo(source.StatusInfoList[a]));
            }

            StopTimer = source.StopTimer;
            HyoujiName = source.HyoujiName;   //パターン作成時に分かりやすいような仮の名前です。ここでしか使われません
            RunRule = source.RunRule;              //0=条件達成時のみ実行　1=とにかく実行　2=条件不一致で実施せず次へ
            UnitRowNo = source.UnitRowNo;         //画面の0=ユニット情報のところ　1=エラー情報のところ　2=その他のところ　に表示
            MessageString = source.MessageString;    //上記条件に当てはまった時のメッセージ
            MessageColor = source.MessageColor;     //上記条件に当てはまった時のメッセージの色
            CmdName = source.CmdName;          //実行するコマンド名
            EndWaitRule = source.EndWaitRule;          //0=非同期　　　1=同期
        }

        ~IfClass()
        {
            Dispose();
        }
        public void Dispose()
        {
            StatusInfoList.Clear();
        }
    }
    [Serializable()]
    public class IfStatusInfo
    {
        public int UseInfo = 0;                     //0=EventMessageを使用する　1=EventMessageのErrorCodeIDに"GLY_ERROR"が含まれる場合引っ掛ける　2=DLL_Statusを使用する
        public String EventMessage_ErrorCodeID = "";//WindowsメッセージのイベントのLParamのErrorCodeID
        public String EventMessage_MessageID = "";  //WindowsメッセージのイベントのLParamのMessage
        public String DLL_Status = "";              //DLLのステータスを使用
        public int UseRequestID = 1;             //0=リクエストID=0も有効  1=対応のリクエストIDのみ有効

        public IfStatusInfo()
        {
        }

        public IfStatusInfo(IfStatusInfo source)
        {
            UseInfo = source.UseInfo;                     //0=EventMessageを使用する　1=EventMessageのErrorCodeIDに"GLY_ERROR"が含まれる場合引っ掛ける　2=DLL_Statusを使用する
            EventMessage_ErrorCodeID = source.EventMessage_ErrorCodeID;//WindowsメッセージのイベントのLParamのErrorCodeID
            EventMessage_MessageID = source.EventMessage_MessageID;  //WindowsメッセージのイベントのLParamのMessage
            DLL_Status = source.DLL_Status;              //DLLのステータスを使用
            UseRequestID = source.UseRequestID;             //0=リクエストID=0も有効  1=対応のリクエストIDのみ有効
        }

        ~IfStatusInfo()
        {
            Dispose();
        }
        public void Dispose()
        {
        }
    }
}
