﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Portread
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Portread(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                string portinfo = CmdP.Parameter;               //パラメータの欄から文字列を取得する
                string[] portData = portinfo.Split(',');        //カンマ区切りで分割して配列に格納する

                byte[] addr = new byte[portData.Length / 2];
                byte[] bit = new byte[portData.Length / 2];

                for (int i=0; i < (portData.Length / 2); i++)
                { 
                    addr[i] = byte.Parse(portData[2 * i]);
                    bit[i] = byte.Parse(portData[2 * i + 1]);
                }
                int nowVal = 0;

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);   //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                //ポートリードコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASportread);       //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                if (err == false)
                {
                    byte[] ReceiveData;
                    for (int i = 0; i < (portData.Length / 2); i++)
                    {
                        bool Firstflg = false;
                        do
                        {
                            if (OwnerP.ForceStopFlg)
                            {
                                err = true;
                                break;
                            }
                            //ＲＡＳセンスコマンド
                            data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);  //コマンド（データ長０のもの）
                            SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                            recv = OwnerP.Send(data, 1500);         //送信
                            ReceiveData = OwnerP.RecvCheckAndGetData(recv);             //recvからデータだけ取り出す
                            if (ReceiveData == null)
                            {
                                err = true;
                                OwnerP.GetErrorByRASsense();
                                break;  //whileを抜ける
                            }
                            if (Firstflg == false)
                            {
                                nowVal = ReceiveData[addr[i]] & bit[i];
                                Firstflg = true;
                            }
                        } while (nowVal == (ReceiveData[addr[i]] & bit[i]));            //対象ポートデータが変わらない間は継続
                        if (err == true) { break; }
                    }

                    //ＲＡＳ継続動作終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);           //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);                 //送信
                    if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);        //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
