﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

//「機種毎に変更必要」と書かれている部分を修正のこと
namespace Simulator
{
    public partial class SQMain : Form
    {
        //通信セット
        private SgNet.COM.Comm_s.Sio_s SioRecvP = null;
        private List<byte[]> RecvDataRecv = new List<byte[]>();
        private List<int> RecvInfoRecv = new List<int>();
        private byte[] RecvDataBufRecv = new byte[65536];
        private int RecvDataSizeRecv = 0;

        //タイムアウト用タイマー
        System.Threading.TimerCallback TimeOutEventRecv;
        System.Threading.Timer TimeOutTimerRecv;
//        int TimeOutTimeRecv = 1000;

        /// <summary>
        /// オープンフラグ
        /// </summary>
        public bool OpenFlgRecv = false;

        //***********************************************************************************************
        #region 通信処理

        /// <summary>
        /// オープン
        /// </summary>
        /// <param name="ComName">COM名　例："COM1"</param>
        /// <param name="boudrate">ボーレート</param>
        /// <param name="parity">パリティ</param>
        /// <param name="dataLen">データ長</param>
        /// <param name="stopbits">ストップビット</param>
        public void SioRecvOpen(String ComName, int boudrate, System.IO.Ports.Parity parity, int dataLen, System.IO.Ports.StopBits stopbits)
        {
            //COMポートのオープン
            try
            {
                //開く
                SioRecvP = new SgNet.COM.Comm_s.Sio_s(ComName, boudrate, parity, dataLen, stopbits);
                SioRecvP.RecvEventFunc += new SgNet.COM.Comm_s.Sio_s.RecvEvent(this.RecvEventRecv);

                //タイムアウト用のイベント追加
                TimeOutEventRecv = new System.Threading.TimerCallback(TimeOutClockRecv);
                TimeOutTimerRecv = new System.Threading.Timer(TimeOutEventRecv, null, -1, -1);
                OpenFlgRecv = true;
                return;
            }
            catch (Exception e)
            {
                MessageBox.Show(this, e.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
        }

        //ポートのクローズ
        private bool SioRecvClose()
        {
            //閉じる
            if (SioRecvP != null)
            {
                SioRecvP.Dispose();
                SioRecvP = null;
            }
            return true;
        }

        //**********************************************************

        //受信イベント ※ここでデータの長さの正しさなどを精査してRecvCmdを読み出す
        private void RecvEventRecv(byte[] recvData)
        {
            if (recvData == null) return;       //ないと思うけど
            if (recvData.Length == 0) return;   //ないと思うけど

            int len = recvData.Length;
            //データをバッファにコピー
            Array.Copy(recvData, 0, RecvDataBufRecv, RecvDataSizeRecv, len);
            int startaddr = RecvDataSizeRecv;
            RecvDataSizeRecv += len;

            //受信データの分解
            while (true)
            {
                //タイムアウトを一旦停止する
//                TimeOutTimerRecv.Change(-1, -1);          //停止

                //機種毎に変更必要   ***************************************
                //データの長さ確認を行う　　　　
                int okLen;
                if (RecvDataBufRecv[0] == ((byte)CtrlChar.STX | 0xF0))
                {
                    if ((RecvDataBufRecv[1] == 0x21) || (RecvDataBufRecv[1] == 0x23)
                     || (RecvDataBufRecv[1] == 0x41) || (RecvDataBufRecv[1] == 0x43))
                    {   //入金、出金データコマンドなので、サイズ４を入れる
                        okLen = 4;
                    }
                    else if ((RecvDataBufRecv[1] == 0x22) || (RecvDataBufRecv[1] == 0x42))
                    {   //入金データ、出金データと仮定　ETXを検出しにいく
                        okLen = 2000;   //暫定で入金データのサイズ１８６７を超える値(2000)を入れておく
                        for (int a = startaddr; a < RecvDataSizeRecv; a++)
                        {
                            if (RecvDataBufRecv[a] == ((byte)CtrlChar.ETX | 0xF0))      //ETXを検出した時点でokLenを更新
                            {
                                okLen　= a + 1;
                                break;
                            }
                        }
                    }
                    else
                    {   //該当しない場合は読み捨て
                        okLen = 1;
                    }
                }
                else
                {   //STXでない場合は１キャラクタレスポンスとみなして読み捨て
                    okLen = 1;
                }
                //**********************************************************

                //読み取り終了の条件式
                if (okLen <= RecvDataSizeRecv)
                {
                    //データがそろった時
                    //イベントで上位に通知する
                    byte[] d = null;
                    if (okLen != 0)
                    {
                        d = new byte[okLen];
                        Array.Copy(RecvDataBufRecv, d, okLen);
                    }
                    RecvDataSizeRecv -= okLen;
                    //正常受信送信
                    //RecvCmd(1, d);
                    if (RecvDataSizeRecv != 0)
                    {
                        //データを前に詰める
                        for (int a = 0; a < RecvDataSizeRecv; a++)
                        {
                            RecvDataBufRecv[a] = RecvDataBufRecv[okLen + a];
                        }
                    }
                    RecvCmdRecv(1, d);
                    //if (RecvDataSizeRecv == -1) break;

                    byte[] recvDataRecv = RecvDataRecv[0];
                    RecvDataRecv.Clear();
                    if (recvDataRecv[1] == 0x42)
                    {   //出金データ
                        byte[] buf = new byte[1024];
                        int cnt = 0;
                        for (int a = 2; a < recvDataRecv.Length; a++)
                        {
                            if (recvDataRecv[a] == 0xF0)    //DLEの場合はDLEを除いて次のデータを加工する（減った分は詰める）
                            {
                                buf[cnt] = (byte)(recvDataRecv[a + 1] | 0x80);
                                a++;
                            }
                            else                            //それ以外はそのまま
                            {
                                buf[cnt] = recvDataRecv[a];
                            }
                            cnt++;
                        }
                        SavevalueBin("skdata.usa", buf, true);
                    }
                    else if (recvDataRecv[1] == 0x22)
                    {   //入金データ
                        byte[] buf = new byte[4716];
                        int cnt = 128;                      //ＢＩ情報の開始アドレス
                        for (int a = 2; a < recvDataRecv.Length; a++)
                        {
                            if (recvDataRecv[a] == 0xF0)    //DLEの場合はDLEを除いて次のデータを加工する（減った分は詰める）
                            {
                                buf[cnt] = (byte)(recvDataRecv[a + 1] | 0x80);
                                a++;
                            }
                            else                            //それ以外はそのまま
                            {
                                buf[cnt] = recvDataRecv[a];
                            }
                            cnt++;
                            if (cnt == (128 + 64)) { cnt = 936; }       //データ１の開始アドレス
                            if (cnt == (936 + 900)) { cnt = 3636; }     //データ２の開始アドレス
                        }
                        SavevalueBin("nkdata", buf, true);
                    }
                }
                else
                {
                    //データがそろっていない時
                    //タイムアウトタイマーを起動する
//                    TimeOutTimerRecv.Change(TimeOutTimeRecv, -1);//起動
                    break;
                }
            }
        }

        //受信データチェック
        private void RecvCmdRecv(int recvFlg/*1=正常ﾚｽﾎﾟﾝｽ 0=相手からの勝手なﾚｽﾎﾟﾝｽ -1=ﾀｲﾑｱｳﾄ*/, byte[] data)
        {
            RecvDataRecv.Add(data);
            RecvInfoRecv.Add(recvFlg);
        }

        //タイムアウト用イベント
        private void TimeOutClockRecv(object o)
        {
            //タイムアウト用タイマーをストップ
            TimeOutTimerRecv.Change(-1, -1);

            //イベントで上位に上げる
            byte[] d = null;
            if (RecvDataSizeRecv > 0)
            {
                d = new byte[RecvDataSizeRecv];
                Array.Copy(RecvDataBufRecv, d, RecvDataSizeRecv);
                RecvDataSizeRecv = 0;
            }
            RecvCmdRecv(-1, d);
        }

        #endregion 通信処理
        //***********************************************************************************************
    }
}
