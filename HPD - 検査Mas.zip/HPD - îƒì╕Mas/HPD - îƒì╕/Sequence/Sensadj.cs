﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Sensadj
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Sensadj(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        string[] Sensname = { "PS4", "PS5", "PS6", "PS8", "PS9", "PS10", "PS11", "PS14", "PS1A", "PS1B", "PS12", "PS15", "PS16"};
        string[] SensnameInfo0 = { "PS6", "PS4", "PS11", "PS9",  "PS12", "PS1A", "", "PS16", "", "" };
        string[] SensnameInfo1 = { "PS8", "PS5", "PS14", "PS10", "PS15", "PS1B", "", "", "", ""};

        //ＲＡＳセンスの状態enum
        private enum SensadjCond { STOP, OPERATE }
        private enum SensadjResult { NORMAL_END, ERROR_END }
        private enum SensadjInfo { ADJ_DONE, ADJ_YET, ADJ_NOT }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                int sensnum = 13;
                int[] sensval_resp = new int[sensnum];
                int[] sensval_min = new int[sensnum];
                int[] sensval_max = new int[sensnum];

                string param = CmdP.Parameter;                                  //パラメータの欄から文字列を取得する
                string[] paramDivide = param.Split(',');                        //カンマ区切りで分割して配列に格納する
                if (paramDivide.Length != sensnum)
                {
                    err = true;
                    switch (OwnerP.Lang)
                    {
                        case "CN":
                            OwnerP.ChangeInfo(0, 0, "参数异常（传感器数）", System.Drawing.Color.Red);
                            break;
                        case "JP":
                            OwnerP.ChangeInfo(0, 0, "パラメータ異常（センサ数）", System.Drawing.Color.Red);
                            break;
                    }
                    break;
                }
                //パラメータから読み込み（しきい値を分割）
                for (int i = 0; i < sensnum; i++)
                {
                    string[] Sensdt = paramDivide[i].Split(':');                //コロン区切りで分割して配列に格納する
                    if (Sensdt.Length != 2)
                    {
                        err = true;
                        switch (OwnerP.Lang)
                        {
                            case "CN":
                                OwnerP.ChangeInfo(0, 0, "参数异常（阈值）", System.Drawing.Color.Red);
                                break;
                            case "JP":
                                OwnerP.ChangeInfo(0, 0, "パラメータ異常（しきい値）", System.Drawing.Color.Red);
                                break;
                        }
                        break;  //forを抜ける
                    }
                    else
                    {
                        sensval_min[i] = int.Parse(Sensdt[0]);
                        sensval_max[i] = int.Parse(Sensdt[1]);
                    }
                }
                if (err == true) { break; }

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                //センサ自動調整コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsensadj);                    //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                byte[] ReceiveData;
                if (err == false)
                {
                    do
                    {
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);                                         //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }
                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                    } while (ReceiveData[1] == (byte)SensadjCond.OPERATE);

                    if (err == false)
                    {
                        if (ReceiveData[4] == (byte)SensadjResult.ERROR_END)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                        for (int s = 10; s < 20; s++)
                        {
                            if ((ReceiveData[s] & 0x03) == (byte)SensadjInfo.ADJ_YET)
                            {
                                err = true;
                                OwnerP.ChangeInfo(0, 0, "未完了 : " + SensnameInfo0[s - 10], System.Drawing.Color.Red);
                                OwnerP.GetErrorByRASsense();
                                break;
                            }
                            if (((ReceiveData[s] & 0x0C) >> 2) == (byte)SensadjInfo.ADJ_YET)
                            {
                                err = true;
                                OwnerP.ChangeInfo(0, 0, "未完了 : " + SensnameInfo1[s - 10], System.Drawing.Color.Red);
                                OwnerP.GetErrorByRASsense();
                                break;
                            }
                        }
                    }
                }

                if (err == false)
                {
                    //センサデータリードコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsensread);               //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);                                             //送信
                    ReceiveData = OwnerP.RecvCheckAndGetData(recv);                             //recvからデータだけ取り出す

                    if (ReceiveData != null)
                    {
                        //調整値を取得
                        for (int i = 0; i < sensnum; i++)
                        {
                            //CharMerge(a,b)：データ２バイトの下部４ビットずつをまとめて１バイトにする
                            sensval_resp[i] = OwnerP.CharMerge(ReceiveData[2 * i + 2], ReceiveData[2 * i + 3]);
                        }
                        //調整値をファイル保存
                        List<string[]> SensData = new List<string[]>();
                        string[][] SensDataVal = new string[sensnum][];
                        string DispSensData = "";
                        for (int i = 0; i < sensnum; i++)
                        {
                            string[] SensValue = new string[2];
                            SensDataVal[i] = SensValue;
                            SensDataVal[i][0] = Sensname[i];
                            SensDataVal[i][1] = sensval_resp[i].ToString();
                            SensData.Add(SensDataVal[i]);
                            DispSensData += SensDataVal[i][0] + "\t" + SensDataVal[i][1] + "\r\n";
                        }
                        OwnerP.ChangeInfo(2, 0, DispSensData, System.Drawing.Color.White);
                        OwnerP.Savevalue("Sensadj.csv", SensData);
                    }
                    else
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)               //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                if (err == false)
                {
                    //データ比較
                    for (int i = 0; i < sensnum; i++)
                    {
                        if ((sensval_min[i] > sensval_resp[i]) || (sensval_resp[i] > sensval_max[i]))
                        {
                            err = true;
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 0, "範圍外 : " + Sensname[i], System.Drawing.Color.Red);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 0, "範囲外 : " + Sensname[i], System.Drawing.Color.Red);
                                    break;
                            }
                            break;
                        }
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
