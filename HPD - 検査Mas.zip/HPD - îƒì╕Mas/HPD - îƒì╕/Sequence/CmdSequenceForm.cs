﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Simulator
{
    public partial class CmdSequenceForm : Form
    {
        public CmdSequenceForm(SequenceClass sequence)
        {
            InitializeComponent();
            Sequence = sequence;
        }
        public List<String> CommandList = new List<String>();
        public List<String> DLLStatusList = new List<String>();
        public List<String> dwErrorCodeList = new List<String>();
        public List<String> dwMessageIDList = new List<String>();

        IfClass CopyBeforeIf = null;
        IfClass CopyKeizokuInfoIf = null;
        IfClass CopyEndInfoIf = null;
        IfClass CopyErrorEndInfoIf = null;
        IfClass CopyMessageIf = null;

        SequenceClass Sequence = new SequenceClass();

        private void button3_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel <= 0) return;
            String str = listBox1.Items[sel].ToString();
            listBox1.Items.RemoveAt(sel);
            listBox1.Items.Insert( sel-1, str );
            Sequence.CmdClassChange(sel, sel - 1);
            listBox1.SelectedIndex = sel - 1;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;
            if (sel == listBox1.Items.Count-1) return;
            String str = listBox1.Items[sel].ToString();
            listBox1.Items.RemoveAt(sel);
            listBox1.Items.Insert(sel + 1, str);
            Sequence.CmdClassChange(sel, sel + 1);
            listBox1.SelectedIndex = sel + 1;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;
            listBox1.Items.RemoveAt(sel);
            Sequence.CmdClassDelete(sel);
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
            listBox6.Items.Clear();
            textBox1.Text = "";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            CmdClass p = new CmdClass();

            IfClass p0 = new IfClass();
            p0.HyoujiName = "終了条件";
            p0.RunRule = 0;

            IfStatusInfo p1 = new IfStatusInfo();
            p1.UseInfo = 0;
            p1.UseRequestID = 1;
            p1.EventMessage_ErrorCodeID = "GLY_SUCCESS";
            p1.EventMessage_MessageID = "GLY_COMPLETE_MESSAGE";
            p0.StatusInfoList.Add(p1);
            p.EndInfoIf.Add(p0);

            IfClass p2 = new IfClass();
            p2.HyoujiName = "エラー条件";
            p2.RunRule = 0;

            IfStatusInfo p3 = new IfStatusInfo();
            p3.UseInfo = 1;
            p2.StatusInfoList.Add(p3);
            p.ErrorEndInfoIf.Add(p2);

            IfClass p4 = new IfClass();
            p4.HyoujiName = "エラー条件";
            p4.RunRule = 0;

            IfStatusInfo p5 = new IfStatusInfo();
            p5.UseInfo = 0;
            p5.UseRequestID = 0;
            p5.EventMessage_ErrorCodeID = "GLY_SUCCESS";
            p5.EventMessage_MessageID = "GLY_ERROR";
            p4.StatusInfoList.Add(p5);
            p.ErrorEndInfoIf.Add(p4);

            Sequence.CmdClassAdd(p);
            listBox1.Items.Add(p.HyoujiName);
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
            listBox6.Items.Clear();
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
            textBox1.Text = p.HyoujiName;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;
            CmdClass p = Sequence.GetCmdClass(sel);
            //画面のクリア
            textBox1.Text = p.HyoujiName;
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            listBox4.Items.Clear();
            listBox5.Items.Clear();
            listBox6.Items.Clear();
            //子画面の表示 
            int a;
            for (a = 0; a < p.BeforeIf.Count; a++)
            {
                listBox2.Items.Add(p.BeforeIf[a].HyoujiName);
            }
            for (a = 0; a < p.EndInfoIf.Count; a++)
            {
                listBox3.Items.Add(p.EndInfoIf[a].HyoujiName);
            }
            for (a = 0; a < p.ErrorEndInfoIf.Count; a++)
            {
                listBox4.Items.Add(p.ErrorEndInfoIf[a].HyoujiName);
            }
            for (a = 0; a < p.KeizokuInfoIf.Count; a++)
            {
                listBox5.Items.Add(p.KeizokuInfoIf[a].HyoujiName);
            }
            for (a = 0; a < p.MessageIf.Count; a++)
            {
                listBox6.Items.Add(p.MessageIf[a].HyoujiName);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0)
            {
                textBox1.Text = "";
                return;
            }
            CmdClass p = Sequence.GetCmdClass(sel);
            p.HyoujiName = textBox1.Text;
            listBox1.Items[sel] = (object)textBox1.Text;
        }
        //追加
        private void button7_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            IfClass p2 = new IfClass();
            p2.HyoujiName = "コマンド送信条件";
            p2.RunRule = 1;

            SettingForm2 dlg = new SettingForm2(this, p2, 0);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.BeforeIf.Add(dlg.ifClassBuf);
                listBox2.Items.Add(p2.HyoujiName);
                listBox2.SelectedIndex = listBox2.Items.Count - 1;
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            IfClass p2 = new IfClass();
            p2.HyoujiName = "終了条件";
            p2.RunRule = 0;

            IfStatusInfo p3 = new IfStatusInfo();
            p3.UseInfo = 0;
            p3.UseRequestID = 1;
            p3.EventMessage_ErrorCodeID = "GLY_SUCCESS";
            p3.EventMessage_MessageID = "GLY_COMPLETE_MESSAGE";
            p2.StatusInfoList.Add(p3);

            SettingForm2 dlg = new SettingForm2(this, p2, 1);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.EndInfoIf.Add(dlg.ifClassBuf);
                listBox3.Items.Add(p2.HyoujiName);
                listBox3.SelectedIndex = listBox3.Items.Count - 1;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            IfClass p2 = new IfClass();
            p2.HyoujiName = "エラー発生条件";
            p2.RunRule = 0;

            SettingForm2 dlg = new SettingForm2(this, p2, 2);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.ErrorEndInfoIf.Add(dlg.ifClassBuf);
                listBox4.Items.Add(p2.HyoujiName);
                listBox4.SelectedIndex = listBox4.Items.Count - 1;
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            IfClass p2 = new IfClass();
            p2.HyoujiName = "継続条件";
            p2.RunRule = 0;

            SettingForm2 dlg = new SettingForm2(this, p2, 3);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.KeizokuInfoIf.Add(dlg.ifClassBuf);
                listBox5.Items.Add(p2.HyoujiName);
                listBox5.SelectedIndex = listBox5.Items.Count - 1;
            }
        }
        private void button20_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            IfClass p2 = new IfClass();
            p2.HyoujiName = "メッセージ表示条件";
            p2.RunRule = 0;

            SettingForm2 dlg = new SettingForm2(this, p2, 4);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.MessageIf.Add(dlg.ifClassBuf);
                listBox6.Items.Add(p2.HyoujiName);
                listBox6.SelectedIndex = listBox6.Items.Count - 1;
            }
        }

        //削除
        private void button8_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox2.SelectedIndex;
            if (sel2 < 0) return;

            CmdClass p = Sequence.GetCmdClass(sel1);

            p.BeforeIf.RemoveAt(sel2);
            listBox2.Items.RemoveAt(sel2);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox3.SelectedIndex;
            if (sel2 < 0) return;

            CmdClass p = Sequence.GetCmdClass(sel1);

            p.EndInfoIf.RemoveAt(sel2);
            listBox3.Items.RemoveAt(sel2);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox4.SelectedIndex;
            if (sel2 < 0) return;

            CmdClass p = Sequence.GetCmdClass(sel1);

            p.ErrorEndInfoIf.RemoveAt(sel2);
            listBox4.Items.RemoveAt(sel2);
        }

        private void button18_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox5.SelectedIndex;
            if (sel2 < 0) return;

            CmdClass p = Sequence.GetCmdClass(sel1);

            p.KeizokuInfoIf.RemoveAt(sel2);
            listBox5.Items.RemoveAt(sel2);
        }
        private void button21_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox6.SelectedIndex;
            if (sel2 < 0) return;

            CmdClass p = Sequence.GetCmdClass(sel1);

            p.MessageIf.RemoveAt(sel2);
            listBox6.Items.RemoveAt(sel2);
        }
        //編集
        private void button9_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox2.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.BeforeIf[sel2];

            SettingForm2 dlg = new SettingForm2(this, p2, 0);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.BeforeIf[sel2] = dlg.ifClassBuf;
                listBox2.Items[sel2] = (object)dlg.ifClassBuf.HyoujiName;
            }
        }
        private void button12_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox3.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.EndInfoIf[sel2];

            SettingForm2 dlg = new SettingForm2(this, p2, 1);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.EndInfoIf[sel2] = dlg.ifClassBuf;
                listBox3.Items[sel2] = (object)dlg.ifClassBuf.HyoujiName;
            }
        }
        private void button15_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox4.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.ErrorEndInfoIf[sel2];

            SettingForm2 dlg = new SettingForm2(this, p2, 2);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.ErrorEndInfoIf[sel2] = dlg.ifClassBuf;
                listBox4.Items[sel2] = (object)dlg.ifClassBuf.HyoujiName;
            }
        }
        private void button16_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox5.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.KeizokuInfoIf[sel2];

            SettingForm2 dlg = new SettingForm2(this, p2, 3);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.KeizokuInfoIf[sel2] = dlg.ifClassBuf;
                listBox5.Items[sel2] = (object)dlg.ifClassBuf.HyoujiName;
            }
        }
        private void button19_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox6.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.MessageIf[sel2];

            SettingForm2 dlg = new SettingForm2(this, p2, 4);
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                p1.MessageIf[sel2] = dlg.ifClassBuf;
                listBox6.Items[sel2] = (object)dlg.ifClassBuf.HyoujiName;
            }
        }
        private void listBox2_DoubleClick(object sender, EventArgs e)
        {
            button9_Click(sender, e);
        }

        private void listBox3_DoubleClick(object sender, EventArgs e)
        {
            button12_Click(sender, e);
        }

        private void listBox4_DoubleClick(object sender, EventArgs e)
        {
            button15_Click(sender, e);
        }

        private void listBox5_DoubleClick(object sender, EventArgs e)
        {
            button16_Click(sender, e);
        }

        private void listBox6_DoubleClick(object sender, EventArgs e)
        {
            button19_Click(sender, e);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //debug******初期のファイルを作成するとき*************
            //SgNet.COM.Form_s.SaveString(Application.StartupPath + "\\FormString.ini", this);
            //****************************************************
            
            for (int a = 0; a < Sequence.GetCmdClassCount(); a++)
            {
                CmdClass p = Sequence.GetCmdClass(a);
                listBox1.Items.Add(p.HyoujiName);
            }

            String path;
            string A;
            System.IO.StreamReader reader;
            path = System.Windows.Forms.Application.StartupPath + "\\CmdList.txt";
            if (System.IO.File.Exists(path))
            {
                reader = new System.IO.StreamReader(path,
                                                                            System.Text.Encoding.GetEncoding("Shift_JIS"));
                while ((A = reader.ReadLine()) != null)
                {
                    CommandList.Add(A);
                }
                reader.Close();
            }
            path = System.Windows.Forms.Application.StartupPath + "\\DLLStatusList.txt";
            if (System.IO.File.Exists(path))
            {
                reader = new System.IO.StreamReader(path,
                                                                            System.Text.Encoding.GetEncoding("Shift_JIS"));
                while ((A = reader.ReadLine()) != null)
                {
                    DLLStatusList.Add(A);
                }
                reader.Close();
            }
            path = System.Windows.Forms.Application.StartupPath + "\\dwErrorCodeList.txt";
            if (System.IO.File.Exists(path))
            {
                reader = new System.IO.StreamReader(path,
                                                                            System.Text.Encoding.GetEncoding("Shift_JIS"));
                while ((A = reader.ReadLine()) != null)
                {
                    dwErrorCodeList.Add(A);
                }
                reader.Close();
            }
            path = System.Windows.Forms.Application.StartupPath + "\\dwMessageIDList.txt";
            if (System.IO.File.Exists(path))
            {
                reader = new System.IO.StreamReader(path,
                                                                            System.Text.Encoding.GetEncoding("Shift_JIS"));
                while ((A = reader.ReadLine()) != null)
                {
                    dwMessageIDList.Add(A);
                }
                reader.Close();
            }
        }

        private void button22_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;
            CmdClass copy = Sequence.GetCmdClass(sel);
            CmdClass paste = new CmdClass(copy);

            Sequence.CmdClassAdd(paste);
            listBox1.Items.Add(paste.HyoujiName);
        }

        private void button23_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox2.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.BeforeIf[sel2];

            CopyBeforeIf = new IfClass(p2);
        }

        private void button26_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox3.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.EndInfoIf[sel2];

            CopyKeizokuInfoIf = new IfClass(p2);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox4.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.ErrorEndInfoIf[sel2];

            CopyEndInfoIf = new IfClass(p2);
        }

        private void button30_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox5.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.KeizokuInfoIf[sel2];

            CopyErrorEndInfoIf = new IfClass(p2);
        }

        private void button32_Click(object sender, EventArgs e)
        {
            int sel1 = listBox1.SelectedIndex;
            if (sel1 < 0) return;

            int sel2 = listBox6.SelectedIndex;
            if (sel2 < 0) return;
            CmdClass p1 = Sequence.GetCmdClass(sel1);
            IfClass p2 = p1.MessageIf[sel2];

            CopyMessageIf = new IfClass(p2);
        }

        private void button24_Click(object sender, EventArgs e)
        {
            if( CopyBeforeIf == null) return;
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            p1.BeforeIf.Add(CopyBeforeIf);
            listBox2.Items.Add(CopyBeforeIf.HyoujiName);
            listBox2.SelectedIndex = listBox2.Items.Count - 1;
        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (CopyKeizokuInfoIf == null) return;
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            p1.KeizokuInfoIf.Add(CopyKeizokuInfoIf);
            listBox3.Items.Add(CopyKeizokuInfoIf.HyoujiName);
            listBox3.SelectedIndex = listBox3.Items.Count - 1;
        }

        private void button27_Click(object sender, EventArgs e)
        {
            if (CopyEndInfoIf == null) return;
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            p1.EndInfoIf.Add(CopyEndInfoIf);
            listBox4.Items.Add(CopyEndInfoIf.HyoujiName);
            listBox4.SelectedIndex = listBox4.Items.Count - 1;
        }

        private void button29_Click(object sender, EventArgs e)
        {
            if (CopyErrorEndInfoIf == null) return;
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            p1.ErrorEndInfoIf.Add(CopyErrorEndInfoIf);
            listBox5.Items.Add(CopyErrorEndInfoIf.HyoujiName);
            listBox5.SelectedIndex = listBox5.Items.Count - 1;
        }

        private void button31_Click(object sender, EventArgs e)
        {
            if (CopyMessageIf == null) return;
            int sel = listBox1.SelectedIndex;
            if (sel < 0) return;

            CmdClass p1 = Sequence.GetCmdClass(sel);
            p1.MessageIf.Add(CopyMessageIf);
            listBox6.Items.Add(CopyMessageIf.HyoujiName);
            listBox6.SelectedIndex = listBox6.Items.Count - 1;
        }
    }
}
