﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Simulator
{
    public partial class SettingForm3 : Form
    {
        public CmdSequenceForm OwnerP;
        public IfStatusInfo data;
        public String NameStr = "";
        public SettingForm3(CmdSequenceForm ownerP, IfStatusInfo p)
        {
            OwnerP = ownerP;
            data = (IfStatusInfo)DeepCopyClone((object)(p));
            InitializeComponent();
        }
        /// <summary>
        /// 対象オブジェクトのディープコピークローンを取得します。
        /// </summary>
        /// <typeparam name="T">対象オブジェクトの型</typeparam>
        /// <param name="target">コピー対象オブジェクトを指定します。</param>
        /// <returns>ディープコピーのクローンを返します。</returns>
        /// <remarks>このメソッドでディープコピーするには、対象クラスがシリアライズ可能である必要があります。</remarks>
        public T DeepCopyClone<T>(T target)
        {
            object clone = null;
            using (MemoryStream stream = new MemoryStream())
            {
                //対象オブジェクトをシリアライズ
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, target);
                stream.Position = 0;

                //シリアライズデータをデシリアライズ
                clone = formatter.Deserialize(stream);
            }
            return (T)clone;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked) data.UseInfo = 0;
            else if (radioButton2.Checked) data.UseInfo = 1;
            else if (radioButton3.Checked) data.UseInfo = 2;

            if (radioButton4.Checked) data.UseRequestID = 0;
            else if (radioButton5.Checked) data.UseRequestID = 1;

            if (comboBox2.SelectedIndex == -1) data.DLL_Status = "";
            else data.DLL_Status = comboBox2.Items[comboBox2.SelectedIndex].ToString();
            if (comboBox1.SelectedIndex == -1) data.EventMessage_ErrorCodeID = "";
            else data.EventMessage_ErrorCodeID = comboBox1.Items[comboBox1.SelectedIndex].ToString();
            if (comboBox3.SelectedIndex == -1) data.EventMessage_MessageID = "";
            else data.EventMessage_MessageID = comboBox3.Items[comboBox3.SelectedIndex].ToString();

            if (data.UseInfo == 0)
            {
                data.DLL_Status = "";
            }
            else if (data.UseInfo == 1)
            {
                data.DLL_Status = "";
                data.EventMessage_ErrorCodeID = "";
                data.EventMessage_MessageID = "";
            }
            else
            {
                data.EventMessage_ErrorCodeID = "";
                data.EventMessage_MessageID = "";
            }
            NameStr = GetNameStr(data);
            DialogResult = DialogResult.OK;
        }

        public String GetNameStr(IfStatusInfo classP)
        {
            String ss = "";
            if (classP.UseInfo == 0)
            {
                ss = classP.EventMessage_ErrorCodeID + "  /  " + classP.EventMessage_MessageID;
            }
            else if (classP.UseInfo == 1)
            {
                ss = "EventMessageのdwErrorCodeに[GLY_ERROR]が含まれる場合";
            }
            else
            {
                ss = classP.DLL_Status;
            }
            return ss;
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("");
            comboBox2.Items.Add("");
            comboBox3.Items.Add("");
            for (int a = 0; a < OwnerP.DLLStatusList.Count; a++)
            {
                comboBox2.Items.Add(OwnerP.DLLStatusList[a]);
            }
            for (int a = 0; a < OwnerP.dwErrorCodeList.Count; a++)
            {
                comboBox1.Items.Add(OwnerP.dwErrorCodeList[a]);
            }
            for (int a = 0; a < OwnerP.dwMessageIDList.Count; a++)
            {
                comboBox3.Items.Add(OwnerP.dwMessageIDList[a]);
            }
            switch (data.UseInfo)
            {
                case 0: radioButton1.Checked = true; groupBox1.Visible = false; break;
                case 1: radioButton2.Checked = true; groupBox1.Visible = false; groupBox2.Visible = false; break;
                case 2: radioButton3.Checked = true; groupBox2.Visible = false; break;
            }
            switch (data.UseRequestID)
            {
                case 0: radioButton4.Checked = true; break;
                case 1: radioButton5.Checked = true; break;
            }

            for (int a = 0; a < comboBox2.Items.Count; a++)
            {
                if(comboBox2.Items[a].ToString()==data.DLL_Status){
                    comboBox2.SelectedIndex = a;
                    break;
                }
            }
            for (int a = 0; a < comboBox1.Items.Count; a++)
            {
                if(comboBox1.Items[a].ToString()==data.EventMessage_ErrorCodeID){
                    comboBox1.SelectedIndex = a;
                    break;
                }
            }
            for (int a = 0; a < comboBox3.Items.Count; a++)
            {
                if (comboBox3.Items[a].ToString() == data.EventMessage_MessageID)
                {
                    comboBox3.SelectedIndex = a;
                    break;
                }
            }
        }

        private void radioButton1_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox2.Visible = true;
        }

        private void radioButton2_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            groupBox2.Visible = false;
        }

        private void radioButton3_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
            groupBox2.Visible = false;
        }
    }
}
