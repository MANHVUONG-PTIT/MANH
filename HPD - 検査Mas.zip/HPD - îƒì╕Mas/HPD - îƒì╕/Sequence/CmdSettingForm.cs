﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Simulator
{
    public partial class CmdSettingForm : Form
    {
        public Cmd SettingCmd = null;
        private Cmd BaseCmd = null;
        private int GridNo = 0;
        private bool GloryDLL = false;

        public CmdSettingForm(Cmd cmd, Cmd baseCmd, int gridNo, bool gloryDLL)
        {
            //パターン上での変更
            BaseCmd = baseCmd;
            SettingCmd = cmd;
            GridNo = gridNo;
            GloryDLL = gloryDLL;

            InitializeComponent();
        }

        public CmdSettingForm(Cmd cmd, int gridNo, bool gloryDLL)
        {
            //新規作成　またはベースの変更
            SettingCmd = cmd;
            GridNo = gridNo;
            GloryDLL = gloryDLL;

            InitializeComponent();
        }

        private void CmdSettingForm_Load(object sender, EventArgs e)
        {
            //debug******初期のファイルを作成するとき*************
            //SgNet.COM.Form_s.SaveString(Application.StartupPath + "\\FormString.ini", this);
            //****************************************************

            //画面のフォント・文字変更
            SgNet.COM.Form_s.LoadString(Application.StartupPath + "\\FormString.ini", this);
            
            textBox4.Text = SettingCmd.FileName;
            String seaquenceName = SettingCmd.SequenceName;
            String comment = SettingCmd.Comment;
            String parameter = SettingCmd.Parameter;
            
            if (GloryDLL == false)
            {
                button2.Enabled = false;
                button2.Visible = false;
                label4.Visible = false;
            }
            if (BaseCmd == null)
            {
                textBox3.Text = seaquenceName;
                textBox2.Text = comment;
                textBox1.Text = parameter;
            }
            else
            {
                button2.Enabled = false;
                button2.Visible = false;
                label4.Visible = false;
                textBox3.Enabled = false;
                textBox3.Text = (seaquenceName != "" ? seaquenceName : BaseCmd.SequenceName);
                textBox2.Text = (comment != "" ? comment : BaseCmd.Comment);
                textBox1.Text = (parameter != "" ? parameter : BaseCmd.Parameter);
            }

            if (BaseCmd == null || (GridNo != 4 && GridNo != 5 && GridNo != 6))
            {
                label2.Visible = false;
                dataGridView1.Visible = false;
            }
            else
            {
                //金種情報を更新する
                SgNet.COM.File_s.IniFile_s iniP = new SgNet.COM.File_s.IniFile_s(SgNet.COM.Dir_s.Path_s.StartupPath() + "\\Settings.ini");
                int kinsyuCount = iniP.ReadInt("Settings", "MoneyCount", 0);
                dataGridView1.ColumnCount = kinsyuCount;
                for (int i = 0; i < kinsyuCount; i++)
                {
                    dataGridView1.Columns[i].HeaderText = iniP.ReadString("Settings", "Money" + i.ToString(), "money" + i.ToString());
                    dataGridView1.Columns[i].SortMode = DataGridViewColumnSortMode.Programmatic;
                    if (i == 0) dataGridView1.RowCount = 1;
                    if (SettingCmd.Maisu.Count > i)
                    {
                        dataGridView1[i, 0].Value = SettingCmd.Maisu[i];
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (BaseCmd != null)
            {
                if (BaseCmd.SequenceName != textBox3.Text) SettingCmd.SequenceName = textBox3.Text;
                else SettingCmd.SequenceName = "";

                if (BaseCmd.Comment != textBox2.Text) SettingCmd.Comment = textBox2.Text;
                else SettingCmd.Comment = "";

                //暫定　パラメータは変更なくてもそのまま登録
                //if (BaseCmd.Parameter != textBox1.Text) SettingCmd.Parameter = textBox1.Text;
                //else SettingCmd.Parameter = "";
                SettingCmd.Parameter = textBox1.Text;

                //金種情報を展開する
                SettingCmd.Maisu.Clear();
                for (int i = 0; i < dataGridView1.ColumnCount; i++)
                {
                    if (dataGridView1[i, 0].Value != null)
                    {
                        SettingCmd.Maisu.Add(dataGridView1[i, 0].Value.ToString());
                    }
                    else
                    {
                        SettingCmd.Maisu.Add("");
                    }
                }
            }
            else
            {
                SettingCmd.SequenceName = textBox3.Text;
                SettingCmd.Comment = textBox2.Text;
                SettingCmd.Parameter = textBox1.Text;
            }
            this.DialogResult = DialogResult.OK;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CmdSequenceForm dlgP = new CmdSequenceForm(SettingCmd.SequenceP);
            dlgP.ShowDialog();
        }
    }
}
