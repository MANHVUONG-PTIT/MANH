﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class BVsenschk
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public BVsenschk(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        string[] BVsensname = { "PS3RdpmVal", "PS3RirEmit", "PS3RirVolt", "PS3RredEmit", "PS3RredVolt", "PS3RirMON", "PS3RredMON",
                                "PS3RCdpmVal", "PS3RCirEmit", "PS3RCirVolt", "PS3RCredEmit", "PS3RCredVolt", "PS3RCirMON", "PS3RCredMON",
                                "PS2CdpmVal", "PS2CirEmit", "PS2CirVolt", "PS2CredEmit", "PS2CredVolt", "PS2CirMON", "PS2CredMON",
                                "PS3LCdpmVal", "PS3LCirEmit", "PS3LCirVolt", "PS3LCredEmit", "PS3LCredVolt", "PS3LCirMON", "PS3LCredMON",
                                "PS3LdpmVal", "PS3LirEmit", "PS3LirVolt", "PS3LredEmit", "PS3LredVolt", "PS3LirMON", "PS3LredMON",
                                "PS7Lresult", "PS7LvolumeA", "PS7LvolumeB", "PS7Rresult", "PS7RvolumeA", "PS7RvolumeB"
                            };
        string[] BVdataname = { "斜行パルス数　　　", "有効サンプリング数", "オフレベル値　　　", "ボリューム値(vrna)",
                                "ボリューム値(vrnb)", "DAPS　　　　　　　", "短距離判定結果　　", "判定結果　　　　　"
                            };
        string[] TitleStr = { "ＰＳ７Ｌ情報", "ＰＳ７Ｌサンプリング", "", "ＰＳ７Ｒ情報", "ＰＳ７Ｒサンプリング" };

        //レスポンスデータのデータサイズ
        int[] BVvalHeader = { 2, 2, 4, 2, 4, 4, 4,              //PS3R
                              2, 2, 4, 2, 4, 4, 4,              //PS3RC
                              2, 2, 4, 2, 4, 4, 4,              //PS2C
                              2, 2, 4, 2, 4, 4, 4,              //PS3LC
                              2, 2, 4, 2, 4, 4, 4,              //PS3L
                              2, 2, 2, 2, 2, 2                  //PS7L,PS7R
                            };

        //ＲＡＳセンスの状態enum
        private enum SensadjCond { STOP, OPERATE }
        private enum DetailCond { ADJEMIT, WAITINSERT, ADJTRANS, WAITREMOVE, HOPPERJAM }
        private enum SensadjResult { NORMAL_END, ERROR_END }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                int sensnum = 41;
                int[] sensval_resp = new int[sensnum];
                int[] sensval_min = new int[(sensnum + 2)];
                int[] sensval_max = new int[(sensnum + 2)];
                int PS7L = 0, PS7R = 0;

                //調整値をファイル保存＆表示
                List<string[]> SensData = new List<string[]>();
                string[][] SensDataVal = new string[(sensnum + 2)][];
                string DispSensData = "";

                string BVval = CmdP.Parameter;                                  //パラメータの欄から文字列を取得する
                string[] BVvalDivide = BVval.Split(',');                        //カンマ区切りで分割して配列に格納する
                if (BVvalDivide.Length != (sensnum + 2))
                {
                    err = true;
                    switch (OwnerP.Lang)
                    {
                        case "CN":
                            OwnerP.ChangeInfo(0, 0, "参数异常（传感器数）", System.Drawing.Color.Red);
                            break;
                        case "JP":
                            OwnerP.ChangeInfo(0, 0, "パラメータ異常（センサ数）", System.Drawing.Color.Red);
                            break;
                    }
                    break;
                }
                //パラメータから読み込み（しきい値を分割）
                for (int i = 0; i < (sensnum + 2); i++)
                {
                    string[] Sensdt = BVvalDivide[i].Split(':');                //コロン区切りで分割して配列に格納する
                    if (Sensdt.Length != 2)
                    {
                        err = true;
                        switch (OwnerP.Lang)
                        {
                            case "CN":
                                OwnerP.ChangeInfo(0, 0, "参数异常（阈值）", System.Drawing.Color.Red);
                                break;
                            case "JP":
                                OwnerP.ChangeInfo(0, 0, "パラメータ異常（しきい値）", System.Drawing.Color.Red);
                                break;
                        }
                        break;  //forを抜ける
                    }
                    else
                    {
                        sensval_min[i] = int.Parse(Sensdt[0]);
                        sensval_max[i] = int.Parse(Sensdt[1]);
                    }
                }
                if (err == true) { break; }

                switch (OwnerP.Lang)
                {
                    case "CN":
                        SgNet.COM.MessageBox_s.ShowInfomation("请放入替身券（５张）");
                        break;
                    case "JP":
                        SgNet.COM.MessageBox_s.ShowInfomation("ダミー券を入れてください（５枚）");
                        break;
                }

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信 
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                int len = 1;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x30;                   //D0・モード（入金＆出金）

                //識別センサ調整コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASBVsensadj, len, dt);         //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                byte[] ReceiveData;
                if (err == false)
                {
                    bool doneFlg = false;
                    int piece = 1;
                    OwnerP.ChangeInfo(0, 0, "ダミー券を入れてください（" + piece + "枚目）", System.Drawing.Color.White);

                    do
                    {
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);                                         //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }
                        if ((doneFlg == false) && (ReceiveData[11] == (byte)DetailCond.WAITREMOVE))
                        {
                            OwnerP.ChangeInfo(0, 0, "データ取得中！　ダミー券を抜かないでください！", System.Drawing.Color.Khaki);
                            doneFlg = true;

                            //調整値をファイル保存＆表示
                            const int DATNUM = 8;           //送るコマンドの回数
                            const int DtByte = 200 / 2;     //コマンドのデータ部バイト数
                            int[] SampleDataVal = new int[DATNUM * DtByte];

                            //データ部生成-----
                            len = 6;
                            dt = new byte[len];             //データ部仮配列
                            dt[0] = 0x30;                   //D0・０固定
                            dt[1] = 0x30;                   //D1・データ種別（０：判定結果不問）
                            dt[2] = 0x30;                   //D2・０固定
                            dt[3] = 0x30;                   //D3・紙幣番号（０：１枚目）
                            dt[4] = 0x30;                   //D4・０固定
                            //データ部生成-----

                            for (int i = 0; i < DATNUM; i++)
                            {
                                dt[5] = (byte)(0x30 | (i & 0x0F));              //D5・センサ番号

                                //出金判別センサ紙幣データリードコマンド
                                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASPayoutsensread, len, dt);         //コマンド,データ長,データ部配列
                                recv = OwnerP.Send(data, 1500);                 //送信
								byte[] ReceiveDataRead = OwnerP.RecvCheckAndGetData(recv); //recvからデータだけ取り出す

                                if (ReceiveDataRead != null)
                                {
                                    //サンプリングデータを取得
                                    for (int a = 0; a < DtByte; a++)
                                    {
                                        //CharMerge(a,b)：データ２バイトの下部４ビットずつをまとめて１バイトにする
                                        SampleDataVal[i * DtByte + a] = OwnerP.CharMerge(ReceiveDataRead[2 * a], ReceiveDataRead[2 * a + 1]);
                                    }
                                }
                                else
                                {
                                    err = true;
                                    OwnerP.GetErrorByRASsense();
                                    break;
                                }
                            }

                            if (err == false)
                            {
                                //調整値をファイル保存＆表示
                                const int DtCont = 8;           //データ部の項目数
                                int ptr,div,mod;
                                List<string[]> SampleData = new List<string[]>();
                                string[][] SampleTitleStr = new string[5][];                    //タイトル
                                string[][] SampleResultStrL = new string[DtCont][];             //ＰＳ７Ｌ情報部分
                                string[][] SampleResultStrR = new string[DtCont][];             //ＰＳ７Ｒ情報部分
                                string[][] SampleDataStrL = new string[18][];                   //ＰＳ７Ｌサンプリング部分
                                string[][] SampleDataStrR = new string[18][];                   //ＰＳ７Ｒサンプリング部分

                                for (int i = 0; i < 5; i++)                     //タイトル文字列設定
                                {
                                    SampleTitleStr[i] = new string[1];
                                    SampleTitleStr[i][0] = TitleStr[i];
                                }
                                for (int i = 0; i < 18; i++)                    //サンプリングデータの配列を準備する（１８０個を１０×１８行で表示）
                                {
                                    SampleDataStrL[i] = new string[10];
                                    SampleDataStrR[i] = new string[10];
                                }

                                //サンプリングデータを取得
                                //ＰＳ７Ｌ情報部分
                                SampleData.Add(SampleTitleStr[0]);              //タイトル追加
                                for (int l = 0; l < DtCont; l++)
                                {
                                    SampleResultStrL[l] = new string[2];
                                    SampleResultStrL[l][0] = BVdataname[l];
                                    SampleResultStrL[l][1] = SampleDataVal[l + 2].ToString();
                                    SampleData.Add(SampleResultStrL[l]);
                                }

                                //ＰＳ７Ｌサンプリング部分
                                SampleData.Add(SampleTitleStr[1]);              //タイトル追加
                                for (int la = 0; la < 4; la++)                  //サンプリングデータは４５個×４ブロック＝１８０個
                                {
                                    for (int lb = 0; lb < 45; lb++)
                                    {
                                        ptr = la * 45 + lb;
                                        div = ptr / 10;
                                        mod = ptr % 10;
                                        SampleDataStrL[div][mod] = ((SampleDataVal[(DtByte * la) + (2 * lb + 10)] << 8)
                                                                  + (SampleDataVal[(DtByte * la) + (2 * lb + 11)])).ToString();
                                        if (mod == 9)
                                        {
                                            SampleData.Add(SampleDataStrL[div]);
                                        }
                                    }
                                }

                                SampleData.Add(SampleTitleStr[2]);              //タイトル追加（空行）

                                //ＰＳ７Ｒ情報部分
                                SampleData.Add(SampleTitleStr[3]);              //タイトル追加
                                for (int r = 0; r < DtCont; r++)
                                {
                                    SampleResultStrR[r] = new string[2];
                                    SampleResultStrR[r][0] = BVdataname[r];
                                    SampleResultStrR[r][1] = SampleDataVal[(4 * DtByte) + r + 2].ToString();
                                    SampleData.Add(SampleResultStrR[r]);
                                }

                                //ＰＳ７Ｒサンプリング部分
                                SampleData.Add(SampleTitleStr[4]);              //タイトル追加
                                for (int ra = 0; ra < 4; ra++)                  //サンプリングデータは４５個×４ブロック＝１８０個
                                {
                                    for (int rb = 0; rb < 45; rb++)
                                    {
                                        ptr = ra * 45 + rb;
                                        div = ptr / 10;
                                        mod = ptr % 10;
                                        SampleDataStrR[div][mod] = ((SampleDataVal[(DtByte * (ra + 4)) + (2 * rb + 10)] << 8)
                                                                  + (SampleDataVal[(DtByte * (ra + 4)) + (2 * rb + 11)])).ToString();
                                        if (mod == 9)
                                        {
                                            SampleData.Add(SampleDataStrR[div]);
                                        }
                                    }
                                }

                                OwnerP.Savevalue("SampleData"+ piece + ".csv", SampleData);

                                OwnerP.ChangeInfo(0, 0, " ", System.Drawing.Color.White);

                                //データ正当性判定処理を追加（ダミーが抜き取られていないこと　ＮＧなら「err = true」セット）
                                //状態リードコマンド
                                len = 2;
                                dt = new byte[len];                 //データ部仮配列
                                dt[0] = 0x38;                       //D0・リードデータ指定（８０固定）
                                dt[1] = 0x30;                       //D1・リードデータ指定
                                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.ConditionRead, len, dt);   //コマンド,データ長,データ部配列
                                recv = OwnerP.Send(data, 1500);                                     //送信
                                byte[] ReceiveDataCond = OwnerP.RecvCheckAndGetData(recv);                     //recvからデータだけ取り出す
                                if (ReceiveDataCond == null)
                                {
                                    err = true;
                                    OwnerP.GetErrorByRASsense();
                                    break;
                                }
                                if ((ReceiveDataCond[21] & 0x02) == 0)      //払い出し口の残留がなかったらエラー停止
                                {
                                    err = true;
                                    break;
                                }
                                SgNet.COM.Time_s.Sleep(500);                //0.5秒スリープ
                                continue;       //ＲＡＳセンスのReceiveData判定ができなくなるのでdo-whileに戻る
                            }
                            else                //出金判別センサ紙幣データリードコマンドでエラーの場合にwhileを抜けるためのbreak
                            {
                                break;
                            }
                        }
                        if ((doneFlg == true) && (ReceiveData[11] == (byte)DetailCond.WAITINSERT))
                        {
                            doneFlg = false;
                            piece++;
                            OwnerP.ChangeInfo(0, 0, "ダミー券を入れてください（" + piece + "枚目）", System.Drawing.Color.White);
                        }
                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                    } while (ReceiveData[1] == (byte)SensadjCond.OPERATE);
                    OwnerP.ChangeInfo(0, 0, " ", System.Drawing.Color.White);

                    if (err == false)
                    {
                        if (ReceiveData[4] == (byte)SensadjResult.ERROR_END)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                    }
                    else                        //識別センサ調整中の異常発生はＲＡＳ継続動作終了コマンドで処理を中断する
                    {
                        //ＲＡＳ継続動作終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);                   //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);             //送信
                        if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                        {
                            OwnerP.GetErrorByRASsense();
                        }
                        else
                        {
                            do
                            {
                                //ＲＡＳセンスコマンド
                                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                                SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                                recv = OwnerP.Send(data, 1500);                                         //送信
                                ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                                if (ReceiveData == null)
                                {
                                    OwnerP.GetErrorByRASsense();
                                    break;  //whileを抜ける
                                }
                                if (OwnerP.ForceStopFlg)
                                {
                                    break;
                                }
                            } while (ReceiveData[1] == (byte)SensadjCond.OPERATE);
                        }
                    }
                }

                if (err == false)
                {
                    //識別センサ調整値リードコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASBVsensread);             //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);                                             //送信
                    ReceiveData = OwnerP.RecvCheckAndGetData(recv);                             //recvからデータだけ取り出す

                    if (ReceiveData != null)
                    {
                        int BVvalOffset = 0;
                        //調整値を取得
                        for (int i = 0; i < sensnum; i++)
                        {
                            //CharMerge(a,b)：データ２バイトの下部４ビットずつをまとめて１バイトにする
                            sensval_resp[i] = OwnerP.CharMerge(ReceiveData[BVvalOffset], ReceiveData[BVvalOffset + 1]);
                            if (BVvalHeader[i] == 4)
                            {
                                sensval_resp[i] <<= 8;
                                sensval_resp[i] += OwnerP.CharMerge(ReceiveData[BVvalOffset + 2], ReceiveData[BVvalOffset + 3]);
                            }
                            BVvalOffset += BVvalHeader[i];
                        }
                        //調整値をファイル保存＆表示
                        for (int i = 0; i < sensnum; i++)
                        {
                            SensDataVal[i] = new string[2];
                            SensDataVal[i][0] = BVsensname[i];
                            SensDataVal[i][1] = sensval_resp[i].ToString();
                            SensData.Add(SensDataVal[i]);
                            DispSensData += SensDataVal[i][0] + "\t" + SensDataVal[i][1] + "\r\n";
                        }
                        OwnerP.ChangeInfo(2, 0, DispSensData, System.Drawing.Color.White);
                        OwnerP.Savevalue("BVsenschk.csv", SensData);
                    }
                    else
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }

                if (err == false)
                {
                    switch (OwnerP.Lang)
                    {
                        case "CN":
                            SgNet.COM.MessageBox_s.ShowInfomation("请放入替身券背面，按'ＯＫ'键");
                            break;
                        case "JP":
                            SgNet.COM.MessageBox_s.ShowInfomation("ダミー券を背面に入れて、\nその後「ＯＫ」を押してください");
                            break;
                    }

                    len = 1;
                    dt[0] = 0x31;                   //D0・センサ発光量（１：フル発光）

                    //センサレベル表示コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsenslevel, len, dt);     //コマンド,データ長,データ部配列
                    recv = OwnerP.Send(data, 1500);                                             //送信
                    if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                    else
                    {
                        OwnerP.ChangeInfo(0, 0, "データ取得中！　取得に約３秒かかります", System.Drawing.Color.Khaki);

                        do
                        {
                            //ＲＡＳセンスコマンド
                            data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                            SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                            recv = OwnerP.Send(data, 1500);                                         //送信
                            ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                            if (ReceiveData == null)
                            {
                                err = true;
                                OwnerP.GetErrorByRASsense();
                                break;  //whileを抜ける
                            }
                            if (OwnerP.ForceStopFlg)
                            {
                                err = true;
                                break;
                            }
                        } while (((ReceiveData[10] << 4) + ReceiveData[11]) == 0);       //PS4の値を取得して０でなければ取得できたものとみなす
                        OwnerP.ChangeInfo(0, 0, " ", System.Drawing.Color.White);

                        if (err == false)
                        {
                            if (ReceiveData[4] == (byte)SensadjResult.ERROR_END)
                            {
                                err = true;
                                OwnerP.GetErrorByRASsense();
                            }
                            else
                            {
                                PS7L = ((ReceiveData[36] << 4) + ReceiveData[37]);       //値を取得
                                PS7R = ((ReceiveData[40] << 4) + ReceiveData[41]);

                                SensDataVal[sensnum] = new string[2];
                                SensDataVal[sensnum][0] = "PS7L";
                                SensDataVal[sensnum][1] = PS7L.ToString();
                                SensData.Add(SensDataVal[sensnum]);
                                DispSensData += "PS7L\t" + PS7L + "\r\n";

                                SensDataVal[(sensnum + 1)] = new string[2];
                                SensDataVal[(sensnum + 1)][0] = "PS7R";
                                SensDataVal[(sensnum + 1)][1] = PS7R.ToString();
                                SensData.Add(SensDataVal[(sensnum + 1)]);
                                DispSensData += "PS7R\t" + PS7R + "\r\n";

                                OwnerP.ChangeInfo(2, 0, DispSensData, System.Drawing.Color.White);
                                OwnerP.Savevalue("BVsenschk.csv", SensData);
                            }
                        }
                    }
                    //ＲＡＳ継続動作終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);                   //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                    else
                    {
                        do
                        {
                            //ＲＡＳセンスコマンド
                            data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                            SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                            recv = OwnerP.Send(data, 1500);                                         //送信
                            ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                            if (ReceiveData == null)
                            {
                                err = true;
                                OwnerP.GetErrorByRASsense();
                                break;  //whileを抜ける
                            }
                            if (OwnerP.ForceStopFlg)
                            {
                                err = true;
                                break;
                            }
                        } while (ReceiveData[1] == (byte)SensadjCond.OPERATE);
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)               //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                if (err == false)
                {
                    switch (OwnerP.Lang)
                    {
                        case "CN":
                            SgNet.COM.MessageBox_s.ShowInfomation("请放出替身券背面，按'ＯＫ'键");
                            break;
                        case "JP":
                            SgNet.COM.MessageBox_s.ShowInfomation("ダミー券を取り除いて、\nその後「ＯＫ」を押してください");
                            break;
                    }

                    //データ比較
                    for (int i = 0; i < sensnum; i++)
                    {
                        if ((sensval_min[i] > sensval_resp[i]) || (sensval_resp[i] > sensval_max[i]))
                        {
                            err = true;
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 0, "範圍外 : " + BVsensname[i], System.Drawing.Color.Red);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 0, "範囲外 : " + BVsensname[i], System.Drawing.Color.Red);
                                    break;
                            }
                            break;
                        }
                    }
                    if ((sensval_min[sensnum] > PS7L) || (PS7L > sensval_max[sensnum]))
                    {
                        err = true;
                        switch (OwnerP.Lang)
                        {
                            case "CN":
                                OwnerP.ChangeInfo(0, 0, "範圍外 : PS7L", System.Drawing.Color.Red);
                                break;
                            case "JP":
                                OwnerP.ChangeInfo(0, 0, "範囲外 : PS7L", System.Drawing.Color.Red);
                                break;
                        }
                        break;
                    }
                    if ((sensval_min[(sensnum + 1)] > PS7R) || (PS7R > sensval_max[(sensnum + 1)]))
                    {
                        err = true;
                        switch (OwnerP.Lang)
                        {
                            case "CN":
                                OwnerP.ChangeInfo(0, 0, "範圍外 : PS7R", System.Drawing.Color.Red);
                                break;
                            case "JP":
                                OwnerP.ChangeInfo(0, 0, "範囲外 : PS7R", System.Drawing.Color.Red);
                                break;
                        }
                        break;
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
