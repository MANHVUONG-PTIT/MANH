﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Syukkin
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Syukkin(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //指示枚数設定、計数枚数のデータ部（10000円,5000円,2000円,1000円）
        //2000円に対するオフセット
        int[] MaisuHeader = { 3, 6, 0, 9 };

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                List<int> DispPCS = new List<int>();            //指示枚数、計数枚数を表示するための枚数データ格納リスト
                DispPCS.Clear();
                int pcs;

                //データ部生成-----
                int len = 34;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x30;                   //D0・初回出金
                dt[1] = 0x30;                   //D1・通常出金
                dt[2] = 0x30;                   //D2・金種振替なし
                dt[3] = 0x30;                   //D3・予備

                for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                {
                    //コマンドのデータCmdP.Maisu[a]から指示枚数を取得
                    if (!int.TryParse(CmdP.Maisu[a], out pcs)) { pcs = 0; }
                    DispPCS.Add(pcs);

                    //指示枚数設定のデータ部
                    //D4~D6　  2000円指示枚数
                    //D7~D9 　10000円指示枚数
                    //D10~D12　5000円指示枚数
                    //D13~D15　1000円指示枚数
                    //指示枚数設定に枚数を格納　MaisuHeader[a]でオフセットを考慮
                    dt[MaisuHeader[a] + 4] = (byte)(0x30 | (pcs / 100));
                    dt[MaisuHeader[a] + 5] = (byte)(0x30 | ((pcs / 10) % 10));
                    dt[MaisuHeader[a] + 6] = (byte)(0x30 | (pcs % 10));
                }

                for (int i = 16; i < 34; i++)
                { 
                    dt[i] = 0x30;               //D16~D33・予備
                }
                //データ部生成-----

                OwnerP.ChangeMaisu(DispPCS, 0);                 //指示枚数を表示
                for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                {
                    DispPCS[a] = 0;                             //０クリアして計数枚数表示に使用
                }
                OwnerP.ChangeMaisu(DispPCS, 1);                 //計数枚数を表示

                //枚数指定出金搬送コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.PayoutPieces, len, dt);  //コマンド,データ長,データ部配列
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, true))               //レスポンスチェック（ENQ待ちあり）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                byte[] ReceiveData;
                len = 2;
                dt = new byte[len];             //データ部仮配列
                dt[0] = 0x30;                   //D0・モード指定（０固定）
                dt[1] = 0x30;                   //D1・モード指定（０固定）

                //放出計数枚数取得コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.PayoutGetPcs, len, dt);         //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信
                ReceiveData = OwnerP.RecvCheckAndGetData(recv); //recvからデータだけ取り出す

                if (ReceiveData != null)
                {
                    DispPCS.Clear();
                    for (int a = 0; a < CmdP.Maisu.Count; a++)  //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        pcs = 0;
                        for (int b = 0; b < 3; b++)             //カセット（３つ）分ループ
                        {
                            int offset = b * 15;                //カセット１つあたりの枚数データ（１５バイト）分だけオフセット
                            //計数枚数のデータ部
                            //D0~D2 +D15~D17+D30~D32　  2000円合計枚数
                            //D3~D5 +D18~D20+D33~D35 　10000円合計枚数
                            //D6~D8 +D21~D23+D36~D38　  5000円合計枚数
                            //D9~D11+D24~D26+D39~D41    1000円合計枚数
                            //合計計数枚数を取得　MaisuHeader[a]でオフセットを考慮
                            pcs += (ReceiveData[offset + MaisuHeader[a]] & 0x0F) * 100
                                + (ReceiveData[offset + MaisuHeader[a] + 1] & 0x0F) * 10
                                + (ReceiveData[offset + MaisuHeader[a] + 2] & 0x0F);
                        }
                        DispPCS.Add(pcs);
                    }
                    OwnerP.ChangeMaisu(DispPCS, 1);             //計数枚数を表示
                }
                else
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //払出しコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.OutBills);      //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 1500);                                 //送信
                if (OwnerP.RespCheck(recv, true))                               //レスポンスチェック（ENQ待ちあり）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
