﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class KaisyuCST1
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public KaisyuCST1(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //計数枚数のデータ部（10000円,5000円,2000円,1000円）
        //2000円に対するオフセット
        int[] MaisuHeader = { 3, 6, 0, 9 };

        //状態リードの回収結果enum
        private enum Collectresult { NOT_YET, NORMAL_END, FULL_END, RJ_FULL, ERROR_END }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                byte[] ReceiveData;
                bool Firstflg = false;

                List<int> DispPCS = new List<int>();            //計数枚数を表示するための枚数データ格納リスト
                DispPCS.Clear();
                int pcs;
                int[] CountPcs_para = new int[CmdP.Maisu.Count];
                int[] CountPcs_resp = new int[CmdP.Maisu.Count];

                //精査コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.Examine);                //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                ReceiveData = OwnerP.RecvCheckAndGetData(recv); //recvからデータだけ取り出す
                if (ReceiveData != null)
                {
                    for (int a = 0; a < CmdP.Maisu.Count; a++)  //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        pcs = 0;
                        for (int b = 0; b < 3; b++)             //カセット（３つ）分ループ
                        {
                            if (b == 0) { continue; }           //カセット１の分は数えない

                            int offset = b * 12;                //カセット１つあたりの枚数データ（１２バイト）分だけオフセット
                                                                //計数枚数のデータ部
                                                                //D12~D14+D24~D26　  2000円合計枚数
                                                                //D15~D17+D27~D29 　10000円合計枚数
                                                                //D18~D20+D30~D32　  5000円合計枚数
                                                                //D21~D23+D33~D35    1000円合計枚数
                                                                //合計計数枚数を取得　MaisuHeader[a]でオフセットを考慮
                            pcs += (ReceiveData[offset + MaisuHeader[a]] & 0x0F) * 100
                                + (ReceiveData[offset + MaisuHeader[a] + 1] & 0x0F) * 10
                                + (ReceiveData[offset + MaisuHeader[a] + 2] & 0x0F);
                        }
                        CountPcs_para[a] = pcs;
                        DispPCS.Add(pcs);
                    }
                    OwnerP.ChangeMaisu(DispPCS, 0);             //指示枚数を表示
                }
                else
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                DispPCS.Clear();
                for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                {
                    DispPCS.Add(0);                             //計数枚数表示用に０セット
                }
                OwnerP.ChangeMaisu(DispPCS, 1);                 //計数枚数を表示

                int len = 4;
                byte[] dt = new byte[len];      //データ部仮配列
                if (Firstflg == false)
                {
                    dt[0] = 0x30;               //D0・初回動作
                    Firstflg = true;
                }
                else
                {
                    dt[0] = 0x31;               //D0・継続動作
                }
                dt[1] = 0x30;                   //D1・予備
                dt[2] = 0x32;                   //D2・回収モード　（２：カセット１回収）
                dt[3] = 0x30;                   //D3・予備

                //回収コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.BillCollection, len, dt);       //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, true))               //レスポンスチェック（ENQ待ちあり）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                len = 2;
                dt = new byte[len];             //データ部仮配列
                dt[0] = 0x30;                   //D0・モード指定（０固定）
                dt[1] = 0x30;                   //D1・モード指定（０固定）

                //放出計数枚数取得コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.PayoutGetPcs, len, dt);         //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信
                ReceiveData = OwnerP.RecvCheckAndGetData(recv); //recvからデータだけ取り出す

                if (ReceiveData != null)
                {
                    DispPCS.Clear();
                    for (int a = 0; a < CmdP.Maisu.Count; a++)  //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        pcs = 0;
                        for (int b = 0; b < 3; b++)             //カセット（３つ）分ループ
                        {
                            int offset = b * 15;                //カセット１つあたりの枚数データ（１５バイト）分だけオフセット
                                                                //計数枚数のデータ部
                                                                //D0~D2 +D15~D17+D30~D32　  2000円合計枚数
                                                                //D3~D5 +D18~D20+D33~D35 　10000円合計枚数
                                                                //D6~D8 +D21~D23+D36~D38　  5000円合計枚数
                                                                //D9~D11+D24~D26+D39~D41    1000円合計枚数
                                                                //合計計数枚数を取得　MaisuHeader[a]でオフセットを考慮
                            pcs += (ReceiveData[offset + MaisuHeader[a]] & 0x0F) * 100
                                + (ReceiveData[offset + MaisuHeader[a] + 1] & 0x0F) * 10
                                + (ReceiveData[offset + MaisuHeader[a] + 2] & 0x0F);
                        }
                        CountPcs_resp[a] = pcs;
                        DispPCS.Add(pcs);
                    }
                    OwnerP.ChangeMaisu(DispPCS, 1);             //計数枚数を表示
                }
                else
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                len = 2;
                dt = new byte[len];             //データ部仮配列
                dt[0] = 0x38;                   //D0・リードデータ指定（８０固定）
                dt[1] = 0x30;                   //D1・リードデータ指定

                //状態リードコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.ConditionRead, len, dt);        //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信
                ReceiveData = OwnerP.RecvCheckAndGetData(recv); //recvからデータだけ取り出す

                if (ReceiveData != null)
                {
                    if (ReceiveData[45] == (byte)Collectresult.NOT_YET
                     || ReceiveData[45] == (byte)Collectresult.RJ_FULL
                     || ReceiveData[45] == (byte)Collectresult.ERROR_END)
                    {
                        err = true;             //回収結果が未実施か異常終了ならエラーとする
                        switch (OwnerP.Lang)
                        {
                            case "CN":
                                OwnerP.ChangeInfo(0, 0, "回收中报错", System.Drawing.Color.Red);
                                break;
                            case "JP":
                                OwnerP.ChangeInfo(0, 0, "回収中エラー", System.Drawing.Color.Red);
                                break;
                        }
                        break;
                    }
                    else if (ReceiveData[45] == (byte)Collectresult.NORMAL_END
                          || ReceiveData[45] == (byte)Collectresult.FULL_END)
                    {
                        break;                  //回収結果が正常終了、フル終了なら終了
                    }
                }
                else
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                if (err == false)
                {
                    for (int a = 0; a < CmdP.Maisu.Count; a++)  //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        if (CountPcs_para[a] != CountPcs_resp[a])
                        {
                            err = true;
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 0, "枚数不一样", System.Drawing.Color.Red);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 0, "枚数不一致", System.Drawing.Color.Red);
                                    break;
                            }
                            break;
                        }
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
