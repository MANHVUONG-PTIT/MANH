﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Logread
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Logread(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        const int LogDataSize = 64;
        int TotalLogsize;
        
        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                string param = CmdP.Parameter;                  //パラメータの欄から文字列を取得する

                string[] log_para = param.Split(',');           //パラメータをカンマ区切りで分割して配列に格納する
                if (log_para.Length == 0)
                {
                    err = true;
                    switch (OwnerP.Lang)
                    {
                        case "CN":
                            OwnerP.ChangeInfo(0, 0, "参数异常", System.Drawing.Color.Red);
                            break;
                        case "JP":
                            OwnerP.ChangeInfo(0, 0, "パラメータ異常", System.Drawing.Color.Red);
                            break;
                    }
                    break;
                }

                //ログヘッダ生成
                byte[] LogHeader = new byte[20];
                LogHeader[0] = 1; LogHeader[1] = 1; LogHeader[2] = 0; LogHeader[3] = 20;
                LogHeader[4] = 0x30; LogHeader[5] = 0x31; LogHeader[13] = 0; LogHeader[14] = 0; LogHeader[15] = 0;

                for (int lognum = 0; lognum < log_para.Length; lognum++)
                {
                    int LogNumber = Convert.ToInt32(log_para[lognum], 16);                      //パラメータを数値変換
                    LogHeader[12] = (byte)LogNumber;

                    int len = 6;
                    byte[] dt = new byte[len];                  //データ部仮配列
                    dt[0] = (byte)(0x30 | (LogNumber / 16));    //D0・ログ番号（16^1）
                    dt[1] = (byte)(0x30 | (LogNumber % 16));    //D1・ログ番号（16^0）

                    dt[2] = 0x30;                               //D2・インデックス（16^3）
                    dt[3] = 0x30;                               //D3・インデックス（16^2）
                    dt[4] = 0x30;                               //D4・インデックス（16^1）
                    dt[5] = 0x30;                               //D5・インデックス（16^0）

                    byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.LogRead, len, dt);   //コマンド,データ長,データ部配列
                    byte[] recv = OwnerP.Send(data, 1500);      //送信

                    byte[] ReceiveData = OwnerP.RecvCheckAndGetData(recv);      //recvからデータだけ取り出す
                    if (ReceiveData != null)
                    {
                        int LastIndex = (ReceiveData[6] << 12)                  //最終インデックス取得
                                      + (ReceiveData[7] << 8)
                                      + (ReceiveData[8] << 4)
                                      + (ReceiveData[9]);
                        TotalLogsize = (LastIndex - 1) * LogDataSize;

                        byte[] LogContents = new byte[LastIndex * LogDataSize]; //データ部仮配列（ログデータのバイト値を格納）
                        for (int i = 1; i <= LastIndex; i++)
                        {
                            dt[2] = (byte)(0x30 | ((i >> 12) & 0x0F));          //D2・インデックス（16^3）
                            dt[3] = (byte)(0x30 | ((i >> 8) & 0x0F));           //D3・インデックス（16^2）
                            dt[4] = (byte)(0x30 | ((i >> 4) & 0x0F));           //D4・インデックス（16^1）
                            dt[5] = (byte)(0x30 | (i & 0x0F));                  //D5・インデックス（16^0）

                            data = OwnerP.MakeSendData((byte)SQMain.CmdCode.LogRead, len, dt);      //コマンド,データ長,データ部配列
                            recv = OwnerP.Send(data, 1500);          //送信

                            ReceiveData = OwnerP.RecvCheckAndGetData(recv);     //recvからデータだけ取り出す
                            if (ReceiveData != null)
                            {
                                int sz;
                                if (i == LastIndex)                             //最終インデックスなら受信バイト数を調べてログサイズに加算
                                {
									//ただし、元々ReceiveDataがDLE,STX,L,ETX,BCCで６バイト多く、さらにログ番号とインデックスを引いてから２バイト分をまとめる
									sz = ((ReceiveData.Length - 6) - 6) / 2;
									TotalLogsize += sz;
                                    LogHeader[16] = (byte)((TotalLogsize >> 24) & 0xFF);
                                    LogHeader[17] = (byte)((TotalLogsize >> 16) & 0xFF);
                                    LogHeader[18] = (byte)((TotalLogsize >> 8) & 0xFF);
                                    LogHeader[19] = (byte)((TotalLogsize) & 0xFF);
                                }
                                else                                            //最終インデックス以外ならデータ数は６４バイト
                                {
                                    sz = LogDataSize;
                                }

                                for (int a = 0; a < sz; a++)
                                {
                                    LogContents[(i - 1) * LogDataSize + a] =
                                        (byte)(((ReceiveData[2 * a + 6] & 0x0F) << 4) + (ReceiveData[2 * a + 7] & 0x0F));
                                }
                            }
                            else
                            {
                                err = true;
                                OwnerP.GetErrorByConditionRead();
                                break;
                            }
                        }

                        //取得ログデータのファイル保存と判定
                        List<string[]> Data = new List<string[]>();
                        string[] DataValue = new string[TotalLogsize];          //ログデータのバイト値を格納
                        byte[] DataValueBin = new byte[TotalLogsize];           //ログデータのバイト値を格納

                        Array.Copy(LogContents, DataValueBin, TotalLogsize);
                        string filename;

                        switch (log_para[lognum])
                        {
                            case "04":              //エラー時系列ログ
                                /*
                                for (int i = 0; i < TotalLogsize; i++)
                                {
                                    DataValue[i] = LogContents[i].ToString("X2");
                                }
                                Data.Add(DataValue);
                                OwnerP.Savevalue("ErrorLog.csv", Data);
                                */
                                filename = "エラー時系列ログ_" + SgNet.COM.Time_s.DateTimeNoSeparate() + ".log";
                                OwnerP.SavevalueBin(filename, LogHeader, false);
                                OwnerP.SavevalueBin(filename, DataValueBin, true);
                                break;
                            case "05":              //処理再現ログ
                                /*
                                for (int i = 0; i < TotalLogsize; i++)
                                {
                                    DataValue[i] = LogContents[i].ToString("X2");
                                }
                                Data.Add(DataValue);
                                OwnerP.Savevalue("SyoriLog.csv", Data);
                                */
                                filename = "処理再現ログ_" + SgNet.COM.Time_s.DateTimeNoSeparate() + ".log";
                                OwnerP.SavevalueBin(filename, LogHeader, false);
                                OwnerP.SavevalueBin(filename, DataValueBin, true);
                                break;
                            case "11":              //リジェクト時系列ログ
								string[] TitleStr = {	"入金識別ﾘｼﾞｪｸﾄﾃﾞｰﾀ",
														"月/日 時:分\t判定結果　　　　\t媒体間隔\t搬送速度\t停滞\tPS斜行　　\tPS札長\tPS2～PS3距離",
														"------------------------------------------------------------------------------------",
														"出金判別ﾘｼﾞｪｸﾄﾃﾞｰﾀ1",
														"月/日 時:分\t判定結果　　　　\t指示金種\t進行方向\t搬送速度\t停滞\tPS斜行",
														"------------------------------------------------------------------------------------",
														"出金判別ﾘｼﾞｪｸﾄﾃﾞｰﾀ2",
														"月/日 分:秒\t判定結果　　　　\t繰出元ｶｾｯﾄ\t札長"
								};
								string[][] DataTitle = new string[8][];          //ログデータのバイト値を格納
								for (int i = 0; i < 8; i++)                     //タイトル文字列設定
								{
									DataTitle[i] = new string[1];
									DataTitle[i][0] = TitleStr[i];
								}

								//入金識別リジェクトデータ（0～551）
					            Data.Add(DataTitle[0]);         //タイトル追加
								Data.Add(DataTitle[1]);         //タイトル追加

								int pt = ((LogContents[0] << 8) + LogContents[1]) * 11 + 2;
								string[][] DataValueNrj = new string[50][];

								for (int i = 0; i < 50; i++)
                                {
									DataValueNrj[i] = new string[1];
									DataValueNrj[i][0] = String.Format("{0,0:X2}/{1,0:X2} {2,0:X2}:{3,0:X2}\t", LogContents[pt + 0], LogContents[pt + 1], LogContents[pt + 2], LogContents[pt + 3]);
                                    if ((LogContents[pt + 4] & 0x80) == 0)
                                    {
										DataValueNrj[i][0] += "正券:";
										DataValueNrj[i][0] += MukiChk(LogContents[pt + 4] & 0x30);
										DataValueNrj[i][0] += SatsuChk1(LogContents[pt + 4] & 0x0f);
                                    }
                                    else
                                    {
										DataValueNrj[i][0] += ErrDetail1(LogContents[pt + 4] & 0x7f);
                                    }
									DataValueNrj[i][0] += String.Format("\t{0,5}mm\t{1,5}mm/s\t{2,5}ms\t", LogContents[pt + 5] * 2, LogContents[pt + 6] * 10, LogContents[pt + 7]);

                                    if (0 == (LogContents[pt + 8] & 0x7f))
                                    {
										DataValueNrj[i][0] += "斜行なし    \t";
                                    }
                                    else
                                    {
										DataValueNrj[i][0] += ((LogContents[pt + 8] & 0x80) == 0) ? "左先行" : "右先行";
										DataValueNrj[i][0] += String.Format("{0,2}.{1}mm\t", ((LogContents[pt + 8] & 0x7f) / 2), ((LogContents[pt + 8] & 0x7f) % 2) * 5);
                                    }
									DataValueNrj[i][0] += String.Format("{0,5}mm\t{1,5}mm", LogContents[pt + 9], LogContents[pt + 10]);
                                    Data.Add(DataValueNrj[i]);
                                    pt += 11;
                                    if (pt >( 50 * 11)) { pt -= (50 * 11); }
                                }

								//出金判別リジェクトデータ１（552～1053）
								Data.Add(DataTitle[2]);         //タイトル追加
								Data.Add(DataTitle[3]);         //タイトル追加
								Data.Add(DataTitle[4]);         //タイトル追加

								pt = (LogContents[552] << 8 + LogContents[553]) * 10 + 554;
								string[][] DataValueSrj1 = new string[50][];
								for (int i = 0; i < 50; i++)
                                {
									DataValueSrj1[i] = new string[1];
									DataValueSrj1[i][0] = String.Format("{0,0:X2}/{1,0:X2} {2,0:X2}:{3,0:X2}\t", LogContents[pt + 0], LogContents[pt + 1], LogContents[pt + 2], LogContents[pt + 3]);
                                    if ((LogContents[pt + 4] & 0x80) == 0)
                                    {
										DataValueSrj1[i][0] += "正券:";
										DataValueSrj1[i][0] += MukiChk(LogContents[pt + 4] & 0x30);
										DataValueSrj1[i][0] += SatsuChk1(LogContents[pt + 4] & 0x0f);
                                    }
                                    else
                                    {
										DataValueSrj1[i][0] += ErrDetail2(LogContents[pt + 4] & 0x7f);
                                    }
									DataValueSrj1[i][0] += "\t";
									DataValueSrj1[i][0] += SatsuChk2(LogContents[pt + 5]);
									DataValueSrj1[i][0] += (LogContents[pt + 6] == 0) ? "\t正転(↓)\t" : "\t逆転(↑)\t";
									DataValueSrj1[i][0] += String.Format("{0,5}mm/s\t{1,5}ms\t", LogContents[pt + 7] * 10, LogContents[pt + 8]);

									if (0 == (LogContents[pt + 9] & 0x7f))
									{
									    DataValueSrj1[i][0] += "斜行なし    \t";
									}
									else
									{
									    DataValueSrj1[i][0] += ((LogContents[pt + 9] & 0x80) == 0) ? "左先行" : "右先行";
									    DataValueSrj1[i][0] += String.Format("{0,4}mm\t", LogContents[pt + 9] & 0x7f);
									}

									Data.Add(DataValueSrj1[i]);
									pt += 10;
									if (pt > (50 * 10)) { pt -= (50 * 10); }
								}

								//出金判別リジェクトデータ２（1054～1405）
								Data.Add(DataTitle[5]);         //タイトル追加
								Data.Add(DataTitle[6]);         //タイトル追加
								Data.Add(DataTitle[7]);         //タイトル追加

                                pt = (LogContents[1054] << 8 + LogContents[1055]) * 7 + 1056;
                                string[][] DataValueSrj2 = new string[50][];
                                for (int i = 0; i < 50; i++)
                                {
                                    DataValueSrj2[i] = new string[1];
                                    DataValueSrj2[i][0] = String.Format("{0,0:X2}/{1,0:X2} {2,0:X2}:{3,0:X2}\t", LogContents[pt + 0], LogContents[pt + 1], LogContents[pt + 2], LogContents[pt + 3]);
                                    if ((LogContents[pt + 4] & 0x80) == 0)
                                    {
                                        DataValueSrj2[i][0] += "正券:";
                                        DataValueSrj2[i][0] += SatsuChk1(LogContents[pt + 4] & 0x0f);
                                    }
                                    else
                                    {
                                        DataValueSrj2[i][0] += ErrDetail2(LogContents[pt + 4] & 0x7f);
                                    }
                                    DataValueSrj2[i][0] += "\t";
                                    DataValueSrj2[i][0] += String.Format("ｶｾｯﾄ{0}\t{1,5}mm", LogContents[pt + 5], LogContents[pt + 6]);

                                    Data.Add(DataValueSrj2[i]);
                                    pt += 10;
                                    if (pt > (50 * 7)) { pt -= (50 * 7); }
                                }
                                OwnerP.Savevalue("RejectLog.csv", Data);
                                filename = "リジェクト時系列ログ_" + SgNet.COM.Time_s.DateTimeNoSeparate() + ".log";
                                OwnerP.SavevalueBin(filename, LogHeader, false);
                                OwnerP.SavevalueBin(filename, DataValueBin, true);
                                break;
                            case "13":              //検査用ログ
                                //foreach (System.IO.FileInfo f in KensaFile)
                                //{
                                //    FileName = KensaFile[fcnt].FullName;
                                //    fcnt++;

                                //    wdata = label1.Text + "で翻訳しています\r\n";
                                //    wdata2 = "";
                                //    fs = new FileStream(FileName, FileMode.Open);
                                //    r = new BinaryReader(fs);
                                //    b = r.ReadBytes(20);
                                //    wdata += String.Format("ﾛｸﾞｸﾘｱ日時: {0,0:X2}/{1,0:X2}/{2,0:X2} {3,0:X2}:{4,0:X2}:{5,0:X2}\r\n", b[6], b[7], b[8], b[9], b[10], b[11]);
                                //    wdata += "------------------------------------------------------------------------------------\r\n";
                                //    for (int k = 0; k < 2; k++)
                                //    {
                                //        if (k == 0)
                                //        {
                                //            wdata += "入金系搬送ﾃﾞｰﾀ\r\n";
                                //        }
                                //        else
                                //        {
                                //            wdata += "------------------------------------------------------------------------------------\r\n";
                                //            wdata += wdata2;
                                //            wdata += "------------------------------------------------------------------------------------\r\n";
                                //            wdata += "出金系搬送ﾃﾞｰﾀ\r\n";
                                //        }
                                //        b = r.ReadBytes(2);
                                //        ptr = (int)(b[0] << 8) + b[1];

                                //        for (int i = 0; i < 100; i++)
                                //        {
                                //            lstwdata[i] = "";
                                //            lstwdata2[i] = "";

                                //            b = r.ReadBytes(48);
                                //            tmpdata = StatusChk(b[0]);
                                //            lstwdata[i] += tmpdata;
                                //            lstwdata2[i] += tmpdata + "\t";

                                //            tmpdata = String.Format(":{0,5}\t", (b[1] << 8) + b[2]);
                                //            lstwdata[i] += tmpdata;
                                //            swpdata = (b[1] << 8) + b[2];

                                //            for (int j = 0; j < 15; j++)
                                //            {
                                //                if (0 != (int)((b[4 + (j * 3)] << 8) + b[5 + (j * 3)]))
                                //                {
                                //                    tmpdata = SensorChk(b[3 + (j * 3)] & 0x7f);
                                //                    lstwdata[i] += tmpdata;
                                //                    tmpdata2 = tmpdata;
                                //                    tmpdata = (0 == (0x80 & (b[3 + (j * 3)]))) ? "遮光" : "透光";
                                //                    lstwdata[i] += tmpdata;
                                //                    if (tmpdata2 == "BV受信")
                                //                    {
                                //                        lstwdata2[i] += tmpdata2 + "\t";
                                //                        lstwdata2[i] += String.Format("\t{0,5}\t", (int)((b[4 + (j * 3)] << 8) + b[5 + (j * 3)]) - swpdata2[1]);
                                //                        swpdata2[11] = (int)((b[4 + (j * 3)] << 8) + b[5 + (j * 3)]);
                                //                    }
                                //                    else if (0 == (0x80 & (b[3 + (j * 3)])))    //遮光
                                //                    {
                                //                        tmpdata2 += tmpdata;
                                //                        lstwdata2[i] += tmpdata2;

                                //                        if (tmpdata2 == "PS6遮光")
                                //                        {
                                //                            lstwdata2[i] += String.Format("\t{0,5}\t", (int)((b[4 + (j * 3)] << 8) + b[5 + (j * 3)]) - swpdata2[5]);
                                //                        }
                                //                        else if (tmpdata2 == "PS7遮光")
                                //                        {
                                //                            lstwdata2[i] += String.Format("\t{0,5}\t", (int)((b[4 + (j * 3)] << 8) + b[5 + (j * 3)]) - (swpdata2[11] != 0 ? swpdata2[11] : swpdata2[1]));
                                //                        }
                                //                        else
                                //                        {
                                //                            lstwdata2[i] += String.Format("\t{0,5}\t", (int)((b[4 + (j * 3)] << 8) + b[5 + (j * 3)]) - (int)((b[4 + ((j - 1) * 3)] << 8) + b[5 + ((j - 1) * 3)]));
                                //                        }
                                //                        swpdata2[b[3 + (j * 3)] & 0x7f] = (int)((b[4 + (j * 3)] << 8) + b[5 + (j * 3)]);
                                //                        lstwdata2[i] += tmpdata2 + "tmp\t";
                                //                    }
                                //                    else
                                //                    {
                                //                        tmpdata = String.Format("\t{0,5}\t", (int)((b[4 + (j * 3)] << 8) + b[5 + (j * 3)]) - swpdata2[b[3 + (j * 3)] & 0x7f]);
                                //                        lstwdata2[i] = lstwdata2[i].Replace(tmpdata2 + "遮光tmp", tmpdata);
                                //                    }
                                //                    tmpdata = String.Format(":{0,5}[{1,3}]\t", (b[4 + (j * 3)] << 8) + b[5 + (j * 3)], (int)((b[4 + (j * 3)] << 8) + b[5 + (j * 3)]) - swpdata);
                                //                    lstwdata[i] += tmpdata;
                                //                }
                                //            }
                                //            lstwdata[i] += "\r\n";
                                //            lstwdata2[i] += "\r\n";

                                //        }
                                //        for (int i = 0; i < 100; i++)
                                //        {
                                //            ptr = (ptr - 48) < 0 ? 99 * 48 : (ptr - 48);
                                //            wdata += lstwdata[ptr / 48];
                                //            wdata2 += lstwdata2[ptr / 48];
                                //        }

                                //    }


                                //    wdata += "------------------------------------------------------------------------------------\r\n";
                                //    wdata += wdata2;

                                //    wdata += "------------------------------------------------------------------------------------\r\n";
                                //    wdata += "入金識別ﾃﾞｰﾀ\r\n";
                                //    b = r.ReadBytes(2);
                                //    ptr = (int)(b[0] << 8) + b[1];
                                //    for (int i = 0; i < 100; i++)
                                //    {
                                //        lstwdata[i] = "";

                                //        b = r.ReadBytes(7);
                                //        if ((b[0] & 0x80) == 0)
                                //        {
                                //            lstwdata[i] += "正券:";
                                //            lstwdata[i] += MukiChk(b[0] & 0x30);
                                //            //★★★b[0] & 0x0fでは正常に動作しない
                                //            lstwdata[i] += SatsuChk1(b[0] & 0x07);
                                //        }
                                //        else
                                //        {
                                //            lstwdata[i] += "ﾘｼﾞｪｸﾄ券:";
                                //            lstwdata[i] += ErrDetail1(b[0] & 0x7f);

                                //        }
                                //        lstwdata[i] += "\t";
                                //        tmpdata = String.Format("{0,5}mm\t{1,5}mm/s\t{2}ms\t", b[1] * 2, b[2] * 10, b[3]);
                                //        lstwdata[i] += tmpdata;

                                //        if (0 == (b[4] & 0x7f))
                                //        {
                                //            lstwdata[i] += "斜行なし    \t";
                                //        }
                                //        else
                                //        {
                                //            tmpdata = ((b[4] & 0x80) == 0) ? "左先行" : "右先行";
                                //            lstwdata[i] += tmpdata;
                                //            tmpdata = String.Format("{0,2}.{1}mm\t", ((b[4] & 0x7f) / 2), ((b[4] & 0x7f) % 2) * 5);
                                //            lstwdata[i] += tmpdata;
                                //        }
                                //        tmpdata = String.Format("{0,5}mm\t{1,5}mm\r\n", b[5], b[6]);
                                //        lstwdata[i] += tmpdata;
                                //    }
                                //    for (int i = 0; i < 100; i++)
                                //    {
                                //        ptr = (ptr - 7) < 0 ? 99 * 7 : (ptr - 7);
                                //        wdata += lstwdata[ptr / 7];
                                //    }

                                //    wdata += "------------------------------------------------------------------------------------\r\n";
                                //    wdata += "出金判別ﾃﾞｰﾀ1\r\n";
                                //    b = r.ReadBytes(2);
                                //    ptr = (int)(b[0] << 8) + b[1];
                                //    for (int i = 0; i < 100; i++)
                                //    {
                                //        lstwdata[i] = "";

                                //        b = r.ReadBytes(6);
                                //        if ((b[0] & 0x80) == 0)
                                //        {
                                //            lstwdata[i] += "正券:";
                                //            lstwdata[i] += MukiChk(b[0] & 0x30);
                                //            //★★★b[0] & 0x0fでは正常に動作しない
                                //            lstwdata[i] += SatsuChk1(b[0] & 0x07);
                                //        }
                                //        else
                                //        {
                                //            lstwdata[i] += "ﾘｼﾞｪｸﾄ券:";
                                //            lstwdata[i] += ErrDetail2(b[0] & 0x7f, 1);
                                //        }
                                //        lstwdata[i] += "\t";
                                //        lstwdata[i] += SatsuChk2(b[1]);
                                //        lstwdata[i] += "\t";
                                //        tmpdata = (b[2] == 0) ? "正転(↓)\t" : "逆転(↑)\t";
                                //        lstwdata[i] += tmpdata;
                                //        tmpdata = String.Format("{0,5}mm/s\t{1,5}ms\t", b[3] * 10, b[4]);
                                //        lstwdata[i] += tmpdata;

                                //        if (0 == (b[5] & 0x7f))
                                //        {
                                //            lstwdata[i] += "斜行なし    \t";
                                //        }
                                //        else
                                //        {
                                //            tmpdata = ((b[5] & 0x80) == 0) ? "左先行" : "右先行";
                                //            lstwdata[i] += tmpdata;
                                //            tmpdata = String.Format("{0,4}mm\t", b[5] & 0x7f);
                                //            lstwdata[i] += tmpdata;
                                //        }
                                //        lstwdata[i] += "\r\n";
                                //    }
                                //    for (int i = 0; i < 100; i++)
                                //    {
                                //        ptr = (ptr - 6) < 0 ? 99 * 6 : (ptr - 6);
                                //        wdata += lstwdata[ptr / 6];
                                //    }

                                //    wdata += "------------------------------------------------------------------------------------\r\n";
                                //    wdata += "出金判別ﾃﾞｰﾀ2\r\n";
                                //    b = r.ReadBytes(2);
                                //    ptr = (int)(b[0] << 8) + b[1];
                                //    for (int i = 0; i < 100; i++)
                                //    {
                                //        lstwdata[i] = "";

                                //        b = r.ReadBytes(3);
                                //        if ((b[0] & 0x80) == 0)
                                //        {
                                //            lstwdata[i] += "正券:";
                                //            lstwdata[i] += SatsuChk1(b[0] & 0x0f);
                                //        }
                                //        else
                                //        {
                                //            lstwdata[i] += "ﾘｼﾞｪｸﾄ券";
                                //            lstwdata[i] += ErrDetail2(b[0] & 0x7f, 2);
                                //        }
                                //        lstwdata[i] += "\t";
                                //        tmpdata = String.Format("ｶｾｯﾄ{0}\t{1,5}mm\r\n", b[1], b[2]);
                                //        lstwdata[i] += tmpdata;
                                //    }
                                //    for (int i = 0; i < 100; i++)
                                //    {
                                //        ptr = (ptr - 3) < 0 ? 99 * 3 : (ptr - 3);
                                //        wdata += lstwdata[ptr / 3];
                                //    }
                                //    fs.Close();
                                //}
                                /*
                                for (int i = 0; i < TotalLogsize; i++)
                                {
                                    DataValue[i] = LogContents[i].ToString("X2");
                                }
                                Data.Add(DataValue);
                                OwnerP.Savevalue("KensaLog.csv", Data);
                                */
                                filename = "検査用ログ_" + SgNet.COM.Time_s.DateTimeNoSeparate() + ".log";
                                OwnerP.SavevalueBin(filename, LogHeader, false);
                                OwnerP.SavevalueBin(filename, DataValueBin, true);
                                break;
                            case "83":              //データログ
                                /*
                                string[] Vername = { "型式名称", "版数　　", "小変更No", "SUM 値　", "ブート SUM" };
                                string[][] DataValueVer = new string[6*3][];
                                for (int i = 0; i < 6 * 3; i++)
                                {
                                    DataValueVer[i] = new string[2];
                                }
                                for (int i = 0; i < 3; i++)
                                {
//                                    DataValueVer[l][0] = Vername[l];
//                                    DataValueVer[l][1] = LogContents[l + 2].ToString();
//                                    Data.Add(DataValueVer[l]);
                                }

                                string[] Logname = { "PS4", "PS5", "PS6", "PS8", "PS9", "PS10", "PS11", "PS14", "PS1A", "PS1B", "PS12", "PS15", "PS16" };

                                for (int i = 0; i < TotalLogsize; i++)
                                {
                                    DataValue[i] = LogContents[i].ToString("X2");
                                }
                                Data.Add(DataValue);
                                OwnerP.Savevalue("DataLog.csv", Data);
                                */
                                filename = "データログ_" + SgNet.COM.Time_s.DateTimeNoSeparate() + ".log";
                                OwnerP.SavevalueBin(filename, LogHeader, false);
                                OwnerP.SavevalueBin(filename, DataValueBin, true);
                                break;
                            case "93":              //搬送ログ：ブロック０
                                /*
                                for (int i = 0; i < TotalLogsize; i++)
                                {
                                    DataValue[i] = LogContents[i].ToString("X2");
                                }
                                Data.Add(DataValue);
                                OwnerP.Savevalue("HansouLog0.csv", Data);
                                */
                                filename = "搬送ログ(ブロック０)_" + SgNet.COM.Time_s.DateTimeNoSeparate() + ".log";
                                OwnerP.SavevalueBin(filename, LogHeader, false);
                                OwnerP.SavevalueBin(filename, DataValueBin, true);
                                break;
                            case "94":              //搬送ログ：ブロック１
                                /*
                                for (int i = 0; i < TotalLogsize; i++)
                                {
                                    DataValue[i] = LogContents[i].ToString("X2");
                                }
                                Data.Add(DataValue);
                                OwnerP.Savevalue("HansouLog1.csv", Data);
                                */
                                filename = "搬送ログ(ブロック１)_" + SgNet.COM.Time_s.DateTimeNoSeparate() + ".log";
                                OwnerP.SavevalueBin(filename, LogHeader, false);
                                OwnerP.SavevalueBin(filename, DataValueBin, true);
                                break;
                        }
                    }
                    else
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                    }
                }

                if (err == false)
                {
                    //データ比較
                    for (int i = 0; i < TotalLogsize; i++)
                    {
//                        if ((sensval_min[i] > sensval_resp[i]) || (sensval_resp[i] > sensval_max[i]))
//                        {
//                            err = true;
//                            OwnerP.ChangeInfo(0, 0, "Out of range : " + Logname[i], System.Drawing.Color.Red);
//                            break;
//                        }
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }

        private string SatsuChk1(int code)
        {
            string res = "";

            switch (code)
            {
                case 1:
                    res = "二千券";
                    break;
                case 2:
                    res = "千券  ";
                    break;
                case 3:
                    res = "五千券";
                    break;
                case 4:
                    res = "万券  ";
                    break;
                default:
                    res = "??????";
                    break;
            }
            return res;
        }
		private string SatsuChk2(int code)
		{
			string res = "";

			switch (code)
			{
				case 1:
					res = "万  ";
					break;
				case 2:
					res = "五千";
					break;
				case 4:
					res = "千  ";
					break;
				case 8:
					res = "二千";
					break;
				default:
					res = "????";
					break;
			}
			return res;
		}
		private string MukiChk(int code)
        {
            string res = "";

            switch (code)
            {
                case 0x00:
                    res = "D方向:";
                    break;
                case 0x10:
                    res = "A方向:";
                    break;
                case 0x20:
                    res = "C方向:";
                    break;
                case 0x30:
                    res = "B方向:";
                    break;
                default:
                    res = "?????:";
                    break;
            }
            return res;
        }
        private string ErrDetail1(int code)
        {
            string[] tbl = 
            {
                "異常接近           ","斜行異常           ","搬送速度過大       ","搬送速度過小       ",
                "                   ","                   ","札長過大           ","札長過小           ",
                "                   ","                   ","札長不一致         ","形状異常           ",
                "形状異常2          ","VP異常             ","形状異常3          ","                   ",
                "                   ","                   ","透かしﾊﾟﾀｰﾝ異常    ","                   ",
                "透かしバーﾊﾟﾀｰﾝ異常","                   ","                   ","                   ",
                "Pｻﾝﾌﾟﾘﾝｸﾞﾀｲﾐﾝｸﾞ異常","ﾌｫﾄ2枚ﾊﾟﾀｰﾝ異常    ","色差ﾊﾟﾀｰﾝ異常1     ","搬送異常           ",
                "色差ﾊﾟﾀｰﾝ異常2     ","色差ﾊﾟﾀｰﾝ異常3     ","色差ﾊﾟﾀｰﾝ異常4     ","色差ﾊﾟﾀｰﾝ異常5     ",
                "","","","", "","","","", "","","","", "","","","", "","","","", "","","","", "","","","", "","","","",
                "","","","", "","","","", "","","","", "","","","", "","","","", "","","","", "","","","", "","","","",
                "","","","", "","","","", "","","","", "","","","", "","","","", "","","","", "","","","", "","","",""
            };

            return tbl[code];
        }
        private string ErrDetail2(int code)
        {
            string[] tbl =
            {
                "斜行異常              ","搬送速度過大          ","搬送速度過小          ","札長過小              ",
                "形状異常              ","形状異常2             ","正規化失敗            ","金種主判定処理NG      ",
                "金種主判定処理2NG     ","異金種                ","ﾌｫﾄ2枚ﾊﾟﾀｰﾝ異常       ","出金判別結果 Jｺｰﾄﾞ最大",
                "","","","", "","","","", "","","","", "","","","", "","","","", "","","","", "","","","",
                "通信異常              ","ﾁｪｯｸｺｰﾄﾞ異常          ","搬送異常              ","                      ",
                "                      ","通信ﾀｲﾑｱｯﾌﾟ           ","                      ","                      ",
                "","","","", "","","","", "","","","", "","","","",
                "                      ","                      ","異金種(万)            ","異金種(五千)          ",
                "異金種(二千)          ","異金種(千)            ","札長判定未完了        ","札長過大              ",
                "札長過小              ","                      ","                      ","                      ",
                "","","","", "","","","", "","","","", "","","","", "","","","",
                "","","","", "","","","", "","","","", "","","","", "","","","", "","","","", "","","","", "","","",""
            };
            return tbl[code];
        }

    }
}
