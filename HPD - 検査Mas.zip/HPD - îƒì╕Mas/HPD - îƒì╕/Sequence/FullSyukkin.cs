﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class FullSyukkin
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        public static int pcs = 0;
        public static int ChkRslt = 0;

        //コンストラクタ
        public FullSyukkin(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                List<int> DispPCS = new List<int>();            //指示枚数、計数枚数を表示するための枚数データ格納リスト
                DispPCS.Clear();
                for (int a = 0; a < CmdP.Maisu.Count; a++)      //リストを４金種分生成、０で初期化
                {
                    DispPCS.Add(0);
                }

                //コマンドのデータCmdP.Maisu[3]から1000円指示枚数を取得
                if (!int.TryParse(CmdP.Maisu[3], out pcs)) { pcs = 0; }

                while (pcs > 0)
                {
                    if (OwnerP.ForceStopFlg)
                    {
                        break;
                    }
                    //データ部生成-----
                    int len = 34;
                    byte[] dt = new byte[len];      //データ部仮配列
                    dt[0] = 0x30;                   //D0・初回出金
                    dt[1] = 0x30;                   //D1・通常出金
                    dt[2] = 0x30;                   //D2・金種振替なし
                    dt[3] = 0x30;                   //D3・予備

                    //D7~D9 　10000円指示枚数
                    dt[7] = 0x30;                   //D7
                    dt[8] = 0x30;                   //D8
                    dt[9] = 0x30;                   //D9
                    DispPCS[0] = 0;                 //指示枚数０
                    //D10~D12　5000円指示枚数
                    dt[10] = 0x30;                  //D10
                    dt[11] = 0x30;                  //D11
                    dt[12] = 0x30;                  //D12
                    DispPCS[1] = 0;                 //指示枚数０
                    //D4~D6　  2000円指示枚数
                    dt[4] = 0x30;                   //D4
                    dt[5] = 0x30;                   //D5
                    dt[6] = 0x30;                   //D6
                    DispPCS[2] = 0;                 //指示枚数０

                    //D13~D15　1000円指示枚数　指示枚数設定に枚数を格納
                    dt[13] = 0x30;                  //D13
                    if (pcs >= 10)   //１０枚以上であれば１０枚ずつ
                    {
                        dt[14] = 0x31;              //D14
                        dt[15] = 0x30;              //D15
                        DispPCS[3] = 10;            //指示枚数１０
                    }
                    else            //１０枚未満であれば残り枚数が指示枚数
                    {
                        dt[14] = 0x30;                  //D14
                        dt[15] = (byte)(0x30 | pcs);    //D15
                        DispPCS[3] = pcs;               //残り枚数が指示枚数
                    }

                    for (int i = 16; i < 34; i++)
                    { 
                        dt[i] = 0x30;               //D16~D33・予備
                    }
                    //データ部生成-----

                    OwnerP.ChangeMaisu(DispPCS, 0);                 //指示枚数を表示
                    for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        DispPCS[a] = 0;                             //０クリアして計数枚数表示に使用
                    }
                    OwnerP.ChangeMaisu(DispPCS, 1);                 //計数枚数を表示

                    //枚数指定出金搬送コマンド
                    byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.PayoutPieces, len, dt);  //コマンド,データ長,データ部配列
                    byte[] recv = OwnerP.Send(data, 1500);          //送信
                    if (OwnerP.RespCheck(recv, true))               //レスポンスチェック（ENQ待ちあり）
                    {
                        OwnerP.GetErrorByConditionRead();
                        //在高不一致、動作中エンプティ　のエラーの場合は特別の復旧処理を実施
                        //在高不一致エラー時　戻し入れあり
                        if ((OwnerP.GetErrCode == "5913") || (OwnerP.GetErrCode == "5923") || (OwnerP.GetErrCode == "5933"))
                        {
                            OwnerP.AmountErrorExec(true, pcs);
                        }
                        //動作中エンプティエラー時　戻し入れなし　代わりに入金で入れる
                        else if ((OwnerP.GetErrCode == "1801") || (OwnerP.GetErrCode == "1802") || (OwnerP.GetErrCode == "1803"))
                        {
                            OwnerP.AmountErrorExec(false, pcs);
                        }
                        else
                        {
                            err = true;
                            break;
                        }

                        len = 34;
                        for (int i = 0; i < 34; i++)
                        {
                            dt[i] = 0x30;
                        }
                        dt[14] = (byte)(0x30 | (pcs / 10));     //D14
                        dt[15] = (byte)(0x30 | (pcs % 10));     //D15
                                                                //枚数指定出金搬送コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.PayoutPieces, len, dt);  //コマンド,データ長,データ部配列
                        recv = OwnerP.Send(data, 1500);         //送信
                        if (OwnerP.RespCheck(recv, true))       //レスポンスチェック（ENQ待ちあり）
                        {
                            err = true;
                            OwnerP.GetErrorByConditionRead();
                            break;
                        }
                    }

                    byte[] ReceiveData;
                    len = 2;
                    dt = new byte[len];             //データ部仮配列
                    dt[0] = 0x30;                   //D0・モード指定（０固定）
                    dt[1] = 0x30;                   //D1・モード指定（０固定）

                    //放出計数枚数取得コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.PayoutGetPcs, len, dt);         //コマンド,データ長,データ部配列
                    recv = OwnerP.Send(data, 1500);                 //送信
                    ReceiveData = OwnerP.RecvCheckAndGetData(recv); //recvからデータだけ取り出す

                    if (ReceiveData != null)
                    {
                        //計数枚数を取得
                        DispPCS[3] += (ReceiveData[39] & 0x0F) * 100
                                    + (ReceiveData[40] & 0x0F) * 10
                                    + (ReceiveData[41] & 0x0F);
                        pcs = pcs - DispPCS[3];
                        OwnerP.ChangeMaisu(DispPCS, 1);             //計数枚数を表示
                    }
                    else
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;
                    }

                    //払出しコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.OutBills);      //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);                                 //送信
                    if (OwnerP.RespCheck(recv, true))                               //レスポンスチェック（ENQ待ちあり）
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;
                    }

                }
                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
