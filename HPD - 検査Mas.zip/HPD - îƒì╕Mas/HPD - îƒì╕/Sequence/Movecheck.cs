﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Movecheck
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Movecheck(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //ＲＡＳセンスの状態enum
        private enum MovechkCond { STOP, OPERATE }
        private enum MovechkResult { NORMAL_END, ERROR_END }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

/*
                //リセットコマンド（駆動部動作の前に定位置にする必要がある）
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.Reset);  //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信

                if (OwnerP.RespCheck(recv, true))               //レスポンスチェック（ENQ待ちあり）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                }

                //ＲＡＳ開始コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                int len = 2;
                byte[] dt = new byte[len];      //データ部仮配列

                dt[0] = 0x31;                   //D0・動作内容指定（１：カセットレバー位置移動(札押さえ位置)）

                for (int i = 0; i < 3; i++)     //カセット（３つ）分ループ
                { 
                    dt[1] = (byte)(0x30 | i);   //D1・動作箇所（カセット１～３）

                    //駆動部動作チェックコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASmovecheck, len, dt);     //コマンド,データ長,データ部配列
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }

                    byte[] ReceiveData;
                    if (err == false)
                    {
                        do
                        {
                            //ＲＡＳセンスコマンド
                            data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);          //コマンド（データ長０のもの）
                            SgNet.COM.Time_s.Sleep(500);        //0.5秒スリープ
                            recv = OwnerP.Send(data, 1500);                                     //送信
                            ReceiveData = OwnerP.RecvCheckAndGetData(recv);                     //recvからデータだけ取り出す
                            if (ReceiveData == null)
                            {
                                err = true;
                                OwnerP.GetErrorByRASsense();
                                break;  //whileを抜ける
                            }
                            if (OwnerP.ForceStopFlg)
                            {
                                err = true;
                                break;
                            }
                        } while (ReceiveData[10] == (byte)MovechkCond.OPERATE);

                        if (err == false)
                        {
                            if (ReceiveData[4] == (byte)MovechkResult.ERROR_END)
                            {
                                err = true;
                                OwnerP.GetErrorByRASsense();
                            }
                        }
                    }
                    if (err == true) { break; } //forを抜ける
                }

                if (recv != null)               //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ継続動作終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);                   //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)               //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }
*/

                int len = 2;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x31;                   //D0・設定データ（16^1）
                dt[1] = 0x30;                   //D1・設定データ（16^0）（１６：カセットレバー出荷位置移動）

                //ロック解除コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.LockRelease, len, dt);    //コマンド,データ長,データ部配列
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, true))               //レスポンスチェック（ENQ待ちあり）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
