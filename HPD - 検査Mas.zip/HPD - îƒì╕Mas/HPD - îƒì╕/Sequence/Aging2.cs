﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Aging2
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Aging2(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //ＲＡＳセンスの状態enum
        private enum AgingCond { STOP, OPERATE }
        private enum AgingResult { NORMAL_END, ERROR_END }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                string AGpara = CmdP.Parameter;                                  //パラメータの欄から文字列を取得する
                string[] AGparaDivide = AGpara.Split(',');                        //カンマ区切りで分割して配列に格納する
                if (AGparaDivide.Length != 2)
                {
                    err = true;
                    switch (OwnerP.Lang)
                    {
                        case "CN":
                            OwnerP.ChangeInfo(0, 0, "参数异常", System.Drawing.Color.Red);
                            break;
                        case "JP":
                            OwnerP.ChangeInfo(0, 0, "パラメータ異常", System.Drawing.Color.Red);
                            break;
                    }
                    break;
                }
                int times, interval; 
                if (!int.TryParse(AGparaDivide[0], out times)) { times = 0; }
                if (!int.TryParse(AGparaDivide[1], out interval)) { interval = 0; }

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                int len = 6;
                byte[] dt = new byte[len];  //データ部仮配列
                dt[0] = (byte)(0x30 | (times / 1000));          //D0・動作回数（千位）
                dt[1] = (byte)(0x30 | ((times / 100) % 10));    //D1・動作回数（百位）
                dt[2] = (byte)(0x30 | ((times / 10) % 10));     //D2・動作回数（十位）
                dt[3] = (byte)(0x30 | (times % 10));            //D3・動作回数（一位）
                dt[4] = (byte)(0x30 | (interval / 10));         //D4・インターバル時間（十位）
                dt[5] = (byte)(0x30 | (interval % 10));         //D5・インターバル時間（一位）

                //エージング２コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASAging2, len, dt);            //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信

                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                byte[] ReceiveData;
                if (err == false)
                {
                    do
                    {
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);              //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);            //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);                                         //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);                         //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }

                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                    } while (ReceiveData[1] == (byte)AgingCond.OPERATE);

                    if(ReceiveData == null)
                    {
                        break;
                    }
                    else if(ReceiveData.Length < 14)
                    {
                        break;
                    }

                    int exetimes = 0;
                    
                    for (int i = 0; i < 4; i++)
                    {
                        exetimes *= 10;
                        exetimes += ReceiveData[i + 10];        //動作回数を取り出す（D10～D13）
                    }
                    OwnerP.Aging2times = exetimes.ToString();   //文字列に変換

                    if (err == false)
                    {
                        if (ReceiveData[4] == (byte)AgingResult.ERROR_END)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)               //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }

                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.Reset);         //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);                 //送信

                    if (OwnerP.RespCheck(recv, true))               //レスポンスチェック（ENQ待ちあり）
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                    }
                }


                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
