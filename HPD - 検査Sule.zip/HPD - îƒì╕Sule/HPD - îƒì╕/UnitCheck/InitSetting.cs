﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Simulator
{
    public partial class InitSetting : Form
    {
        SgNet.COM.File_s.IniFile_s iniP = new SgNet.COM.File_s.IniFile_s(SgNet.COM.Dir_s.Path_s.StartupPath() + "\\Settings.ini");
        List<String> titleBase = new List<String>();
        List<String> widthBase = new List<String>();
        int beforeItemNo = -1;
        public InitSetting()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Save
            SgNet.COM.File_s.IniFile_s iniP2 = new SgNet.COM.File_s.IniFile_s(SgNet.COM.Dir_s.Path_s.StartupPath() + "\\dummySettings.ini");
            iniP2.IniFilePath = SgNet.COM.Dir_s.Path_s.StartupPath() + "\\Settings.ini";

            iniP2.WriteInt("Settings", "GridPattern", comboBox1.SelectedIndex);
            iniP2.WriteInt("Settings", "GloryDLL", (checkBox1.Checked ? 1 : 0));

            iniP2.WriteInt("Settings", "Infomation_BigPanel", (checkBox2.Checked ? 1 : 0));
            iniP2.WriteInt("Settings", "Infomation_LittlePanel", (checkBox3.Checked ? 1 : 0));
            iniP2.WriteInt("Settings", "Infomation_MaisuPanel", (checkBox4.Checked ? 1 : 0));
            iniP2.WriteInt("Settings", "Infomation_ProgresPanel", (checkBox5.Checked ? 1 : 0));

            iniP2.WriteString("Settings", "Address", textBox2.Text);


            String ss = "";
            int no = 0;

            //金種情報をセット
            iniP2.WriteString("Settings", "MoneyCount", textBox1.Text);
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                ss = listBox1.Items[i].ToString();
                if (ss != ("money" + i.ToString()))
                {
                    iniP2.WriteString("Settings", "Money" + i.ToString(), ss);
                }
            }

            int kinsyuCnt = 0;
            int.TryParse(textBox1.Text, out kinsyuCnt);

            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    no = 0; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title0", ss);
                    no = 1; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title1", ss);
                    no = 2; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title2", ss);
                    break;
                case 1:
                    no = 0; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title0", ss);
                    no = 1; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title1", ss);
                    no = 2; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title2", ss);
                    no = 3; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title3", ss);
                    break;
                case 2:
                    no = 0; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title0", ss);
                    no = 1; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title1", ss);
                    no = 2; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title2", ss);
                    no = 3; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title3", ss);
                    break;
                case 3:
                    no = 0; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title0", ss);
                    no = 1; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title1", ss);
                    no = 2; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title2", ss);
                    no = 3; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title3", ss);
                    no = 4; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title4", ss);
                    break;
                case 4:
                    no = 0; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title0", ss);
                    no = 1; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title" + (1 + kinsyuCnt).ToString(), ss);
                    break;
                case 5:
                    no = 0; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title0", ss);
                    no = 1; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title" + (1 + kinsyuCnt).ToString(), ss);
                    no = 1; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title" + (2 + kinsyuCnt).ToString(), ss);
                    break;
                case 6:
                    no = 0; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title0", ss);
                    no = 1; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title1", ss);
                    no = 2; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title2", ss);
                    no = 3; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title3", ss);
                    no = 4; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title4", ss);
                    no = 5; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title5", ss);
                    no = 6; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title6", ss);
                    no = 7; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title7", ss);
                    no = 8; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title8", ss);
                    no = 9; ss = listBox2.Items[no].ToString(); if (titleBase[no] != ss) iniP2.WriteString("Settings", "Title9", ss);
                    break;
            }
            String[] sp = null;
            for (int i = 0; i < listBox3.Items.Count; i++)
            {
                sp = SgNet.COM.String_s.Sprit(listBox3.Items[i].ToString(), "=");
                if(sp[1] != "")
                {
                    iniP2.WriteString("Settings", "Width" + i.ToString(), sp[1]);
                }
            }
            iniP2.Save();

            SgNet.COM.MessageBox_s.ShowInfomation(Application.StartupPath + "\\MsgString.ini", "Msg", "1", "Complete");
         }

        private void InitSetting_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = iniP.ReadInt("Settings", "GridPattern", 0);
            textBox1.Text = iniP.ReadString("Settings", "MoneyCount", "");
            checkBox1.Checked = (iniP.ReadInt("Settings", "GloryDLL", 0) == 0? false: true);

            checkBox2.Checked = (iniP.ReadInt("Settings", "Infomation_BigPanel", 0) == 0 ? false : true);
            checkBox3.Checked = (iniP.ReadInt("Settings", "Infomation_LittlePanel", 0) == 0 ? false : true);
            checkBox4.Checked = (iniP.ReadInt("Settings", "Infomation_MaisuPanel", 0) == 0 ? false : true);
            checkBox5.Checked = (iniP.ReadInt("Settings", "Infomation_ProgresPanel", 0) == 0 ? false : true);
            textBox2.Text = iniP.ReadString("Settings", "Address", "");

            int kinsyuCnt = 0;
            int.TryParse(textBox1.Text, out kinsyuCnt);

            //金種情報をセット
            String ss = "";
            int no = 0;
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                ss = iniP.ReadString("Settings", "Money" + i.ToString(), "");
                listBox1.Items[i] = (ss != "" ? ss : listBox1.Items[i]);
            }
            
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    no = 0; ss = iniP.ReadString("Settings", "Title0", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 1; ss = iniP.ReadString("Settings", "Title1", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 2; ss = iniP.ReadString("Settings", "Title2", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    break;
                case 1:
                    no = 0; ss = iniP.ReadString("Settings", "Title0", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 1; ss = iniP.ReadString("Settings", "Title1", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 2; ss = iniP.ReadString("Settings", "Title2", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 3; ss = iniP.ReadString("Settings", "Title3", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    break;
                case 2:
                    no = 0; ss = iniP.ReadString("Settings", "Title0", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 1; ss = iniP.ReadString("Settings", "Title1", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 2; ss = iniP.ReadString("Settings", "Title2", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 3; ss = iniP.ReadString("Settings", "Title3", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    break;
                case 3:
                    no = 0; ss = iniP.ReadString("Settings", "Title0", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 1; ss = iniP.ReadString("Settings", "Title1", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 2; ss = iniP.ReadString("Settings", "Title2", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 3; ss = iniP.ReadString("Settings", "Title3", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 4; ss = iniP.ReadString("Settings", "Title4", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    break;
                case 4:
                    no = 0; ss = iniP.ReadString("Settings", "Title0", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 1; ss = iniP.ReadString("Settings", "Title" + (1 + kinsyuCnt).ToString(), ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    break;
                case 5:
                    no = 0; ss = iniP.ReadString("Settings", "Title0", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 1; ss = iniP.ReadString("Settings", "Title" + (1 + kinsyuCnt).ToString(), ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 2; ss = iniP.ReadString("Settings", "Title" + (2 + kinsyuCnt).ToString(), ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    break;
                case 6:
                    no = 0; ss = iniP.ReadString("Settings", "Title0", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 1; ss = iniP.ReadString("Settings", "Title1", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 2; ss = iniP.ReadString("Settings", "Title2", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 3; ss = iniP.ReadString("Settings", "Title3", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 4; ss = iniP.ReadString("Settings", "Title4", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 5; ss = iniP.ReadString("Settings", "Title5", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 6; ss = iniP.ReadString("Settings", "Title6", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 7; ss = iniP.ReadString("Settings", "Title7", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 8; ss = iniP.ReadString("Settings", "Title8", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    no = 9; ss = iniP.ReadString("Settings", "Title9", ""); listBox2.Items[no] = (ss != "" ? ss : listBox2.Items[no]);
                    break;
            }
            for (int i = 0; i < listBox3.Items.Count; i++)
            {
                ss = iniP.ReadString("Settings", "Width" + i.ToString(), "");
                listBox3.Items[i] = (ss != "" ? i.ToString() + "=" + ss : listBox3.Items[i]);
            }
            String[] lst = SgNet.COM.File_s.PathList(Application.StartupPath + "\\Command", "*.xml");
            if (lst != null)
            {
                for (int i = 0; i < lst.Length; i++)
                {
                    listBox4.Items.Add(SgNet.COM.File_s.Path2FileNameWithoutEx(lst[i]));
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (beforeItemNo == comboBox1.SelectedIndex)
            {
                return;
            }
            else if (beforeItemNo != -1)
            {
                if (SgNet.COM.MessageBox_s.ShowYesNo("②③④の内容が初期化されますが実施してもいいですか？") == DialogResult.No)
                {
                    comboBox1.SelectedIndex = beforeItemNo;
                    return;
                }
            }
            beforeItemNo = comboBox1.SelectedIndex;
            iniP.WriteInt("Settings", "GridPattern", comboBox1.SelectedIndex);
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                case 1:
                case 2:
                case 3:
                    textBox1.Enabled = false;
                    button6.Enabled = false;
                    textBox1.Text = "";
                    textBox1_TextChanged(null, null);
                    break;
                case 4:
                case 5:
                case 6:
                    textBox1.Enabled = true;
                    button6.Enabled = true;
                    textBox1_TextChanged(null, null);
                    break;
            }
            listBox2.Items.Clear();
            titleBase.Clear();

            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    titleBase.Add("Command");
                    titleBase.Add("Comment");
                    titleBase.Add("Result");
                    break;
                case 1:
                    titleBase.Add("Command");
                    titleBase.Add("Comment");
                    titleBase.Add("End");
                    titleBase.Add("Count");
                    break;
                case 2:
                    titleBase.Add("Command");
                    titleBase.Add("Comment");
                    titleBase.Add("Value");
                    titleBase.Add("Result");
                    break;
                case 3:
                    titleBase.Add("Command");
                    titleBase.Add("Comment");
                    titleBase.Add("Value");
                    titleBase.Add("End");
                    titleBase.Add("Count");
                    break;
                case 4:
                    titleBase.Add("Command");
                    titleBase.Add("Result");
                    break;
                case 5:
                    titleBase.Add("Command");
                    titleBase.Add("End");
                    titleBase.Add("Count");
                    break;
                case 6:
                    titleBase.Add("Cmd1");
                    titleBase.Add("Cmd2");
                    titleBase.Add("Cmd3");
                    titleBase.Add("Cmd4");
                    titleBase.Add("Cmd5");
                    titleBase.Add("Cmd6");
                    titleBase.Add("Cmd7");
                    titleBase.Add("Cmd8");
                    titleBase.Add("End");
                    titleBase.Add("Count");
                    break;
            }
            for (int i = 0; i < titleBase.Count; i++)
            {
                listBox2.Items.Add(titleBase[i]);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int kinsyuCount = 0;
            int.TryParse(textBox1.Text, out kinsyuCount);

            //金種情報のセット
            for (int a = listBox1.Items.Count - 1; a >= 0; a--)
            {
                if (listBox1.Items.Count <= kinsyuCount) break;
                listBox1.Items.RemoveAt(listBox1.Items.Count - 1);
            }
            for (int a = listBox1.Items.Count; a < kinsyuCount; a++)
            {
                listBox1.Items.Add("money" + a.ToString());
            }
            int row = 0;

            widthBase.Clear();
            listBox3.Items.Clear();
            //Widthのセット
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    row = 3;
                    break;
                case 1:
                    row = 4;
                    break;
                case 2:
                    row = 4;
                    break;
                case 3:
                    row = 5;
                    break;
                case 4:
                    row = 2 + kinsyuCount;
                    break;
                case 5:
                    row = 3 + kinsyuCount;
                    break;
                case 6:
                    row = 10;
                    break;
            }

            for (int i = 0; i < row; i++)
            {
                widthBase.Add(i.ToString() + "=");
            }
            for (int i = 0; i < widthBase.Count; i++)
            {
                listBox3.Items.Add(widthBase[i]);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel == -1) return;
            String ss = listBox1.Items[sel].ToString();
            bool okFlg = false;
            ss = SgNet.COM.Form_s.InputForm(ss, "金種名を入力してください", "金種", false, out okFlg);
            if (okFlg && ss != "") listBox1.Items[sel] = ss;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            int sel = listBox2.SelectedIndex;
            if (sel == -1) return;
            String ss = listBox2.Items[sel].ToString();
            bool okFlg = false;
            ss = SgNet.COM.Form_s.InputForm(ss, "タイトルを入力してください", "タイトル", false, out okFlg);
            if (okFlg && ss != "") listBox2.Items[sel] = ss;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int sel = listBox3.SelectedIndex;
            if (sel == -1) return;
            String ss = listBox3.Items[sel].ToString();
            String[] sp = SgNet.COM.String_s.Sprit(ss, "=");
            bool okFlg = false;
            ss = SgNet.COM.Form_s.InputForm(sp[1], "列幅を入力してください", "列幅", false, out okFlg);
            if (okFlg) listBox3.Items[sel] = sp[0] + "=" + ss;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool okFlg = false;
            String fileName = SgNet.COM.Form_s.InputForm("", "ファイル名を英数字で入力してください", "ファイル名指定", false, out okFlg);
            if (fileName == "") return;
            //ダブりがないかどうかチェックする
            String path = Application.StartupPath + "\\Command";
            SgNet.COM.Dir_s.Create(path);
            path += fileName + ".xml";
            if (SgNet.COM.File_s.Exists(path))
            {
                SgNet.COM.MessageBox_s.ShowError("There is the same name file.");
                return;
            }
            //ダブってなければ、コマンドクラスをnewして、起動する
            Cmd cmd = new Cmd();
            cmd.FileName = fileName;
            cmd.SequenceName = fileName;

            //変更フォームを起動
            CmdSettingForm dlgP = new CmdSettingForm(cmd, comboBox1.SelectedIndex, checkBox1.Checked);
            if (dlgP.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }
            //ファイルの保存
            bool ret = CmdCommon.WriteCmdXML(Application.StartupPath + "\\Command\\" + fileName + ".xml", dlgP.SettingCmd);
            if (ret == false)
            {
                SgNet.COM.MessageBox_s.ShowError("保存に失敗しました");
                return;
            }
            listBox4.Items.Clear();
            String[] lst = SgNet.COM.File_s.PathList(Application.StartupPath + "\\Command", "*.xml");
            for (int i = 0; i < lst.Length; i++)
            {
                listBox4.Items.Add(SgNet.COM.File_s.Path2FileNameWithoutEx(lst[i]));
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sel = listBox4.SelectedIndex;
            if (sel == -1) return;
            String ss = listBox4.Items[sel].ToString();

            if( SgNet.COM.MessageBox_s.ShowYesNo("選択したファイル「" + ss + ".xml」を削除してもよろしいですか？") == DialogResult.No)
            {
                return;
            }
            //削除
            bool ret = SgNet.COM.File_s.Delete(Application.StartupPath + "\\Command\\" + ss + ".xml");

            if (ret == true)
            {
                SgNet.COM.MessageBox_s.ShowInfomation("削除しました");
                //画面更新
                listBox4.Items.Clear();
                String[] lst = SgNet.COM.File_s.PathList(Application.StartupPath + "\\Command", "*.xml");
                for (int i = 0; i < lst.Length; i++)
                {
                    listBox4.Items.Add(SgNet.COM.File_s.Path2FileNameWithoutEx(lst[i]));
                }
            }
            else
            {
                SgNet.COM.MessageBox_s.ShowError("削除に失敗しました");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int sel = listBox4.SelectedIndex;
            if (sel == -1) return;
            String fileName = listBox4.Items[sel].ToString();
            //ファイルの有無を確認し、読み込んで編集フォームを起動する
            if (SgNet.COM.File_s.Exists(Application.StartupPath + "\\Command\\" + fileName + ".xml") == false)
            {
                SgNet.COM.MessageBox_s.ShowError("選択されたファイルが見つかりません");
                return;
            }
            //ダブってなければ、コマンドクラスをnewして、起動する
            Cmd cmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\" + fileName + ".xml");

            //変更フォームを起動
            CmdSettingForm dlgP = new CmdSettingForm(cmd, comboBox1.SelectedIndex, checkBox1.Checked);
            if (dlgP.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }

            //ファイルの保存
            bool ret = CmdCommon.WriteCmdXML(Application.StartupPath + "\\Command\\" + fileName + ".xml", dlgP.SettingCmd);
            if (ret == false)
            {
                SgNet.COM.MessageBox_s.ShowError("保存に失敗しました");
                return;
            }
        }
    }
}
