﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Simulator
{
    public partial class InputSID : Form
    {
        SgNet.COM.File_s.IniFile_s BeforeFormInfo = new SgNet.COM.File_s.IniFile_s(Application.StartupPath + "\\BeforeFormInfo.ini");

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public InputSID()
        {
            InitializeComponent();
        }
        /// <summary>
        /// フォームロード
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void InputSID_Load(object sender, EventArgs e)
        {
            this.Text += " Version=" + SgNet.COM.Application_s.Version(System.Reflection.Assembly.GetExecutingAssembly());

            //debug******初期のファイルを作成するとき*************
            //SgNet.COM.Form_s.SaveString(Application.StartupPath + "\\FormString.ini", this);
            //****************************************************

            string Lng = BeforeFormInfo.ReadString("Form", "Lang", "CN");

            //画面のフォント・文字変更
            switch (Lng)
            {
                case "CN":
                    SgNet.COM.Form_s.LoadString(Application.StartupPath + "\\FormStringC.ini", this);
                    break;
                case "JP":
                    SgNet.COM.Form_s.LoadString(Application.StartupPath + "\\FormStringJ.ini", this);
                    break;
            }

            // カレントディレクトリの設定
            System.IO.Directory.SetCurrentDirectory(Application.StartupPath);

            //前回入力ロットを表示
            LotText.Text = BeforeFormInfo.ReadString("Form", "Lot", "");

            //ユニット設定
            switch (Lng)
            {
                case "CN":
                    UnitBox.Items.Add("出货检查");
                    UnitBox.Items.Add("流动检查");
                    UnitBox.Items.Add("识别传感器");
                    UnitBox.Items.Add("盒式200张");
                    UnitBox.Items.Add("盒式600张");
                    break;
                case "JP":
                    UnitBox.Items.Add("出荷検査");
                    UnitBox.Items.Add("流動検査");
                    UnitBox.Items.Add("識別センサ");
                    UnitBox.Items.Add("ｶｾｯﾄ200枚");
                    UnitBox.Items.Add("ｶｾｯﾄ600枚");
                    break;
            }
            UnitBox.SelectedIndex = 0;

            //パターンファイル読み込み
            string[] files = SgNet.COM.File_s.PathList(Application.StartupPath,"Pattern*.xml");
            for (int i = 0; i < files.Length; i++) {
                PatternBox.Items.Add(SgNet.COM.File_s.Path2FileName(files[i]));
            }
            if (files.Length > 0) { PatternBox.SelectedIndex = 0; }

            //言語設定
            LanguageBox.Items.Add("CN");
            LanguageBox.Items.Add("JP");
            //前回入力ロットを表示
            switch(Lng)
            {
                case "CN":
                    LanguageBox.SelectedIndex = 0;
                    break;
                case "JP":
                    LanguageBox.SelectedIndex = 1;
                    break;
            }

            //最前面に表示
            SgNet.COM.Form_s.ShowTopMost(this);
        }

        /// <summary>
        /// 号機UPボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UpBtn_Click(object sender, EventArgs e)
        {
            int sid = 0;
            String sstr = SerialNoText.Text;
            int count = sstr.Length;
            if (count == 0) count++;

            int.TryParse(SerialNoText.Text, out sid);
            sid++;
            SerialNoText.Text = sid.ToString("D" + count.ToString());
            SerialNoText.Focus();
            SerialNoText.SelectAll();
        }

        /// <summary>
        /// 号機DOWNボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DownBtn_Click(object sender, EventArgs e)
        {
            int sid = 0;
            String sstr = SerialNoText.Text;
            int count = sstr.Length;
            if (count == 0) count++;

            int.TryParse(SerialNoText.Text, out sid);
            sid--;
            if (sid < 0) sid = 0;
            SerialNoText.Text = sid.ToString("D" + count.ToString());
            SerialNoText.Focus();
            SerialNoText.SelectAll();
        }

        /// <summary>
        /// スタートボタン
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartBtn_Click(object sender, EventArgs e)
        {
            String lot = LotText.Text;
            String sid = SerialNoText.Text;
            String unit = "";
            String ptn = PatternBox.Text;
            String lang = LanguageBox.Text;

            if (lot == "" || sid == "")
            {
                switch (lang)
                {
                    case "CN":
                        SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + "\\MsgStringC.ini", "Msg", "5", "Please input Lot and SerialNo.");
                        break;
                    case "JP":
                        SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + "\\MsgStringJ.ini", "Msg", "5", "Please input Lot and SerialNo.");
                        break;
                }
                return;
            }

            switch (UnitBox.SelectedIndex)
            {
                case 0:
                    unit = "syukka";
                    break;
                case 1:
                    unit = "ryuudou";
                    break;
                case 2:
                    unit = "bv";
                    break;
                case 3:
                    unit = "k200";
                    break;
                case 4:
                    unit = "k600";
                    break;
            }

            if (unit == "ryuudou" && sid == "0")
            {
                try
                {
                    var path = System.IO.Path.Combine(Application.StartupPath, "Data", lot, unit, sid);
                    var filePaths = System.IO.Directory.GetFiles(path);
                    foreach (var filePath in filePaths)
                    {
                        System.IO.File.SetAttributes(filePath, System.IO.FileAttributes.Normal);
                        System.IO.File.Delete(filePath);
                    }

                    var directoryPaths = System.IO.Directory.GetDirectories(path);
                    foreach (var directoryPath in directoryPaths)
                    {
                        if (!System.IO.Directory.Exists(directoryPath))
                        {
                            System.IO.Directory.Delete(directoryPath);
                        }
                    }

                    System.IO.Directory.Delete(path);
                }
                catch
                {
                }
            }

            this.Hide();
            MainForm frm = new MainForm(lot, sid, unit, ptn, lang);
            frm.ShowDialog();
            this.Show();

            SerialNoText.Focus();
            SerialNoText.SelectAll();
            
            //最前面に表示
            SgNet.COM.Form_s.ShowTopMost(this);
        }

        /// <summary>
        /// フォームを閉じる
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void InputSID_FormClosing(object sender, FormClosingEventArgs e)
        {
            BeforeFormInfo.WriteString("Form", "Lot", LotText.Text);
            BeforeFormInfo.WriteString("Form", "Lang", LanguageBox.Text);
            BeforeFormInfo.Save();
            SgNet.COM.Application_s.Exit();
        }
        
        /// <summary>
        /// キーダウンイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void InputSID_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F1:
                    StartBtn_Click(null, null);
                    break;

                case Keys.F5:
                    UpBtn_Click(null, null);
                    break;

                case Keys.F6:
                    DownBtn_Click(null, null);
                    break;

                case Keys.F12:
                case Keys.Escape:
                    this.Close();
                    break;
            }
        }

        private void LanguageBox_TextChanged(object sender, EventArgs e)
        {
            int UnitIdx;
            switch (LanguageBox.Text)
            {
                case "CN":
                    SgNet.COM.Form_s.LoadString(Application.StartupPath + "\\FormStringC.ini", this);
                    UnitIdx = UnitBox.SelectedIndex;
                    UnitBox.Items.Clear();
                    UnitBox.Items.Add("出货检查");
                    UnitBox.Items.Add("流动检查");
                    UnitBox.Items.Add("识别传感器");
                    UnitBox.Items.Add("盒式200张");
                    UnitBox.Items.Add("盒式600张");
                    UnitBox.SelectedIndex = UnitIdx;
                    UnitBox.Text = UnitBox.SelectedItem.ToString();
                    break;
                case "JP":
                    SgNet.COM.Form_s.LoadString(Application.StartupPath + "\\FormStringJ.ini", this);
                    UnitIdx = UnitBox.SelectedIndex;
                    UnitBox.Items.Clear();
                    UnitBox.Items.Add("出荷検査");
                    UnitBox.Items.Add("流動検査");
                    UnitBox.Items.Add("識別センサ");
                    UnitBox.Items.Add("ｶｾｯﾄ200枚");
                    UnitBox.Items.Add("ｶｾｯﾄ600枚");
                    UnitBox.SelectedIndex = UnitIdx;
                    UnitBox.Text = UnitBox.SelectedItem.ToString();
                    break;
            }
        }
    }
}
