﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Runtime.InteropServices;
using System.IO.Ports;

//「機種毎に変更必要」と書かれている部分を修正のこと
namespace Simulator
{
    public partial class MainForm : Form
    {
        /// <summary>
        /// PLCと通信する為のシリアルポード
        /// </summary>
        private System.IO.Ports.SerialPort _serialPort = new SerialPort();

        //private List<string> Maisu = new List<string>();
        //Start・Stop・Reset・Endボタンの表示ポジション
        private Point ButtonLocation = new Point(202, 9);

        //フォームステータス
        private FormStatus NowStatus = FormStatus.Wait;
        //ロット
        private String Lot = "";
        //号機
        private String SID = "";
        //ユニット
        private String Unit = "";
        //パターンファイル
        private String PtnFile = "";
        //言語
        private String Lang = "";
        //アドレス
        private String Address = "";

        //自動サイズ列
        private int AutoResizeCol = -1;

        //結果入力列
        private int ResultCol = -1;

        //EndCount列
        private int EndCountCol = -1;

        //Count列
        private int CountCol = -1;

        //Value列
        private int ValueCol = -1;

        //コマンド列
        private List<int> CommandCol = new List<int>();

        //コメント列
        private int CommentCol = -1;

        //停止フラグ
        private bool StopFlg = false;

        //シングルコマンド時
        private bool SingleFlg = false;

        //編集フラグ
        private bool HensyuFlg = false;

        //編集前の背景色
        private Color BeforeColor = Color.Red;

        //GridパターンNo
        private int GridPatternNo = 0;

        //GloryDLLフラグ
        private bool GloryDLL = false;

        //Setting.ini
        private SgNet.COM.File_s.IniFile_s SettingIni = new SgNet.COM.File_s.IniFile_s(Application.StartupPath + "\\Settings.ini");

        //金種文字列一覧
        private List<String> KinsyuString = new List<String>();

        //タイトル文字列
        private List<String> TitleString = new List<String>();

        //列幅一覧
        private List<int> ColWidth = new List<int>();

        //ベースのコマンドリストを取得
        private List<Cmd> BaseCmdList = new List<Cmd>();

        //コピーの一時記憶領域
        private List<Cell> CopyList = new List<Cell>();

        //インフォーメーションの表示状況
        private bool Infomation_BigPanel = false;
        private bool Infomation_LittlePanel = false;
        private bool Infomation_MaisuPanel = false;
        private bool Infomation_ProgresPanel = false;

        //インフォーメーションのラベル
        Label[] UnitInfo1 = null;
        Label[] UnitInfo2 = null;

        //コマンドフォームの作成
        SQMain SQFrm = null;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public MainForm(String lot, String serialNo, String unitcode, String pattern, String language)
        {
            InitializeComponent();
            Lot = lot;
            SID = serialNo;
            Unit = unitcode;
            PtnFile = pattern;
            Lang = language;
        }

        /// <summary>
        /// フォームステータス
        /// </summary>
        private enum FormStatus
        {
            Wait,
            Move,
            Error,
            Comp
        }

        /// <summary>
        /// 判定ステータス
        /// </summary>
        private enum ResultStatus
        {
            OK,
            NG,
            None
        }

        /// <summary>
        /// フォームのステータス変更
        /// </summary>
        /// <param name="status"></param>
        private void FormStatusChange(FormStatus status)
        {
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                NowStatus = status;

                switch (status)
                {
                    case FormStatus.Wait:
                        StartBtn.Visible = true;
                        StopBtn.Visible = false;
                        ResetBtn.Visible = false;
                        EndBtn.Visible = false;
                        this.BackColor = Color.LightYellow;
                        ResultText.BackColor = Color.White;
                        ResultText.ForeColor = Color.Black;
                        ResultText.Text = "-";
                        TaskGrid.Enabled = true;
                        TaskGrid.Focus();
                        StepButton.Enabled = true;
                        ResetButton.Enabled = true;
                        SingleButton.Enabled = true;
                        LogReadButton.Enabled = true;
                        DownloadButton.Enabled = true;
                        InitSettingButton.Enabled = true;
                        PatternSettingButton.Enabled = true;
                        EndCountClearButton.Enabled = true;
                        break;

                    case FormStatus.Move:
                        StartBtn.Visible = false;
                        StopBtn.Visible = true;
                        StopBtn.Focus();
                        ResetBtn.Visible = false;
                        EndBtn.Visible = false;
                        this.BackColor = Color.DeepSkyBlue;
                        ResultText.BackColor = Color.White;
                        ResultText.ForeColor = Color.Black;
                        ResultText.Text = "-";
                        TaskGrid.Enabled = false;
                        StepButton.Enabled = false;
                        ResetButton.Enabled = false;
                        SingleButton.Enabled = false;
                        LogReadButton.Enabled = false;
                        DownloadButton.Enabled = false;
                        InitSettingButton.Enabled = false;
                        PatternSettingButton.Enabled = false;
                        EndCountClearButton.Enabled = false;
                        break;

                    case FormStatus.Error:
                        StartBtn.Visible = false;
                        StopBtn.Visible = false;
                        ResetBtn.Visible = true;
                        ResetBtn.Focus();
                        EndBtn.Visible = false;
                        this.BackColor = Color.Pink;
                        ResultText.BackColor = Color.Red;
                        ResultText.ForeColor = Color.White;
                        ResultText.Text = "NG";
                        TaskGrid.Enabled = false;
                        StepButton.Enabled = true;
                        ResetButton.Enabled = true;
                        SingleButton.Enabled = true;
                        LogReadButton.Enabled = true;
                        DownloadButton.Enabled = true;
                        InitSettingButton.Enabled = true;
                        PatternSettingButton.Enabled = true;
                        EndCountClearButton.Enabled = true;
                        var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");
                        WritePrivateProfileString("Settings", "Status", "NG", fPath);
                        //SgNet.COM.Sound_s.PlaySound(Application.StartupPath + "\\resultNG.wav");
                        break;

                    case FormStatus.Comp:
                        StartBtn.Visible = false;
                        StopBtn.Visible = false;
                        ResetBtn.Visible = false;
                        EndBtn.Visible = true;
                        this.BackColor = Color.Green;
                        ResultText.BackColor = Color.Blue;
                        ResultText.ForeColor = Color.White;
                        ResultText.Text = "OK";
                        TaskGrid.Enabled = true;
                        TaskGrid.Focus();
                        StepButton.Enabled = true;
                        ResetButton.Enabled = true;
                        SingleButton.Enabled = true;
                        LogReadButton.Enabled = true;
                        DownloadButton.Enabled = true;
                        InitSettingButton.Enabled = true;
                        PatternSettingButton.Enabled = true;
                        EndCountClearButton.Enabled = true;
                        //SgNet.COM.Sound_s.PlaySound(Application.StartupPath + "\\resultOK.wav");
                        break;
                }
            });
        }

        /// <summary>
        /// キーダウンを無効にする
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TaskGrid_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                e.Handled = true;
                //ボタンを実行する
                switch (NowStatus)
                {
                    case FormStatus.Wait:
                        StartBtn_Click(StartBtn, null);
                        break;
                    case FormStatus.Move:
                        StopBtn_Click(null, null);
                        break;
                    case FormStatus.Error:
                        ResetBtn_Click(null, null);
                        break;
                    case FormStatus.Comp:
                        EndBtn_Click(null, null);
                        break;
                }
            }
            else if (e.KeyData == Keys.Delete)
            {
                if (HensyuFlg == false) return;
                //コマンド削除
                button7_Click(null, null);
            }
            else if ((e.Modifiers & Keys.Control) == Keys.Control && e.KeyCode == Keys.C)
            {
                if (HensyuFlg == false) return;
                //コピー
                button8_Click(null, null);
            }
            else if ((e.Modifiers & Keys.Control) == Keys.Control && e.KeyCode == Keys.V)
            {
                if (HensyuFlg == false) return;
                //貼り付け
                button9_Click(null, null);
            }
        }

        /// <summary>
        /// キーダウンイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.F1:
                    if (NowStatus == FormStatus.Wait)
                    {
                        StartBtn_Click(StartBtn, null);
                    }
                    break;

                case Keys.F2:
                    if (NowStatus == FormStatus.Move)
                    {
                        StopBtn_Click(null, null);
                    }
                    break;

                case Keys.F3:
                    if (NowStatus == FormStatus.Error)
                    {
                        ResetBtn_Click(null, null);
                    }
                    break;

                case Keys.F12:
                case Keys.Escape:
                    if (NowStatus == FormStatus.Error)
                    {
                        EndBtn_Click(null, null);
                    }
                    break;
            }
        }

        private string FileNameOfMsgString()
        {
            string fname = "";
            switch (Lang)
            {
                case "CN":
                    fname = "\\MsgStringC.ini";
                    break;
                case "JP":
                    fname = "\\MsgStringJ.ini";
                    break;
            }
            return fname;
        }

        /// <summary>
        /// フォームクロージングイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (NowStatus != FormStatus.Comp)
            {
                if (SgNet.COM.MessageBox_s.ShowYesNo(Application.StartupPath + FileNameOfMsgString(), "Msg", "7", "All tests have not fished yet.\nAre you sure you want to finish?") == DialogResult.No)
                {
                    e.Cancel = true;
                    return;
                }
            }
            if (SQFrm != null) SQFrm.FormDispose();
            if (this.ErrorTimer.Enabled == true)
            {
                this.ErrorTimer.Enabled = false;
            }
            SgNet.COM.Time_s.Sleep(100);
        }

        /// <summary>
        /// Gridの選択CELL変更
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TaskGrid_SelectionChanged(object sender, EventArgs e)
        {
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                try
                {
                    //選択行をDataGridViewの真ん中に持っていく
                    bool enable = TaskGrid.Enabled;
                    TaskGrid.Enabled = true;

                    int row = TaskGrid.CurrentCell.RowIndex;
                    int max = TaskGrid.RowCount;
                    int display = TaskGrid.DisplayedRowCount(false);
                    int first = row + (display / 2) - display;
                    if (first < 0) first = 0;

                    TaskGrid.FirstDisplayedScrollingRowIndex = first;

                    TaskGrid.Enabled = enable;
                }
                catch { }
            });
        }

        /// <summary>
        /// デバッグ画面表示のチェック変更
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DebugCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (DebugCheckBox.Checked == true)
            {
                bool returnFlg = false;
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    if (SgNet.COM.MessageBox_s.ShowYesNo(Application.StartupPath + FileNameOfMsgString(), "Msg", "8", "This is debug mode.\nAre you sure you want debug?")
                        == DialogResult.No)
                    {
                        DebugCheckBox.Checked = false;
                        returnFlg = true;
                    }
                });
                if (returnFlg) return;

                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    //SplitContainerのpanel2の表示
                    splitContainer1.Panel2Collapsed = false;
                    splitContainer1.BorderStyle = BorderStyle.FixedSingle;
                });
            }
            else
            {
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    if (HensyuFlg == true)
                    {
                        PatternSettingButton_Click(null, null);
                    }
                    //SplitContainerのpanel2の非表示
                    splitContainer1.Panel2Collapsed = true;
                    splitContainer1.BorderStyle = BorderStyle.None;
                });
            }
        }

        /// <summary>
        /// 終了ボタン押下
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void EndBtn_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            this.Close();
        }

        /// <summary>
        /// Gridの初期化
        /// </summary>
        /// <param name="iniPath">iniパス</param>
        private void GridInit()
        {
            GridPatternNo = SettingIni.ReadInt("Settings", "GridPattern", 0);
            int kinsyuCount = SettingIni.ReadInt("Settings", "MoneyCount", 0);
            if (kinsyuCount != 0)
            {
                //列の追加
                KinsyuInfoGrid.ColumnCount = 1;
                //ヘッダテキストのセット
                KinsyuInfoGrid.Columns[0].HeaderText = "";
                //ソートはプログラム
                KinsyuInfoGrid.Columns[0].SortMode = DataGridViewColumnSortMode.Programmatic;
                //自動列幅調整
                KinsyuInfoGrid.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                //行の追加
                KinsyuInfoGrid.RowCount = 2;
                //ヘッダテキストのセット
                switch (Lang)
                {
                    case "CN":
                        KinsyuInfoGrid[0, 0].Value = "指示枚数";
                        KinsyuInfoGrid[0, 1].Value = "计数枚数";
                        break;
                    case "JP":
                        KinsyuInfoGrid[0, 0].Value = "指示枚数";
                        KinsyuInfoGrid[0, 1].Value = "計数枚数";
                        break;
                }
                //色を変える
                KinsyuInfoGrid[0, 0].Style.BackColor = Color.LightBlue;
                //フォーカスを外す
                KinsyuInfoGrid.ClearSelection();
            }
            for (int i = 0; i < kinsyuCount; i++)
            {
                KinsyuString.Add(SettingIni.ReadString("Settings", "Money" + i.ToString(), "money" + i.ToString()));
                //列の追加
                KinsyuInfoGrid.ColumnCount = i + 2;
                //ヘッダテキストのセット
                KinsyuInfoGrid.Columns[i + 1].HeaderText = KinsyuString[i];
                //ソートはプログラム
                KinsyuInfoGrid.Columns[i + 1].SortMode = DataGridViewColumnSortMode.Programmatic;
                //自動列幅調整
                KinsyuInfoGrid.Columns[i + 1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                //色を変える
                KinsyuInfoGrid[i + 1, 0].Style.BackColor = Color.LightBlue;
            }
            int colCount = 0;
            switch (GridPatternNo)
            {
                case 0:
                    colCount = 3;
                    TitleString.Add(SettingIni.ReadString("Settings", "Title0", "Command"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title1", "Comment"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title2", "Result"));
                    AutoResizeCol = 1;
                    CommentCol = 1;
                    ResultCol = 2;
                    EndCountCol = -1;
                    CountCol = -1;
                    ValueCol = -1;
                    CommandCol.Add(0);
                    TaskGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    break;
                case 1:
                    colCount = 4;
                    TitleString.Add(SettingIni.ReadString("Settings", "Title0", "Command"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title1", "Comment"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title2", "End"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title3", "Count"));
                    AutoResizeCol = 1;
                    CommentCol = 1;
                    ResultCol = -1;
                    EndCountCol = 2;
                    CountCol = 3;
                    ValueCol = -1;
                    CommandCol.Add(0);
                    TaskGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    break;
                case 2:
                    colCount = 4;
                    TitleString.Add(SettingIni.ReadString("Settings", "Title0", "Command"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title1", "Comment"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title2", "Value"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title3", "Result"));
                    AutoResizeCol = 1;
                    CommentCol = 1;
                    ValueCol = 2;
                    ResultCol = 3;
                    EndCountCol = -1;
                    CountCol = -1;
                    CommandCol.Add(0);
                    TaskGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    break;
                case 3:
                    colCount = 5;
                    TitleString.Add(SettingIni.ReadString("Settings", "Title0", "Command"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title1", "Comment"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title2", "Value"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title3", "End"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title4", "Count"));
                    AutoResizeCol = 1;
                    CommentCol = 1;
                    ValueCol = 2;
                    ResultCol = -1;
                    EndCountCol = 3;
                    CountCol = 4;
                    CommandCol.Add(0);
                    TaskGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    break;
                case 4:
                    colCount = 2 + KinsyuString.Count;
                    TitleString.Add(SettingIni.ReadString("Settings", "Title0", "Command"));
                    for (int i4 = 0; i4 < KinsyuString.Count; i4++)
                    {
                        TitleString.Add(KinsyuString[i4]);
                    }
                    TitleString.Add(SettingIni.ReadString("Settings", "Title" + (1 + KinsyuString.Count).ToString(), "Result"));
                    AutoResizeCol = -1;
                    CommentCol = -1;
                    ValueCol = -1;
                    ResultCol = 1 + KinsyuString.Count;
                    EndCountCol = -1;
                    CountCol = -1;
                    CommandCol.Add(0);
                    TaskGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    break;
                case 5:
                    colCount = 3 + KinsyuString.Count;
                    TitleString.Add(SettingIni.ReadString("Settings", "Title0", "Command"));
                    for (int i4 = 0; i4 < KinsyuString.Count; i4++)
                    {
                        TitleString.Add(KinsyuString[i4]);
                    }
                    TitleString.Add(SettingIni.ReadString("Settings", "Title" + (1 + KinsyuString.Count).ToString(), "End"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title" + (2 + KinsyuString.Count).ToString(), "Count"));
                    AutoResizeCol = -1;
                    CommentCol = -1;
                    ValueCol = -1;
                    ResultCol = -1;
                    EndCountCol = 1 + KinsyuString.Count;
                    CountCol = 2 + KinsyuString.Count;
                    CommandCol.Add(0);
                    TaskGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    break;
                case 6:
                    colCount = 2 + 8;
                    TitleString.Add(SettingIni.ReadString("Settings", "Title0", "Cmd1"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title1", "Cmd2"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title2", "Cmd3"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title3", "Cmd4"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title4", "Cmd5"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title5", "Cmd6"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title6", "Cmd7"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title7", "Cmd8"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title8", "End"));
                    TitleString.Add(SettingIni.ReadString("Settings", "Title9", "Count"));
                    AutoResizeCol = -1;
                    CommentCol = -1;
                    ValueCol = -1;
                    ResultCol = -1;
                    EndCountCol = 8;
                    CountCol = 9;
                    for (int a = 0; a < 8; a++)
                    {
                        CommandCol.Add(a);
                    }
                    TaskGrid.SelectionMode = DataGridViewSelectionMode.CellSelect;
                    break;
            }

            ColWidth = new List<int>();
            for (int i = 0; i < colCount; i++)
            {
                ColWidth.Add(SettingIni.ReadInt("Settings", "Width" + i.ToString(), -1));
            }

            //グリッドの初期化
            TaskGrid.ColumnCount = colCount;
            for (int i = 0; i < colCount; i++)
            {
                //ヘッダテキストのセット
                TaskGrid.Columns[i].HeaderText = TitleString[i];
                //ソートはプログラム
                TaskGrid.Columns[i].SortMode = DataGridViewColumnSortMode.Programmatic;
                //セルのテキストを折り返して表示する
                TaskGrid.Columns[i].DefaultCellStyle.WrapMode = DataGridViewTriState.True;
            }

            //グリッドの列幅設定
            for (int i = 0; i < colCount; i++)
            {
                if (ColWidth[i] == -1)
                {
                    //自動列幅調整
                    TaskGrid.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                }
                else
                {
                    //固定サイズをセット
                    TaskGrid.Columns[i].Width = ColWidth[i];
                }
            }
            if (GridPatternNo == 6)
            {
                for (int i = 0; i < 8; i++)
                {
                    int width = TaskGrid.Columns[i].Width;
                    //列幅固定
                    TaskGrid.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                    //固定サイズをセット
                    TaskGrid.Columns[i].Width = width;
                }
                TaskGrid.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
            }
            if (AutoResizeCol != -1)
            {
                TaskGrid.Columns[AutoResizeCol].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
                TaskGrid_Resize(null, null);
            }
        }

        /// <summary>
        /// GridのResizeイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TaskGrid_Resize(object sender, EventArgs e)
        {
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                try
                {
                    if (UnitInfo1 != null)
                    {
                        //UnitInfo2のサイズ＆表示位置変更
                        int totalWidth = UnitInfo1[0].Size.Width;
                        int top = UnitInfo2[0].Location.Y;
                        int left = UnitInfo2[0].Location.X;
                        int height = UnitInfo2[0].Size.Height;
                        int splitX = UnitInfo2[1].Location.X - (left + UnitInfo2[0].Size.Width);
                        int splitY = UnitInfo2[8].Location.Y - (top + height);
                        int oneWidth = (totalWidth / 8);
                        for (int i = 0; i < UnitInfo2.Length; i++)
                        {
                            UnitInfo2[i].Location = new Point(oneWidth * (i % 8), (i / 8) * (height + splitY));
                            UnitInfo2[i].Size = new Size(oneWidth - splitX, height);
                        }
                    }
                }
                catch { }
            });

            if (AutoResizeCol == -1) return;
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                int totalSize = 0;
                int maxSize = TaskGrid.Width - 30 - TaskGrid.RowHeadersWidth;
                int cols = TaskGrid.ColumnCount;
                for (int i = 0; i < cols; i++)
                {
                    if (i != AutoResizeCol)
                    {
                        totalSize += TaskGrid.Columns[i].Width;
                    }
                }
                try
                {
                    if (maxSize - totalSize >= 0)
                    {
                        TaskGrid.Columns[AutoResizeCol].Width = maxSize - totalSize;
                    }
                }
                catch { }
            });
        }

        /// <summary>
        /// ファイル名（タイトル）から基本コマンドを取得する
        /// </summary>
        /// <param name="fileTitle">ファイルのタイトル</param>
        /// <returns></returns>
        private Cmd GetBaseCmd(String fileTitle)
        {
            for (int i = 0; i < BaseCmdList.Count; i++)
            {
                if (BaseCmdList[i].FileName == fileTitle)
                {
                    return BaseCmdList[i];
                }
            }
            return null;
        }
        /// <summary>
        /// コマンド間全体の作成
        /// </summary>
        /// <param name="cmd">コマンド</param>
        /// <returns></returns>
        private Cmd GetIntegerCmd(Cmd cmd)
        {
            Cmd cmd_Base = GetBaseCmd(cmd.FileName);
            Cmd cmdRet = new Cmd();
            cmdRet.Comment = (cmd.Comment != "" ? cmd.Comment : cmd_Base.Comment);
            cmdRet.FileName = cmd_Base.FileName;
            cmdRet.Maisu = cmd.Maisu;
            cmdRet.Parameter = (cmd.Parameter != "" ? cmd.Parameter : cmd_Base.Parameter);
            cmdRet.SequenceName = (cmd.SequenceName != "" ? cmd.SequenceName : cmd_Base.SequenceName);
            cmdRet.SequenceP = cmd_Base.SequenceP;
            return cmdRet;
        }

        /// <summary>
        /// コマンドの情報取得
        /// </summary>
        /// <param name="cmd">コマンド</param>
        /// <param name="no">0=シーケンス名　1=コメント　2=パラメータ</param>
        /// <returns></returns>
        private String GetCmdString(Cmd cmd, int no)
        {
            if ((no == 0 ? cmd.SequenceName : (no == 1 ? cmd.Comment : cmd.Parameter)) == "")
            {
                for (int i = 0; i < BaseCmdList.Count; i++)
                {
                    if (BaseCmdList[i].FileName == cmd.FileName)
                    {
                        return (no == 0 ? BaseCmdList[i].SequenceName : (no == 1 ? BaseCmdList[i].Comment : BaseCmdList[i].Parameter));
                    }
                }
                return "";
            }
            else
            {
                return (no == 0 ? cmd.SequenceName : (no == 1 ? cmd.Comment : cmd.Parameter));
            }
        }

        /// <summary>
        /// パターンファイルの読み込み
        /// </summary>
        /// <param name="loadResultPath">過去結果のファイルパス</param>
        /// <param name="initPatternPath">過去結果が無かった場合に読み込むパターンファイル</param>
        private void ReadPattern(String loadResultPath, String initPatternPath)
        {
            //ファイルを読み込む
            String path = (SgNet.COM.File_s.Exists(loadResultPath) ? loadResultPath : (SgNet.COM.File_s.Exists(initPatternPath) ? initPatternPath : ""));
            if (path == "")
            {
                FormStatusChange(FormStatus.Comp);
                return;
            }
            PatternNameLabel.Text = (SgNet.COM.File_s.Exists(loadResultPath) ? "RunResult.xml" : PtnFile);

            List<PatternRow> lst = CmdCommon.ReadPatternXML(path);
            if (lst == null)
            {
                //SgNet.COM.MessageBox_s.ShowError(SgNet.COM.Debug_s.LastErrorString);
                return;
            }
            //列の設定
            TaskGrid.RowCount = lst[lst.Count - 1].RowNo + 1;

            //TaskGridへ展開する
            for (int i = 0; i < lst.Count; i++)
            {
                int row = lst[i].RowNo;
                if (CountCol != -1) TaskGrid[CountCol, row].Value = lst[i].Count;
                if (EndCountCol != -1) TaskGrid[EndCountCol, row].Value = lst[i].EndCount;
                if (ResultCol != -1) TaskGrid[ResultCol, row].Value = lst[i].Result;
                if (ValueCol != -1) TaskGrid[ValueCol, row].Value = lst[i].Value;
                for (int c = 0; c < lst[i].RowData.Count; c++)
                {
                    int col = -1;
                    for (int i2 = 0; i2 < CommandCol.Count; i2++)
                    {
                        if (CommandCol[i2] == lst[i].RowData[c].ColNo)
                        {
                            col = lst[i].RowData[c].ColNo;
                            break;
                        }
                    }
                    if (col != -1)
                    {
                        TaskGrid[col, row].Tag = lst[i].RowData[c].CmdData;
                        TaskGrid[col, row].Value = GetCmdString(lst[i].RowData[c].CmdData, 0);
                        if (GridPatternNo == 0 || GridPatternNo == 1 || GridPatternNo == 2 || GridPatternNo == 3)
                        {
                            //コメントの設定
                            TaskGrid[CommentCol, row].Value = GetCmdString(lst[i].RowData[c].CmdData, 1);
                        }
                        else if (GridPatternNo == 4 || GridPatternNo == 5)
                        {
                            //金種の設定
                            for (int i3 = 0; i3 < lst[i].RowData[c].CmdData.Maisu.Count; i3++)
                            {
                                try
                                {
                                    TaskGrid[i3 + 1, row].Value = lst[i].RowData[c].CmdData.Maisu[i3];
                                }
                                catch { }
                            }
                        }
                    }
                }
            }

            if (ResultCol != -1)
            {
                //OK NGの色をつけていく
                for (int i = 0; i < TaskGrid.RowCount; i++)
                {
                    //センター寄せ
                    TaskGrid[ResultCol, i].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    switch (TaskGrid[ResultCol, i].Value.ToString())
                    {
                        case "OK":
                            TaskGrid[ResultCol, i].Style.ForeColor = Color.Blue;
                            break;
                        case "NG":
                            TaskGrid[ResultCol, i].Style.ForeColor = Color.Red;
                            break;
                        case "":
                            TaskGrid[ResultCol, i].Style.ForeColor = Color.Black;
                            break;
                    }
                }
            }

            //総合判定を決定する
            int hantei = 1;
            for (int i = 0; i < TaskGrid.RowCount; i++)
            {
                if (ResultCol == -1)
                {
                    String ss1 = TaskGrid[EndCountCol, i].Value.ToString();
                    String ss2 = TaskGrid[CountCol, i].Value.ToString();
                    int end = 0;
                    int cnt = 0;
                    int.TryParse(ss1, out end);
                    int.TryParse(ss2, out cnt);
                    bool cmdAri = false;
                    for (int a = 0; a < CommandCol.Count; a++)
                    {
                        if (TaskGrid[CommandCol[a], i].Value != null)
                        {
                            if (TaskGrid[CommandCol[a], i].Value.ToString() != "")
                            {
                                cmdAri = true;
                                break;
                            }
                        }
                    }
                    if (cmdAri & cnt == 0) cnt = 1;
                    if (end < cnt)
                    {
                        hantei = 0;
                        break;
                    }
                }
                else
                {
                    TaskGrid[0, i].Selected = true;

                    String ss = TaskGrid[ResultCol, i].Value.ToString();
                    if (ss == "NG")
                    {
                        //次の項目を選択
                        hantei = -1;
                        break;
                    }
                    else if (ss == "")
                    {
                        bool cmdAri = false;
                        for (int a = 0; a < CommandCol.Count; a++)
                        {
                            if (TaskGrid[CommandCol[a], i].Value != null)
                            {
                                if (TaskGrid[CommandCol[a], i].Value.ToString() != "")
                                {
                                    cmdAri = true;
                                    break;
                                }
                            }
                        }
                        if (cmdAri)
                        {
                            hantei = 0;
                        }
                        break;
                    }
                }
            }
            TaskGrid_SelectionChanged(null, null);

            //現在のステイータスを設定
            switch (hantei)
            {
                case 1://OK
                    FormStatusChange(FormStatus.Comp);
                    break;
                case 0://途中
                    FormStatusChange(FormStatus.Wait);
                    break;
                case -1://エラー
                    FormStatusChange(FormStatus.Error);
                    NowStatus = FormStatus.Wait;
                    StartBtn.Visible = true;
                    StopBtn.Visible = false;
                    ResetBtn.Visible = false;
                    EndBtn.Visible = false;

                    TaskGrid.Enabled = true;
                    TaskGrid.Focus();
                    break;
            }
        }

        /// <summary>
        /// 実行結果の保存
        /// </summary>
        private bool SaveResult()
        {
            String path = Application.StartupPath + "\\Data";
            //フォルダの作成
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + Lot;
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + Unit;
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + SID;
            SgNet.COM.Dir_s.Create(path);
            path += "\\RunResult.xml";

            return CmdCommon.WritePatternXML(path, CmdCommon.GetPattern(false, TaskGrid, GridPatternNo, CountCol, EndCountCol, ResultCol, ValueCol));
        }

        /// <summary>
        /// フォームロード
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_Load(object sender, EventArgs e)
        {
            //debug******初期のファイルを作成するとき*************
            //SgNet.COM.Form_s.SaveString(Application.StartupPath + "\\FormString.ini", this);
            //****************************************************
            String path1 = Application.StartupPath + "\\CommLog.txt";
            String path2 = Application.StartupPath + "\\CommLog1.txt";
            String path3 = Application.StartupPath + "\\CommLog2.txt";
            String path4 = Application.StartupPath + "\\CommLog3.txt";
            if (SgNet.COM.File_s.Exists(path4)) SgNet.COM.File_s.Delete(path4);
            if (SgNet.COM.File_s.Exists(path3)) SgNet.COM.File_s.Move(path3, path4);
            if (SgNet.COM.File_s.Exists(path2)) SgNet.COM.File_s.Move(path2, path3);
            if (SgNet.COM.File_s.Exists(path1)) SgNet.COM.File_s.Move(path1, path2);

            //画面のフォント・文字変更
            switch (Lang)
            {
                case "CN":
                    SgNet.COM.Form_s.LoadString(Application.StartupPath + "\\FormStringC.ini", this);
                    break;
                case "JP":
                    SgNet.COM.Form_s.LoadString(Application.StartupPath + "\\FormStringJ.ini", this);
                    break;
            }

            //Start/Stop/Reset/Endボタンの位置変更
            StartBtn.Location = ButtonLocation;
            StopBtn.Location = ButtonLocation;
            ResetBtn.Location = ButtonLocation;
            EndBtn.Location = ButtonLocation;

            //デバッグ情報を消す
            DebugCheckBox_CheckedChanged(null, null);

            //ロット・号機のセット
            LotText.Text = Lot;
            SerialNoText.Text = SID;
            Address = SettingIni.ReadString("Settings", "Address", "");

            //コマンドリストの取得
            String[] lst = SgNet.COM.File_s.PathList(Application.StartupPath + "\\Command", "*.xml");
            if (lst != null)
            {
                for (int i = 0; i < lst.Length; i++)
                {
                    BaseCmdList.Add(CmdCommon.ReadCmdXML(lst[i]));
                }
            }

            //GloryDLLフラグの取得
            GloryDLL = (SettingIni.ReadInt("Settings", "GloryDLL", 0) == 0 ? false : true);

            //Gridの初期化
            GridInit();

            //Infomationの設定
            Infomation_BigPanel = (SettingIni.ReadInt("Settings", "Infomation_BigPanel", 0) == 0 ? false : true);
            Infomation_LittlePanel = (SettingIni.ReadInt("Settings", "Infomation_LittlePanel", 0) == 0 ? false : true);
            Infomation_MaisuPanel = (SettingIni.ReadInt("Settings", "Infomation_MaisuPanel", 0) == 0 ? false : true);
            Infomation_ProgresPanel = (SettingIni.ReadInt("Settings", "Infomation_ProgresPanel", 0) == 0 ? false : true);
            int top = panel1.Location.Y;
            int delsize = 0;
            Size p3Size = new Size(panel3.Size.Width, panel3.Size.Height);
            if (!Infomation_BigPanel)
            {
                panel1.Visible = false;
                delsize += panel1.Height;
            }
            if (!Infomation_LittlePanel)
            {
                panel2.Visible = false;
                delsize += panel2.Height;
            }
            if (!Infomation_MaisuPanel)
            {
                panel3.Visible = false;
                delsize += panel3.Height;
            }
            if (!Infomation_ProgresPanel)
            {
                panel4.Visible = false;
            }
            else
            {
                panel4.Visible = true;
            }

            if (!Infomation_BigPanel && !Infomation_LittlePanel && !Infomation_MaisuPanel && !Infomation_ProgresPanel)
            {
                splitContainer2.Panel2Collapsed = true;
            }
            else
            {
                splitContainer2.SplitterDistance += delsize;
            }

            if (Infomation_BigPanel)
            {
                panel1.Visible = true;
                panel1.Location = new Point(24, top);
                top += panel1.Height;
            }
            if (Infomation_LittlePanel)
            {
                panel2.Visible = true;
                panel2.Location = new Point(24, top);
                top += panel2.Height;
            }
            if (Infomation_MaisuPanel)
            {
                panel3.Visible = true;
                panel3.Location = new Point(24, top);
                panel3.Size = p3Size;
                top += panel3.Height;
                if (KinsyuString.Count == 0)
                {
                    KinsyuInfoGrid.Visible = false;
                    InfomationTextBox.Location = new Point(KinsyuInfoGrid.Location.X, KinsyuInfoGrid.Location.X);
                    InfomationTextBox.Size = new Size(KinsyuInfoGrid.Size.Width + InfomationTextBox.Size.Width, InfomationTextBox.Size.Height);
                }
                else
                {
                    int width = InfomationTextBox.Size.Width;
                    int height = InfomationTextBox.Size.Height;
                    int kinsyuWidth = KinsyuInfoGrid.Size.Width;
                    int total = 0;
                    for (int i = 0; i < KinsyuInfoGrid.ColumnCount; i++)
                    {
                        total += KinsyuInfoGrid[i, 0].Size.Width;
                    }
                    total += 10;
                    KinsyuInfoGrid.Size = new Size(total, KinsyuInfoGrid.Size.Height);
                    InfomationTextBox.Location = new Point(KinsyuInfoGrid.Size.Width + 3, KinsyuInfoGrid.Location.Y);
                    try
                    {
                        InfomationTextBox.Size = new Size(kinsyuWidth - KinsyuInfoGrid.Size.Width + width, InfomationTextBox.Size.Height);
                    }
                    catch { }
                }
            }

            //インフォーメーションのラベル設定
            UnitInfo1 = new Label[]
            {
                Info1_1,
                Info1_2,
                Info1_3
            };
            UnitInfo2 = new Label[]
            {
                Info2_1_1,
                Info2_1_2,
                Info2_1_3,
                Info2_1_4,
                Info2_1_5,
                Info2_1_6,
                Info2_1_7,
                Info2_1_8,
                Info2_2_1,
                Info2_2_2,
                Info2_2_3,
                Info2_2_4,
                Info2_2_5,
                Info2_2_6,
                Info2_2_7,
                Info2_2_8,
                Info2_3_1,
                Info2_3_2,
                Info2_3_3,
                Info2_3_4,
                Info2_3_5,
                Info2_3_6,
                Info2_3_7,
                Info2_3_8,
            };

            //パターンファイルの読み込み ※前回結果がある場合は結果も読み込む
            ReadPattern(Application.StartupPath + "\\Data\\" + Lot + "\\" + Unit + "\\" + SID + "\\RunResult.xml", Application.StartupPath + "\\" + PtnFile);

            //CmdFormの通知イベント設定
            SQFrm = new SQMain(this, Address, SettingIni, Lot, SID, Unit, Lang);
            SQFrm.ChangeInfoEvent += new SQMain.DelegateChangeInfo(ChangeInfo);
            SQFrm.ChangeFormColorEvent += new SQMain.DelegateChangeFormColor(ChangeFormColor);
            SQFrm.ChangeMaisuEvent += new SQMain.DelegateChangeMaisu(ChangeMaisu);
            SQFrm.NotifyCompleteEvent += new SQMain.DelegateNotifyComplete(NotifyComplete);
            SQFrm.NotifyCompleteMultiLineEvent += new SQMain.DelegateNotifyCompleteMultiLine(NotifyCompleteMultiLine);
            SQFrm.ChangeProgressBarEvent += new SQMain.DelegateChangeProgressBar(ChangeProgressBar);
            SgNet.COM.Form_s.HideShow(SQFrm);

            try
            {
                //Gridのリサイズ
                TaskGrid_Resize(null, null);
                this.ErrorTimer.Start();
            }
            catch { }

            //最前面に表示
            SgNet.COM.Form_s.ShowTopMost(this);
        }

        //行番号の自動入力
        private void TaskGrid_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            DataGridView dgv = (DataGridView)sender;
            if (dgv.RowHeadersVisible)
            {
                //行番号を描画する範囲を決定する
                Rectangle rect = new Rectangle(
                    e.RowBounds.Left, e.RowBounds.Top,
                    dgv.RowHeadersWidth, e.RowBounds.Height);
                rect.Inflate(-2, -2);
                //行番号を描画する
                TextRenderer.DrawText(e.Graphics,
                    (e.RowIndex + 1).ToString(),
                    e.InheritedRowStyle.Font,
                    rect,
                    e.InheritedRowStyle.ForeColor,
                    TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
            }
            if (GridPatternNo == 6)
            {
                int mostHeight = 0;
                int height = 0;
                StringFormat sf = new StringFormat();
                sf.Trimming = StringTrimming.Character; //これ
                String ss = "";
                for (int a = 0; a < 8; a++)
                {
                    try
                    {
                        ss = dgv[a, e.RowIndex].Value.ToString();
                        SizeF stringSize = e.Graphics.MeasureString(ss, dgv.Font, dgv[a, e.RowIndex].ContentBounds.Width, sf);
                        height = (int)stringSize.Height + 1;
                    }
                    catch
                    {
                        height = 0;
                    }
                    if (mostHeight < height) mostHeight = height;
                }
                dgv.Rows[e.RowIndex].Height = (mostHeight > dgv.RowTemplate.Height ? mostHeight : dgv.RowTemplate.Height);
            }
        }

        /// <summary>
        /// 判定を書き込む
        /// </summary>
        /// <param name="row"></param>
        /// <param name="status"></param>
        private void ResultWrite(int row, int col, String value, ResultStatus status)
        {
            ResultWrite(row, col, value, status, false);
        }
        /// <summary>
        /// 判定を書き込む
        /// </summary>
        /// <param name="row"></param>
        /// <param name="status"></param>
        private void ResultWrite(int row, int col, String value, ResultStatus status, bool NoSave)
        {
            if (SingleFlg) return;
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                if (ResultCol != -1)
                {
                    //結果列がある場合
                    if (ValueCol != -1)
                    {
                        //値列がある場合
                        TaskGrid[ValueCol, row].Value = value;
                    }
                    TaskGrid[ResultCol, row].Value = (status == ResultStatus.OK ? "OK" : (status == ResultStatus.NG ? "NG" : ""));
                    //センター寄せ
                    TaskGrid[ResultCol, row].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    switch (status)
                    {
                        case ResultStatus.OK:
                            TaskGrid[ResultCol, row].Style.ForeColor = Color.Blue;
                            break;
                        case ResultStatus.NG:
                            TaskGrid[ResultCol, row].Style.ForeColor = Color.Red;
                            break;
                        case ResultStatus.None:
                            TaskGrid[ResultCol, row].Style.ForeColor = Color.Black;
                            break;
                    }
                }
                else
                {
                    //結果列がない場合
                    if (ValueCol != -1)
                    {
                        //値列がある場合
                        TaskGrid[ValueCol, row].Value = value.ToString();
                    }
                    if (status == ResultStatus.OK)
                    {
                        bool countUp = true;
                        if (GridPatternNo == 6)
                        {
                            //横移動 横を見てなければ、カウントアップ
                            for (int i = 0; i < CommandCol.Count; i++)
                            {
                                if (CommandCol[i] > col)
                                {
                                    if (TaskGrid[CommandCol[i], row].Tag != null)
                                    {
                                        countUp = false;
                                    }
                                }
                            }
                        }
                        else
                        {
                            //縦移動
                        }
                        //カウントアップ
                        if (countUp)
                        {
                            int cnt = 0;
                            String ss = (TaskGrid[EndCountCol, row].Value == null ? "" : TaskGrid[EndCountCol, row].Value.ToString());
                            int.TryParse(ss, out cnt);
                            TaskGrid[EndCountCol, row].Value = (cnt + 1).ToString();
                        }
                    }
                    else
                    {
                        //基本的にはなにもしない
                    }
                }
            });
            if (NoSave == false)
            {
                SaveResult();
            }
        }

        /// <summary>
        /// スタートボタン押下
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartBtn_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            SingleFlg = false;
            //下に書かれている判定・終了回数を消す
            int row = TaskGrid.CurrentCell.RowIndex;
            if (row == -1) return;
            for (int i = row + 1; i < TaskGrid.RowCount; i++)
            {
                if (ResultCol == -1)
                {
                    TaskGrid[EndCountCol, i].Value = "";
                }
                else
                {
                    TaskGrid[ResultCol, i].Value = "";
                    TaskGrid[ResultCol, i].Style.ForeColor = Color.Black;
                }
            }
            if (sender != null) StopFlg = false;
            else StopFlg = true;
            //もし現在セルが空白の場合は、次の行へ移動だけして停止
            int col = TaskGrid.CurrentCell.ColumnIndex;
            if (col == -1) return;
            if (GridPatternNo != 6) col = CommandCol[0];

            if (TaskGrid[col, row].Tag == null)
            {
                NextCurMove(row, col, false);
                return;
            }
            else
            {
                FormStatusChange(FormStatus.Move);
                var maisuPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Maisu.ini");
                //日時設定
                WritePrivateProfileString("Kensa2", "Pat", "DateTimeSet", maisuPath);
                bool ret = StartCmd(GetBaseCmd("DateTimeSet"), null, -1, -1);//文字列はファイル名の拡張子を除いたもの
                if (ret == false)
                {
                    FormStatusChange(FormStatus.Error);
                    SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
                }
                else
                {
                    while (SQFrm.MainThread1 != null)
                    {
                        System.Windows.Forms.Application.DoEvents();
                        System.Threading.Thread.Sleep(1);
                    }
                    while (SQFrm.CompWaitThread != null)
                    {
                        System.Windows.Forms.Application.DoEvents();
                        System.Threading.Thread.Sleep(1);
                    }
                    //実行

                    var cmd = GetIntegerCmd((Cmd)TaskGrid[col, row].Tag);

                    var flg = false;
                    if (cmd.FileName == "NempChkSyukkin" && cmd.Maisu[3] == "200")
                    {
                        WritePrivateProfileString("Status", "NempChkFlg", "True", maisuPath);
                        flg = true;
                    }
                    else
                    {
                        WritePrivateProfileString("Status", "NempChkFlg", "False", maisuPath);
                    }

                    if (cmd.FileName == "NempChkSyukkin" && cmd.Maisu[3] == "495")
                    {
                        WritePrivateProfileString("Status", "NempChkFlg495", "True", maisuPath);
                        flg = true;
                    }
                    else
                    {
                        WritePrivateProfileString("Status", "NempChkFlg495", "False", maisuPath);
                    }

                    if (cmd.FileName == "Nyukin" && cmd.Maisu[0] == "0" && cmd.Maisu[1] == "0" && cmd.Maisu[2] == "0" && cmd.Maisu[3] == "495")
                    {
                        flg = true;
                    }

                    if (cmd.Maisu[2] == "4")
                    {
                        flg = true;
                    }

                    if (flg == true)
                    {
                        WritePrivateProfileString("Kensa2", "1Man", cmd.Maisu[0], maisuPath);
                        WritePrivateProfileString("Kensa2", "5Sen", cmd.Maisu[1], maisuPath);
                        WritePrivateProfileString("Kensa2", "2Sen", cmd.Maisu[2], maisuPath);
                        WritePrivateProfileString("Kensa2", "1Sen", cmd.Maisu[3], maisuPath);
                    }
                    else
                    {
                        if (cmd.FileName == "Nyukin" ||
                        cmd.FileName == "Syukkin" ||
                        cmd.FileName == "KaisyuPAYOUT" ||
                        cmd.FileName == "NempChkSyukkin" ||
                        cmd.FileName == "FullSyukkin")
                        {
                            using (var myForm = new ProcessDialog()
                            {
                                Command = cmd,
                            })
                            {
                                myForm.ShowDialog();
                            }

                            var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");
                            var stopFlg = this.GetIniValue(fPath, "Pattern", "StopFlag");
                            if (stopFlg == "True")
                            {
                                if (this.Counter.Enabled == true)
                                {
                                    this.Invoke(new Action(() => this.Counter.Stop()));
                                }
                                FormStatusChange(FormStatus.Wait);
                                return;
                            }
                            else
                            {
                                if (cmd.FileName == "Nyukin" && 
                                    cmd.Maisu[3] == "10" && 
                                    cmd.Maisu[0] == "0" &&
                                    cmd.Maisu[1] == "0" &&
                                    cmd.Maisu[2] == "0")
                                {
                                    WritePrivateProfileString("Pattern", "ExecuteFlag", "True", fPath);
                                }
                            }

                            var result = SendRobot(cmd);
                            if (result == false)
                            {
                                FormStatusChange(FormStatus.Wait);
                                return;
                            }
                        }
                    }

                    WritePrivateProfileString("Kensa2", "Pat", cmd.FileName, maisuPath);

                    ret = StartCmd(cmd, CmdCommon.GetPattern(false, TaskGrid, GridPatternNo, CountCol, EndCountCol, ResultCol, ValueCol), row, col);
                    if (ret == false)
                    {
                        FormStatusChange(FormStatus.Error);
                        SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
                    }
                    else
                    {
                        this.ResetTimer();
                    }
                }
            }
        }

        private void ResetTimer()
        {
            if (this.Counter.Enabled == true)
            {
                this.Invoke(new Action(() => this.Counter.Stop()));
            }
            this.Invoke(new Action(() => this.Counter.Start()));
        }

        private bool SendRobot(Cmd cmd)
        {
            var result = this.OpenSerialPort();
            if (result == false)
            {
                MessageBox.Show("ロボットと接続できませんでした。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }

            var sendData = new byte[3];
            sendData[0] = 2;  //テキスト開始(STX)
            sendData[2] = 3;　//テキスト終了(ETX)　

            switch (cmd.FileName)
            {
                case "Nyukin":
                    if (cmd.Maisu[0] == "999")
                    {
                        sendData[1] = 30;
                        //sendData[1] = 70;
                    }
                    else
                    {
                        sendData[1] = 30;
                    }
                    break;
                case "Syukkin":
                    sendData[1] = 20;
                    break;
                case "KaisyuPAYOUT":
                    sendData[1] = 20;
                    //sendData[1] = 60;
                    break;
                case "NempChkSyukkin":
                    sendData[1] = 20;
                    //sendData[1] = 60;
                    break;
                case "FullSyukkin":
                    sendData[1] = 20;
                    //sendData[1] = 60;
                    break;
            }

            this._serialPort.Write(sendData, 0, 3);
            Thread.Sleep(1000);

            sendData[1] = 10;
            this._serialPort.Write(sendData, 0, 3);  //データ送信

            this.CloseSerialPort();
            return true;
        }

        public string GetIniValue(string path, string section, string key)
        {
            StringBuilder sb = new StringBuilder(256);
            GetPrivateProfileString(section, key, string.Empty, sb, Convert.ToUInt32(sb.Capacity), path);
            return sb.ToString();
        }

        /// <summary>
        /// ストップボタン押下
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StopBtn_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            StopFlg = true;
        }

        /// <summary>
        /// リセットボタン押下
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetBtn_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            StopFlg = true;
            SingleFlg = true;

            FormStatusChange(FormStatus.Move);
            //機種毎に変更必要
            bool ret = StartCmd(GetBaseCmd("Reset"), null, -1, -1);//文字列はファイル名の拡張子を除いたもの
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
        }

        private void NextCurMove(int nowRow, int nowCol, bool runFlg)
        {
            int nextRowNo = -1;
            int nextColNo = -1;
            //次の項目を選択
            List<PatternRow> list = CmdCommon.GetPattern(false, TaskGrid, GridPatternNo, CountCol, EndCountCol, ResultCol, ValueCol);

            int i_row = 0;
            int i_col = 0;
            nextRowNo = -1;
            nextColNo = -1;
            for (i_row = 0; i_row < list.Count; i_row++)
            {
                if (list[i_row].RowNo >= nowRow)
                {
                    if (list[i_row].RowNo != nowRow)
                    {
                        nextRowNo = i_row;
                        nextColNo = list[i_row].RowData[0].ColNo;
                        break;
                    }
                    else
                    {
                        for (i_col = 0; i_col < list[i_row].RowData.Count; i_col++)
                        {
                            if (list[i_row].RowData[i_col].ColNo >= nowCol)
                            {
                                if (list[i_row].RowData[i_col].ColNo != nowCol)
                                {
                                    nextRowNo = i_row;
                                    nextColNo = list[i_row].RowData[i_col].ColNo;
                                    break;
                                }
                                if ((list[i_row].RowData.Count - 1) > i_col)
                                {
                                    nextRowNo = nowRow;
                                    nextColNo = list[i_row].RowData[i_col + 1].ColNo;
                                }
                                else
                                {
                                    bool next = true;
                                    if (ResultCol == -1)
                                    {
                                        //カウントをチェックする
                                        int endcount = 0;
                                        int count = 0;
                                        int.TryParse(list[i_row].EndCount, out endcount);
                                        int.TryParse(list[i_row].Count, out count);
                                        if (endcount < count)
                                        {
                                            nextRowNo = nowRow;
                                            nextColNo = list[i_row].RowData[0].ColNo;
                                            next = false;
                                        }
                                    }
                                    if (next)
                                    {
                                        if ((list.Count - 1) > i_row)
                                        {
                                            nextRowNo = list[i_row + 1].RowNo;
                                            nextColNo = list[i_row + 1].RowData[0].ColNo;
                                        }
                                    }
                                }
                                break;
                            }
                        }
                        if (i_col == list[i_row].RowData.Count)
                        {
                            bool next = true;
                            if (ResultCol == -1)
                            {
                                //カウントをチェックする
                                int endcount = 0;
                                int count = 0;
                                int.TryParse(list[i_row].EndCount, out endcount);
                                int.TryParse(list[i_row].Count, out count);
                                if (endcount < count)
                                {
                                    nextRowNo = nowRow;
                                    nextColNo = list[i_row].RowData[0].ColNo;
                                    next = false;
                                }
                            }
                            if (next)
                            {
                                if ((list.Count - 1) > i_row)
                                {
                                    nextRowNo = list[i_row + 1].RowNo;
                                    nextColNo = list[i_row + 1].RowData[0].ColNo;
                                }
                            }
                        }
                        break;
                    }
                }
            }
            if (i_row == list.Count)
            {
                //ここはそのまま終了なので何もする必要はない。
            }
            if (nextRowNo == -1)
            {
                if (ResultCol != -1)
                {
                    int okcnt = 0;
                    //ResultColがある場合、全部OKか判定
                    for (int i = 0; i < TaskGrid.RowCount; i++)
                    {
                        if (TaskGrid[ResultCol, i].Value.ToString() == "OK")
                        {
                            okcnt++;
                        }
                    }
                    //状態を判定
                    if (okcnt == TaskGrid.RowCount)
                    {
                        FormStatusChange(FormStatus.Comp);
                    }
                    else
                    {
                        FormStatusChange(FormStatus.Wait);
                    }
                }
                else
                {
                    //次は無いのでそのまま終了
                    //完了
                    FormStatusChange(FormStatus.Comp);
                }

                return;
            }
            else
            {
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    //次の行を選択
                    TaskGrid.ClearSelection();
                    TaskGrid[nextColNo, nextRowNo].Selected = true;
                });

                //空白行が間に挟んであったらストップするようにする
                if ((nextRowNo - nowRow) >= 2) StopFlg = true;
                //コマンドの実行
                if (StopFlg == true)
                {
                    FormStatusChange(FormStatus.Wait);
                }
                else
                {
                    if (runFlg == true)
                    {
                        var maisuPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Maisu.ini");
                        //実行
                        var cmd = GetIntegerCmd((Cmd)TaskGrid[nextColNo, nextRowNo].Tag);
                        var flg = false;
                        if (cmd.FileName == "NempChkSyukkin" && cmd.Maisu[3] == "200")
                        {
                            WritePrivateProfileString("Status", "NempChkFlg", "True", maisuPath);
                            flg = true;
                        }
                        else
                        {
                            WritePrivateProfileString("Status", "NempChkFlg", "False", maisuPath);
                        }

                        if (cmd.FileName == "NempChkSyukkin" && cmd.Maisu[3] == "495")
                        {
                            WritePrivateProfileString("Status", "NempChkFlg495", "True", maisuPath);
                            flg = true;
                        }
                        else
                        {
                            WritePrivateProfileString("Status", "NempChkFlg495", "False", maisuPath);
                        }

                        if (cmd.FileName == "Nyukin" && cmd.Maisu[0] == "0" && cmd.Maisu[1] == "0" && cmd.Maisu[2] == "0" && cmd.Maisu[3] == "495")
                        {
                            flg = true;
                        }

                        if (cmd.Maisu[2] == "4")
                        {
                            flg = true;
                        }

                        if (flg == true)
                        {
                            WritePrivateProfileString("Kensa2", "1Man", cmd.Maisu[0], maisuPath);
                            WritePrivateProfileString("Kensa2", "5Sen", cmd.Maisu[1], maisuPath);
                            WritePrivateProfileString("Kensa2", "2Sen", cmd.Maisu[2], maisuPath);
                            WritePrivateProfileString("Kensa2", "1Sen", cmd.Maisu[3], maisuPath);
                        }
                        else
                        {
                            if (cmd.FileName == "Nyukin" ||
                            cmd.FileName == "Syukkin" ||
                            cmd.FileName == "KaisyuPAYOUT" ||
                            cmd.FileName == "NempChkSyukkin" ||
                            cmd.FileName == "FullSyukkin")
                            {
                                using (var myForm = new ProcessDialog()
                                {
                                    Command = cmd,
                                })
                                {
                                    myForm.ShowDialog();
                                }

                                var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");
                                var stopFlg = this.GetIniValue(fPath, "Pattern", "StopFlag");
                                if (stopFlg == "True")
                                {
                                    if (this.Counter.Enabled == true)
                                    {
                                        this.Invoke(new Action(() => this.Counter.Stop()));
                                    }
                                    FormStatusChange(FormStatus.Wait);
                                    return;
                                }

                                var result = SendRobot(cmd);
                                if (result == false)
                                {
                                    FormStatusChange(FormStatus.Wait);
                                    return;
                                }
                            }
                        }

                        WritePrivateProfileString("Kensa2", "Pat", cmd.FileName, maisuPath);

                        bool ret = StartCmd(GetIntegerCmd((Cmd)TaskGrid[nextColNo, nextRowNo].Tag), CmdCommon.GetPattern(false, TaskGrid, GridPatternNo, CountCol, EndCountCol, ResultCol, ValueCol), nextRowNo, nextColNo);
                        if (ret == false)
                        {
                            FormStatusChange(FormStatus.Error);
                            SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
                        }
                        else
                        {
                            this.ResetTimer();
                        }
                    }
                }
            }
        }

        private bool OpenSerialPort()
        {
            try
            {
                this._serialPort.BaudRate = 9600;
                this._serialPort.Parity = Parity.None;
                this._serialPort.DataBits = 8;
                this._serialPort.StopBits = StopBits.One;
                this._serialPort.Handshake = Handshake.None;
                var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");
                var com = GetIniValue(fPath, "Settings", "RoboCom");
                this._serialPort.PortName = com; //暫定
                if (this._serialPort.IsOpen == false)
                {
                    this._serialPort.Open();
                }
                return true;
            }
            catch
            {
                MessageBox.Show("COM設定が間違っています。");
                return false;
            }

        }

        private void CloseSerialPort()
        {
            if (this._serialPort.IsOpen == true)
            {
                this._serialPort.Close();
            }
        }

        //1行ずつ実行
        private void StepButton_Click(object sender, EventArgs e)
        {
            StartBtn_Click(null, null);
        }
        //強制停止
        private void ForceStopButton_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            ForceStop();
            FormStatusChange(FormStatus.Wait);
        }
        //リセット
        private void ResetButton_Click(object sender, EventArgs e)
        {
            ResetBtn_Click(null, null);
        }
        //単発実行
        private void SingleButton_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            SingleFlg = true;
            Cmd cmd = null;
            if (cmd == null)
            {
                //コマンド選択画面を表示し、オブジェクトを生成してから次へ
                List<String> lst = new List<String>();
                for (int i = 0; i < BaseCmdList.Count; i++)
                {
                    lst.Add(BaseCmdList[i].SequenceName);
                }
                int selNo = SgNet.COM.Form_s.ComboBoxForm(lst, -1, "Please select command.", "wait select");
                if (selNo == -1) return;
                cmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\" + BaseCmdList[selNo].FileName + ".xml");
            }
            Cmd baseCmd = GetBaseCmd(cmd.FileName);
            CmdSettingForm dlgP = new CmdSettingForm(cmd, baseCmd, GridPatternNo, GloryDLL);
            if (dlgP.ShowDialog(this) != DialogResult.OK)
            {
                return;
            }

            FormStatusChange(FormStatus.Move);
            //処理の実行**********************
            bool ret = StartCmd(dlgP.SettingCmd, null, -1, -1);
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
        }
        //ログリード
        private void LogReadButton_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            StopFlg = true;
            SingleFlg = true;

            FormStatusChange(FormStatus.Move);
            //機種毎に変更必要
            bool ret = StartCmd(GetBaseCmd("LogRead"), null, -1, -1);//文字列はファイル名の拡張子を除いたもの
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
        }
        //ダウンロード
        private void DownloadButton_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            StopFlg = true;
            SingleFlg = true;

            FormStatusChange(FormStatus.Move);
            //機種毎に変更必要
            bool ret = StartCmd(GetBaseCmd("Download"), null, -1, -1);//文字列はファイル名の拡張子を除いたもの
            if (ret == false)
            {
                FormStatusChange(FormStatus.Error);
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
            }
        }

        //通信デバッグ用フォームの表示
        private void CommDebugFormShowButton_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            SQFormShow();
        }

        //GUIから下位への命令****************************
        //フォームの表示
        void SQFormShow()
        {
            SQFrm.FormShow();
        }
        //Dispose
        void SQFormDispose()
        {
            SQFrm.FormDispose();
        }
        //コマンドの開始
        bool StartCmd(Cmd cmd, List<PatternRow> list, int nowRow, int nowCol)
        {
            if (cmd == null)
            {
                SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "4", "There's not the command.");
                return false;
            }

            return SQFrm.StartCmd(cmd, list, nowRow, nowCol);
        }
        //強制停止
        bool ForceStop()
        {
            return SQFrm.ForceStop();
        }

        //下位からGUIへの通知****************************
        //GUIの各種情報変更通知
        void ChangeInfo(int unitNo, int idNo, String infoString, Color labelColor)
        {
            if (idNo == -1) return;
            Label l = null;
            TextBox t = null;
            try
            {
                switch (unitNo)
                {
                    case 0: l = UnitInfo1[idNo]; break;
                    case 1: l = UnitInfo2[idNo]; break;
                    case 2: t = InfomationTextBox; break;
                }
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    if (l != null)
                    {
                        l.Text = infoString;
                        if (labelColor != null)
                        {
                            l.BackColor = labelColor;
                            l.ForeColor = SgNet.COM.Form_s.Color(255 - labelColor.R, 255 - labelColor.G, 255 - labelColor.B);
                        }
                        else
                        {
                            l.BackColor = Color.White;
                            l.ForeColor = SgNet.COM.Form_s.Color(255 - labelColor.R, 255 - labelColor.G, 255 - labelColor.B);
                        }
                    }
                    else if (t != null)
                    {
                        t.Text = infoString;
                        if (labelColor != null)
                        {
                            t.BackColor = labelColor;
                            t.ForeColor = SgNet.COM.Form_s.Color(255 - labelColor.R, 255 - labelColor.G, 255 - labelColor.B);
                        }
                        else
                        {
                            t.BackColor = Color.White;
                            t.ForeColor = SgNet.COM.Form_s.Color(255 - labelColor.R, 255 - labelColor.G, 255 - labelColor.B);
                        }
                    }
                });
            }
            catch/* (Exception e)*/
            {
                //this.Invoke((MethodInvoker)delegate	//スレッドの切替
                //{
                //    MessageBox.Show(e.ToString());
                //});
            }
        }

        //GUIのフォームの色を変える
        void ChangeFormColor(Color formColor)
        {
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                this.BackColor = formColor;
            });
        }

        //GUIへの枚数変更通知
        void ChangeMaisu(List<int> maisu, int rowNo)
        {
            var path = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Maisu.ini");

            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                for (int a = 0; a < KinsyuInfoGrid.ColumnCount; a++)
                {
                    try
                    {
                        if (rowNo == 1)
                        {

                            if (a == 0)
                            {
                                WritePrivateProfileString("Kensa2", "1Man", maisu[a].ToString(), path);
                            }
                            if (a == 1)
                            {
                                WritePrivateProfileString("Kensa2", "5Sen", maisu[a].ToString(), path);
                            }
                            if (a == 2)
                            {
                                WritePrivateProfileString("Kensa2", "2Sen", maisu[a].ToString(), path);
                            }
                            if (a == 3)
                            {
                                WritePrivateProfileString("Kensa2", "1Sen", maisu[a].ToString(), path);
                            }


                        }
                        KinsyuInfoGrid[a + 1, rowNo].Value = "";
                        KinsyuInfoGrid[a + 1, rowNo].Value = maisu[a].ToString();
                        if (maisu[a] != 0)
                        {
                            KinsyuInfoGrid[a + 1, rowNo].Style.ForeColor = Color.Red;
                        }
                        else
                        {
                            KinsyuInfoGrid[a + 1, rowNo].Style.ForeColor = Color.Black;
                        }


                    }
                    catch { }
                }
            });

            if (rowNo != 1 || maisu[2] != 0)
            {
                return;
            }

            //if (this._oneM == maisu[0].ToString() &&
            //    this._fiveS == maisu[1].ToString() &&
            //    this._twoS == maisu[2].ToString() &&
            //    this._oneS == maisu[3].ToString())
            //{
            //    return;
            //}


        }
        //GUIへの完了通知
        void NotifyComplete(bool errorFlg, String value)
        {
            //if (this.Counter.Enabled == true)
            //{
            //    this.Invoke(new Action(() => this.Counter.Stop()));
            //}


            if (errorFlg)
            {
                Notify_NG(value);
            }
            else
            {
                Notify_OK(value);
            }
        }
        //OK通知時の処理
        private void Notify_OK(String value)
        {
            if (HensyuFlg == true) return;
            if (SingleFlg == true)
            {
                FormStatusChange(FormStatus.Wait);
                return;
            }

            var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Maisu.ini");
            var pat = GetIniValue(fPath, "Kensa2", "Pat");
            var twoSen = GetIniValue(fPath, "Kensa2", "2Sen");
            if (pat == "Nyukin" || pat == "Syukkin" || pat == "KaisyuPAYOUT" || pat == "NempChkSyukkin" || pat == "FullSyukkin")
            {
                if (twoSen != "4")
                {
                    this.ResetComFile();
                }
            }

            if (value == "DateTimeSet")     //DateTimeSetコマンドの場合は何もしない
            {
                return;
            }
            if (NowStatus == FormStatus.Move)
            {
                int row = 0;
                int col = 0;
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    row = TaskGrid.CurrentCell.RowIndex;
                    col = TaskGrid.CurrentCell.ColumnIndex;
                    //OKにする
                    ResultWrite(row, col, value, ResultStatus.OK);
                });

                //現在のPatternRowを検索
                NextCurMove(row, col, true);
            }
        }
        //NG通知時の処理
        private void Notify_NG(String value)
        {
            if (HensyuFlg == true) return;
            if (NowStatus == FormStatus.Move)
            {
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    int row = TaskGrid.CurrentCell.RowIndex;
                    int col = TaskGrid.CurrentCell.ColumnIndex;
                    //NGにする
                    ResultWrite(row, col, value, ResultStatus.NG);
                    FormStatusChange(FormStatus.Error);
                });
            }
        }

        //品証ツールなどの複数行まとめて実行時の処理
        void NotifyCompleteMultiLine(List<PatternRow> list)
        {
            //現在のパターンを取得
            List<PatternRow> source = CmdCommon.GetPattern(false, TaskGrid, GridPatternNo, CountCol, EndCountCol, ResultCol, ValueCol);

            //値を表示
            if (ValueCol != -1)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    TaskGrid[ValueCol, list[i].RowNo].Value = list[i].Value;
                }
            }
            if (ResultCol != -1)
            {
                //判定を表示
                int selRow = -1;
                int selLastNo = -1;
                for (int i = 0; i < list.Count; i++)
                {
                    TaskGrid[ResultCol, list[i].RowNo].Value = list[i].Value;
                    //色をセット
                    //OK NGの色をつけていく
                    switch (list[i].Value)
                    {
                        case "OK":
                            TaskGrid[ResultCol, list[i].RowNo].Style.ForeColor = Color.Blue;
                            break;
                        case "NG":
                            TaskGrid[ResultCol, list[i].RowNo].Style.ForeColor = Color.Red;
                            break;
                        case "":
                            TaskGrid[ResultCol, list[i].RowNo].Style.ForeColor = Color.Black;
                            break;
                    }
                    try
                    {
                        if (selRow == -1 && list[i].Result != source[i].Result)
                        {
                            if (list[i].Result != "OK")
                            {
                                selRow = list[i].RowNo;
                            }
                            selLastNo = i;
                        }
                    }
                    catch { }
                }
                if (selRow == -1 && selLastNo != -1)
                {
                    try
                    {
                        for (int i = selLastNo + 1; i < list.Count; i++)
                        {
                            if (list[i].Result != "OK")
                            {
                                selRow = list[i].RowNo;
                            }
                        }
                    }
                    catch { }
                }
                if (selRow != -1)
                {
                    TaskGrid.ClearSelection();
                    TaskGrid[0, selRow].Selected = true;
                    TaskGrid_SelectionChanged(null, null);
                }
                else if (selLastNo != -1)
                {
                    TaskGrid.ClearSelection();
                    TaskGrid[0, selLastNo].Selected = true;
                    TaskGrid_SelectionChanged(null, null);
                }
            }
            else
            {
                //回数を表示
                int selRow = -1;
                int selLastNo = -1;
                for (int i = 0; i < list.Count; i++)
                {
                    TaskGrid[EndCountCol, list[i].RowNo].Value = list[i].EndCount;
                    try
                    {
                        if (selRow == -1 && list[i].EndCount != source[i].EndCount)
                        {
                            int count = 0;
                            int endCnt = 0;
                            int.TryParse(list[i].Count, out count);
                            int.TryParse(list[i].EndCount, out endCnt);
                            if (endCnt < count)
                            {
                                selRow = list[i].RowNo;
                            }
                            selLastNo = i;
                        }
                    }
                    catch { }
                }
                if (selRow == -1 && selLastNo != -1)
                {
                    try
                    {
                        for (int i = selLastNo + 1; i < list.Count; i++)
                        {
                            int count = 0;
                            int endCnt = 0;
                            int.TryParse(list[i].Count, out count);
                            int.TryParse(list[i].EndCount, out endCnt);
                            if (endCnt < count)
                            {
                                selRow = list[i].RowNo;
                            }
                        }
                    }
                    catch { }
                }
                if (selRow != -1)
                {
                    TaskGrid.ClearSelection();
                    TaskGrid[0, selRow].Selected = true;
                    TaskGrid_SelectionChanged(null, null);
                }
                else if (selLastNo != -1)
                {
                    TaskGrid.ClearSelection();
                    TaskGrid[0, selLastNo].Selected = true;
                    TaskGrid_SelectionChanged(null, null);
                }
            }
            //待機状態にする　これにはNG＝リセットは存在しない
            FormStatusChange(FormStatus.Wait);
        }

        /// <summary>
        /// GUIへのプログレスバー変更通知
        /// </summary>
        /// <param name="max">最大値</param>
        /// <param name="val">現在値　※0の時プログレスバーが非表示になる</param>
        void ChangeProgressBar(uint max, uint val)
        {
            if (val == 0)
            {
                this.Invoke((MethodInvoker)delegate	//スレッドの切替
                {
                    progressBar1.Visible = false;
                });
                return;
            }
            if (max < val) return;
            this.Invoke((MethodInvoker)delegate	//スレッドの切替
            {
                try
                {
                    if (progressBar1.Value >= max)
                    {
                        progressBar1.Value = 1;
                    }
                    progressBar1.Minimum = 1;
                    progressBar1.Maximum = (int)max;
                    this.progressBar1.Value = (int)val;
                    //double v2 = (double)val / (double)max * 100.0;
                    //label3.Text = v2.ToString("F2") + " / 100 ％";
                    progressBar1.Visible = true;
                }
                catch { }
            });

        }
        //*******************************************
        //初期設定ボタン押下
        private void InitSettingButton_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == true) return;
            bool okFlg = false;
            String password = SgNet.COM.Form_s.InputForm("", "Please input password", "Password", true, out okFlg);

            if (password == "password")
            {
                //ダイアログを表示して、設定を行う
                InitSetting dlgP = new InitSetting();
                dlgP.ShowDialog();
                NowStatus = FormStatus.Comp;
                this.Close();
            }
        }
        //パターン設定ボタン押下
        private void PatternSettingButton_Click(object sender, EventArgs e)
        {
            if (HensyuFlg == false)
            {
                HensyuFlg = true;
                PatternSettingButton.Text = "End edit";
                //TaskGrid.AllowUserToAddRows = true;
                //TaskGrid.AllowUserToDeleteRows = true;
                BeforeColor = this.BackColor;
                this.BackColor = Color.PaleGreen;
                button1.Visible = true;
                button2.Visible = true;
                button5.Visible = true;
                button6.Visible = true;
                button7.Visible = true;
                button8.Visible = true;
                button9.Visible = true;
                InitialSettingGroupBox.Visible = false;
                DebugGroupBox.Visible = false;
                PatternSettingButton.BackColor = Color.Violet;
                TaskGrid.MultiSelect = true;
            }
            else
            {
                HensyuFlg = false;
                PatternSettingButton.Text = "Start edit";
                //TaskGrid.AllowUserToAddRows = false;
                //TaskGrid.AllowUserToDeleteRows = false;
                this.BackColor = BeforeColor;
                button1.Visible = false;
                button2.Visible = false;
                button5.Visible = false;
                button6.Visible = false;
                button7.Visible = false;
                button8.Visible = false;
                button9.Visible = false;
                InitialSettingGroupBox.Visible = true;
                DebugGroupBox.Visible = true;
                PatternSettingButton.BackColor = SgNet.COM.Form_s.Color(KnownColor.ButtonFace);
                TaskGrid.MultiSelect = false;
            }
        }
        //行挿入
        private void button1_Click(object sender, EventArgs e)
        {
            if (TaskGrid.CurrentCell == null)
            {
                TaskGrid.RowCount++;
                return;
            }
            try
            {
                List<int> row = new List<int>();
                foreach (DataGridViewCell c in TaskGrid.SelectedCells)
                {
                    bool flg = false;
                    for (int i = 0; i < row.Count; i++)
                    {
                        if (row[i] == c.RowIndex)
                        {
                            flg = true;
                            break;
                        }
                    }
                    if (!flg) row.Add(c.RowIndex);
                }
                int[] row2 = new int[row.Count];
                row.CopyTo(row2, 0);
                Array.Sort(row2);
                for (int i = row2.Length - 1; i >= 0; i--)
                {
                    try
                    {
                        TaskGrid.Rows.Insert(row2[i] + 1);
                    }
                    catch { }
                }
            }
            catch { }
        }
        //行削除
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                List<int> row = new List<int>();
                foreach (DataGridViewCell c in TaskGrid.SelectedCells)
                {
                    bool flg = false;
                    for (int i = 0; i < row.Count; i++)
                    {
                        if (row[i] == c.RowIndex)
                        {
                            flg = true;
                            break;
                        }
                    }
                    if (!flg) row.Add(c.RowIndex);
                }
                int[] row2 = new int[row.Count];
                row.CopyTo(row2, 0);
                Array.Sort(row2);
                for (int i = row2.Length - 1; i >= 0; i--)
                {
                    try
                    {
                        TaskGrid.Rows.Remove(TaskGrid.Rows[row2[i]]);
                    }
                    catch { }
                }
            }
            catch { }
        }

        //パターンの保存
        private void button5_Click(object sender, EventArgs e)
        {
            List<PatternRow> ptn = CmdCommon.GetPattern(true, TaskGrid, GridPatternNo, CountCol, EndCountCol, ResultCol, ValueCol);
            bool ret = CmdCommon.WritePatternXML(Application.StartupPath + "\\Pattern.xml", ptn);

            if (ret) SgNet.COM.MessageBox_s.ShowInfomation(Application.StartupPath + FileNameOfMsgString(), "Msg", "1", "Complete");
            else SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + FileNameOfMsgString(), "Msg", "3", "There are some errors!");
        }

        //Gridのダブルクリック⇒コマンド登録・編集
        private void TaskGrid_DoubleClick(object sender, EventArgs e)
        {
            if (HensyuFlg == false) return;
            button6_Click(null, null);
        }

        //コマンド登録・編集
        private void button6_Click(object sender, EventArgs e)
        {
            int row = TaskGrid.CurrentCell.RowIndex;
            int col = TaskGrid.CurrentCell.ColumnIndex;
            //回数なら数値編集にする
            if (CountCol != -1 && CountCol == col)
            {
                bool okFlg = false;
                String ss = "";
                try
                {
                    ss = TaskGrid[col, row].Value.ToString();
                }
                catch { }
                ss = SgNet.COM.Form_s.InputForm(ss, "Setting run counts", "Setting", false, out okFlg);

                if (okFlg)
                {
                    TaskGrid[col, row].Value = ss;
                }
            }
            else
            {
                //GridPatternNoにより切り分けが必要
                bool flg = false;
                for (int i = 0; i < CommandCol.Count; i++)
                {
                    if (col == CommandCol[i])
                    {
                        flg = true;
                        break;
                    }
                }
                if (flg)
                {
                    Cmd cmd = (Cmd)TaskGrid[col, row].Tag;
                    if (cmd == null)
                    {
                        //コマンド選択画面を表示し、オブジェクトを生成してから次へ
                        List<String> lst = new List<String>();
                        for (int i = 0; i < BaseCmdList.Count; i++)
                        {
                            lst.Add(BaseCmdList[i].SequenceName);
                        }
                        int selNo = SgNet.COM.Form_s.ComboBoxForm(lst, -1, "Please select command.", "wait select");
                        if (selNo == -1) return;
                        cmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\" + BaseCmdList[selNo].FileName + ".xml");
                    }
                    Cmd baseCmd = GetBaseCmd(cmd.FileName);
                    CmdSettingForm dlgP = new CmdSettingForm(cmd, baseCmd, GridPatternNo, GloryDLL);
                    if (dlgP.ShowDialog(this) != DialogResult.OK)
                    {
                        return;
                    }
                    //登録されたコマンドを割り当てる
                    TaskGrid[col, row].Tag = dlgP.SettingCmd;
                    String sqName = (cmd.SequenceName != "" ? cmd.SequenceName : baseCmd.SequenceName);
                    TaskGrid[col, row].Value = sqName;

                    //コメント行があるならばコメントを切り替える
                    if (CommentCol != -1)
                    {
                        String comment = (cmd.Comment != "" ? cmd.Comment : baseCmd.Comment);
                        TaskGrid[CommentCol, row].Value = comment;
                    }

                    //金種行があるならば金種情報を変更する
                    if (GridPatternNo == 4 || GridPatternNo == 5)
                    {
                        for (int i = 0; i < cmd.Maisu.Count; i++)
                        {
                            try
                            {
                                TaskGrid[1 + i, row].Value = cmd.Maisu[i];
                            }
                            catch { }
                        }
                    }
                }
            }
        }

        //コマンド削除
        private void button7_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewCell c in TaskGrid.SelectedCells)
            {
                int row = c.RowIndex;
                int col = c.ColumnIndex;
                TaskGrid[col, row].Value = "";
                TaskGrid[col, row].Tag = null;
            }
        }

        //コピー
        private void button8_Click(object sender, EventArgs e)
        {
            //コマンドの部分だけをコピーしてメモリに格納する
            CopyList.Clear();
            foreach (DataGridViewCell c in TaskGrid.SelectedCells)
            {
                Cell cell = new Cell(c.RowIndex, c.ColumnIndex, TaskGrid[c.ColumnIndex, c.RowIndex].Value, TaskGrid[c.ColumnIndex, c.RowIndex].Tag);
                CopyList.Add(cell);
            }
        }

        //貼り付け
        private void button9_Click(object sender, EventArgs e)
        {
            if (CopyList.Count == 0) return;

            int row = 9999999;
            int col = 9999999;
            foreach (DataGridViewCell c in TaskGrid.SelectedCells)
            {
                if (c.RowIndex < row) row = c.RowIndex;
                if (c.ColumnIndex < col) col = c.ColumnIndex;
            }
            if (row == 9999999) return;

            TaskGrid.ClearSelection();

            int minRow = 9999999;
            int minCol = 9999999;

            //一番左上を確認する
            for (int i = 0; i < CopyList.Count; i++)
            {
                if (CopyList[i].row < minRow) minRow = CopyList[i].row;
                if (CopyList[i].col < minCol) minCol = CopyList[i].col;
            }
            //貼り付けていく
            int pasteRow = 0;
            int pasteCol = 0;
            for (int i = 0; i < CopyList.Count; i++)
            {
                pasteRow = row + (CopyList[i].row - minRow);
                pasteCol = col + (CopyList[i].col - minCol);

                bool flg1 = false;
                bool flg2 = false;
                bool flg3 = false;
                bool flg4 = false;
                for (int i2 = 0; i2 < CommandCol.Count; i2++)
                {
                    if (CommandCol[i2] == pasteCol)
                    {
                        flg1 = true;
                        break;
                    }
                    else if (CountCol == pasteCol)
                    {
                        flg2 = true;
                        break;
                    }
                }
                for (int i2 = 0; i2 < CommandCol.Count; i2++)
                {
                    if (CommandCol[i2] == CopyList[i].col)
                    {
                        flg3 = true;
                        break;
                    }
                    else if (CountCol == CopyList[i].col)
                    {
                        flg4 = true;
                        break;
                    }
                }

                if (flg1 && flg3)
                {
                    //行が足りなければ追加する
                    if (TaskGrid.RowCount <= pasteRow)
                    {
                        TaskGrid.RowCount = pasteRow + 1;
                    }
                    //コマンド列ならば貼り付け
                    //表示文字＋Tagデータのコピー
                    TaskGrid[pasteCol, pasteRow].Value = CopyList[i].text;
                    TaskGrid[pasteCol, pasteRow].Tag = CopyList[i].tag;
                    //コメント行があるならコメントを貼り付け
                    if (CommentCol != -1)
                    {
                        if (CopyList[i].tag == null)
                        {
                            TaskGrid[CommentCol, pasteRow].Value = "";
                        }
                        else
                        {
                            TaskGrid[CommentCol, pasteRow].Value = GetCmdString(CopyList[i].tag, 1);
                        }
                    }
                    //金種行があるならば金種情報を変更する
                    if (GridPatternNo == 4 || GridPatternNo == 5)
                    {
                        if (CopyList[i].tag != null)
                        {
                            for (int i3 = 0; i3 < KinsyuString.Count; i3++)
                            {
                                try
                                {
                                    TaskGrid[1 + i3, pasteRow].Value = CopyList[i].tag.Maisu[i3];
                                }
                                catch
                                {
                                    TaskGrid[1 + i3, pasteRow].Value = "";
                                }
                            }
                        }
                    }
                }
                else if (flg2 && flg4)
                {
                    //カウント列なら貼り付け
                    TaskGrid[pasteCol, pasteRow].Value = CopyList[i].text;
                }
                if ((flg1 && flg3) || (flg2 && flg4))
                {
                    //貼り付けられたならば選択
                    TaskGrid[pasteCol, pasteRow].Selected = true;
                }
            }
            TaskGrid[col, row].Selected = true;
        }

        //終了回数＆結果クリアボタン押下
        private void EndCountClearButton_Click(object sender, EventArgs e)
        {
            if (EndCountCol != -1)
            {
                for (int i = 0; i < TaskGrid.RowCount; i++)
                {
                    TaskGrid[EndCountCol, i].Value = "";
                }
                FormStatusChange(FormStatus.Wait);
                return;
            }
            else
            {
                for (int i = 0; i < TaskGrid.RowCount; i++)
                {
                    TaskGrid[ResultCol, i].Value = "";
                    TaskGrid[ResultCol, i].Style.ForeColor = Color.Black;
                }
                FormStatusChange(FormStatus.Wait);
                return;
            }
        }

        private void TaskGrid_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (GridPatternNo == 6)
            {
                if (e.CellStyle.WrapMode == DataGridViewTriState.True && e.FormattedValue != null && e.FormattedValue is string)
                {
                    string s = (string)e.FormattedValue;
                    if (s.Length > 0)
                    {
                        DataGridView dgv = (DataGridView)sender;

                        DataGridViewPaintParts parts = e.PaintParts & ~DataGridViewPaintParts.ContentForeground;
                        e.Paint(e.CellBounds, parts);

                        Brush brush;
                        if ((e.State & DataGridViewElementStates.Selected) == DataGridViewElementStates.Selected)
                        {
                            brush = new SolidBrush(e.CellStyle.SelectionForeColor);
                        }
                        else
                        {
                            brush = new SolidBrush(e.CellStyle.ForeColor);
                        }

                        StringFormat sf = new StringFormat();
                        sf.Trimming = StringTrimming.Character; //これ
                        e.Graphics.DrawString(s, e.CellStyle.Font, brush, e.CellBounds, sf);
                        brush.Dispose();
                        e.Handled = true;
                    }
                }
            }
        }

        [DllImport("KERNEL32.DLL")]
        public static extern uint
        GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault, StringBuilder lpReturnedString, uint nSize, string lpFileName);

        [DllImport("kernel32.dll")]
        private static extern uint WritePrivateProfileString(string lpApplicationName, string lpKeyName, string lpstring, string lpFileName);

        private void ResetComFile()
        {
            var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");
            WritePrivateProfileString("Pattern", "Pat", "", fPath);
            WritePrivateProfileString("Pattern", "1Sen", "", fPath);
            WritePrivateProfileString("Pattern", "2Sen", "", fPath);
            WritePrivateProfileString("Pattern", "5Sen", "", fPath);
            WritePrivateProfileString("Pattern", "1Man", "", fPath);
            WritePrivateProfileString("Pattern", "ExecuteFlag", "False", fPath);
            WritePrivateProfileString("Pattern", "StopFlag", "False", fPath);
        }

        private void Counter_Tick(object sender, EventArgs e)
        {
            this.SendError();
        }

        private void SendError()
        {
            var result = this.OpenSerialPort();
            if (result == false)
            {
                MessageBox.Show("ロボットと接続できませんでした。", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var sendData = new byte[3];
            sendData[0] = 2;  //テキスト開始(STX)
            sendData[2] = 3;　//テキスト終了(ETX)　

            sendData[1] = 99;  //エラー発生時にRobotに通知する。

            this._serialPort.Write(sendData, 0, 3);
            Thread.Sleep(1000);

            sendData[1] = 10;
            this._serialPort.Write(sendData, 0, 3);  //データ送信

            this.CloseSerialPort();

            this.Invoke(new Action(() => this.Counter.Stop()));
        }

        private void ErrorTimer_Tick(object sender, EventArgs e)
        {
            try
            {
                var fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");
                var status = GetIniValue(fPath, "Settings", "Status");
                if (status == "NG")
                {
                    this.SendError();
                    WritePrivateProfileString("Settings", "Status", "OK", fPath);

                    //if (this.Counter.Enabled == true)
                    //{
                    //    this.Invoke(new Action(() => this.Counter.Stop()));
                    //}
                }

                fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Maisu.ini");
                var sendData = new byte[3];
                sendData[0] = 2;  //テキスト開始(STX)
                sendData[2] = 3;  //テキスト終了(ETX)

                var pat1 = GetIniValue(fPath, "Kensa", "Pat");
                var oneSen1 = GetIniValue(fPath, "Kensa", "1Sen");
                var twoSen1 = GetIniValue(fPath, "Kensa", "2Sen");
                var fiveSen1 = GetIniValue(fPath, "Kensa", "5Sen");
                var oneMan1 = GetIniValue(fPath, "Kensa", "1Man");

                var pat2 = GetIniValue(fPath, "Kensa2", "Pat");
                var oneSen2 = GetIniValue(fPath, "Kensa2", "1Sen");
                var twoSen2 = GetIniValue(fPath, "Kensa2", "2Sen");
                var fiveSen2 = GetIniValue(fPath, "Kensa2", "5Sen");
                var oneMan2 = GetIniValue(fPath, "Kensa2", "1Man");

                var newpChk = GetIniValue(fPath, "Status", "NempChkFlg");
                if (newpChk == "True")
                {
                    if (pat1 == "NempChkSyukkin")
                    {
                        sendData[1] = 50;
                    }

                    if (pat2 == "NempChkSyukkin")
                    {
                        sendData[1] = 40;
                    }


                    var result = this.OpenSerialPort();
                    if (result == false)
                    {
                        return;
                    }

                    this._serialPort.Write(sendData, 0, 3);
                    Thread.Sleep(1000);

                    sendData[1] = 10;
                    this._serialPort.Write(sendData, 0, 3);  //データ送信

                    this.CloseSerialPort();

                    Thread.Sleep(5000);

                    WritePrivateProfileString("Status", "NempChkFlg", "False", fPath);

                    return;
                }

                var newpChk495 = GetIniValue(fPath, "Status", "NempChkFlg495");
                if (newpChk == "True")
                {
                    if (pat1 == "NempChkSyukkin")
                    {
                        sendData[1] = 70;
                    }

                    if (pat2 == "NempChkSyukkin")
                    {
                        sendData[1] = 60;
                    }

                    var result = this.OpenSerialPort();
                    if (result == false)
                    {
                        return;
                    }

                    this._serialPort.Write(sendData, 0, 3);
                    Thread.Sleep(1000);

                    sendData[1] = 10;
                    this._serialPort.Write(sendData, 0, 3);  //データ送信

                    this.CloseSerialPort();

                    Thread.Sleep(5000);

                    WritePrivateProfileString("Status", "NempChkFlg495", "False", fPath);

                    return;
                }

                fPath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Com.ini");
                var pat0 = GetIniValue(fPath, "Pattern", "Pat");
                var oneSen0 = GetIniValue(fPath, "Pattern", "1Sen");
                var twoSen0 = GetIniValue(fPath, "Pattern", "2Sen");
                var fiveSen0 = GetIniValue(fPath, "Pattern", "5Sen");
                var oneMan0 = GetIniValue(fPath, "Pattern", "1Man");

                if (pat2 == "KaisyuPAYOUT")
                {
                    var kaisyuFilePath = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "KaisyuPAYOUT.ini");
                    var kOneSen = GetIniValue(kaisyuFilePath, "Kensa", "1Sen");
                    var kTwoSen = GetIniValue(kaisyuFilePath, "Kensa", "2Sen");
                    var kFiveSen = GetIniValue(kaisyuFilePath, "Kensa", "5Sen");
                    var kOneMan = GetIniValue(kaisyuFilePath, "Kensa", "1Man");

                    if (oneSen2 == "0" && twoSen2 == "0" && fiveSen2 == "0" && oneMan2 == "0")
                    {
                        return;
                    }
                    if (oneSen1 == kOneSen && twoSen1 == kTwoSen && fiveSen1 == kFiveSen && oneMan1 == kOneMan)
                    {
                        WritePrivateProfileString("Kensa", "1Sen", "0", kaisyuFilePath);
                        WritePrivateProfileString("Kensa", "2Sen", "0", kaisyuFilePath);
                        WritePrivateProfileString("Kensa", "5Sen", "0", kaisyuFilePath);
                        WritePrivateProfileString("Kensa", "1Man", "0", kaisyuFilePath);
                        return;
                    }

                    if (oneSen1 == oneSen2 && twoSen1 == twoSen2 && fiveSen1 == fiveSen2 && oneMan1 == oneMan2)
                    {
                        var path = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Maisu.ini");
                        WritePrivateProfileString("Kensa", "1Sen", "0", path);
                        WritePrivateProfileString("Kensa", "2Sen", "0", path);
                        WritePrivateProfileString("Kensa", "5Sen", "0", path);
                        WritePrivateProfileString("Kensa", "1Man", "0", path);

                        WritePrivateProfileString("Kensa2", "1Sen", "0", path);
                        WritePrivateProfileString("Kensa2", "2Sen", "0", path);
                        WritePrivateProfileString("Kensa2", "5Sen", "0", path);
                        WritePrivateProfileString("Kensa2", "1Man", "0", path);

                        var result = this.OpenSerialPort();
                        if (result == false)
                        {
                            return;
                        }

                        //sendData[1] = 60;
                        sendData[1] = 20;

                        this._serialPort.Write(sendData, 0, 3);
                        Thread.Sleep(1000);

                        sendData[1] = 10;
                        this._serialPort.Write(sendData, 0, 3);  //データ送信

                        this.CloseSerialPort();

                        Thread.Sleep(5000);

                        this.ResetTimer();

                        return;
                    }
                    else
                    {
                    }
                }

                if (pat1 == "KaisyuPAYOUT")
                {
                    var a = KinsyuInfoGrid[1, 0].Value.ToString();
                    var b = KinsyuInfoGrid[2, 0].Value.ToString();
                    var c = KinsyuInfoGrid[3, 0].Value.ToString();
                    var d = KinsyuInfoGrid[4, 0].Value.ToString();

                    if (oneSen2 == "0" && twoSen2 == "0" && fiveSen2 == "0" && oneMan2 == "0")
                    {
                        return;
                    }

                    if (oneSen2 == d && twoSen2 == c && fiveSen2 == b && oneMan2 == a)
                    {
                        return;
                    }

                    if (oneSen1 == oneSen2 && twoSen1 == twoSen2 && fiveSen1 == fiveSen2 && oneMan1 == oneMan2)
                    {
                        //if (this._finishFlg == true)
                        //{
                        //    return;
                        //}

                        //this._finishFlg = true;
                        var path = System.IO.Path.Combine(Properties.Settings.Default.SettingPath, "Maisu.ini");
                        WritePrivateProfileString("Kensa", "1Sen", "0", path);
                        WritePrivateProfileString("Kensa", "2Sen", "0", path);
                        WritePrivateProfileString("Kensa", "5Sen", "0", path);
                        WritePrivateProfileString("Kensa", "1Man", "0", path);

                        WritePrivateProfileString("Kensa2", "1Sen", "0", path);
                        WritePrivateProfileString("Kensa2", "2Sen", "0", path);
                        WritePrivateProfileString("Kensa2", "5Sen", "0", path);
                        WritePrivateProfileString("Kensa2", "1Man", "0", path);

                        var result = this.OpenSerialPort();
                        if (result == false)
                        {
                            return;
                        }

                        //sendData[1] = 70;
                        sendData[1] = 30;

                        this._serialPort.Write(sendData, 0, 3);
                        Thread.Sleep(1000);

                        sendData[1] = 10;
                        this._serialPort.Write(sendData, 0, 3);  //データ送信

                        this.CloseSerialPort();

                        Thread.Sleep(5000);

                        this.ResetTimer();

                        return;
                    }
                    //else
                    //{
                    //    this._finishFlg = false;
                    //}
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            
        }
    }

    public class Cell
    {
        public int row = 0;
        public int col = 0;
        public String text = "";
        public Cmd tag = null;
        public Cell(int r, int c, object te, object ta)
        {
            row = r;
            col = c;
            text = (String)te;
            tag = (Cmd)ta;
        }
    }
}
