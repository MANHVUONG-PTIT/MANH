﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Logclear
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Logclear(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                int len = 1;
                byte[] dt = new byte[len];      //データ部仮配列
                dt[0] = 0x30;                   //D0・クリア内容（工場出荷）

                //メモリクリアコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASmemclear, len, dt);          //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }
                else {
                    //正常の場合、装置が再起動するためＲＡＳ終了コマンドを受けられない→ここで終了する（１．５秒待ち）
                    SgNet.COM.Time_s.Sleep(1500);
                    break;
                }


                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
