﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class LEDcheck
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public LEDcheck(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                System.Windows.Forms.DialogResult ChkRslt = System.Windows.Forms.DialogResult.Yes;

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                switch (OwnerP.Lang)
                {
                    case "CN":
                        SgNet.COM.MessageBox_s.ShowInfomation("确认LED灯亮");
                        break;
                    case "JP":
                        SgNet.COM.MessageBox_s.ShowInfomation("ＬＥＤ点灯確認を行います");
                        break;
                }

                int len = 4;
                byte[] dt = new byte[len];      //データ部仮配列

                dt[0] = 0x31;                   //D0・投入口ＬＥＤ点灯制御（０：消灯　１：青）
                dt[1] = 0x30;                   //D1・投入口ＬＥＤ点滅制御（０：点滅なし）
                dt[2] = 0x30;                   //D2・払出口ＬＥＤ点灯制御（０：消灯　１：青　２：赤　３：紫）
                dt[3] = 0x30;                   //D3・払出口ＬＥＤ点滅制御（０：点滅なし）

                //ＬＥＤ制御コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASLEDctrl, len, dt);           //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                if (err == false)
                {
                    SgNet.COM.Time_s.Sleep(3000);                   //3秒スリープ

                    //ＲＡＳ継続動作終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);                       //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);                 //送信
                    if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                }

                if (err == false)
                {
                    dt[0] = 0x30;                   //D0・投入口ＬＥＤ点灯制御（０：消灯　１：青）
                    for (int i = 1; i <= 3; i++)
                    {
                        dt[2] = (byte)(0x30 | i);   //D2・払出口ＬＥＤ点灯制御（０：消灯　１：青　２：赤　３：紫）

                        //ＬＥＤ制御コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASLEDctrl, len, dt);   //コマンド,データ長,データ部配列
                        recv = OwnerP.Send(data, 1500);         //送信
                        if (OwnerP.RespCheck(recv, false))      //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //forを抜ける
                        }

                        SgNet.COM.Time_s.Sleep(3000);           //3秒スリープ

                        //ＲＡＳ継続動作終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);               //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);         //送信
                        if (OwnerP.RespCheck(recv, false))      //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //forを抜ける
                        }
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                switch (OwnerP.Lang)
                {
                    case "CN":
                        ChkRslt = SgNet.COM.MessageBox_s.ShowYesNo("LED灯亮了吗?");
                        break;
                    case "JP":
                        ChkRslt = SgNet.COM.MessageBox_s.ShowYesNo("ＬＥＤは点灯していましたか？");
                        break;
                }
                if (ChkRslt == System.Windows.Forms.DialogResult.Yes) { err = false; }
                else if (ChkRslt == System.Windows.Forms.DialogResult.No) { err = true; }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
