﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Modoshiire
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Modoshiire(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //計数枚数のデータ部（10000円,5000円,2000円,1000円）
        //2000円に対するオフセット
        int[] MaisuHeader = { 3, 6, 0, 9 };
        int[] Fullpcs = { 200, 200, 0, 600 };

        //計数データリードの装置状態enum
        private enum HopperInfo { NONE, EXIST }
        private enum DetailInfo { OTHER, WAIT, MOVE, YOBI3, RJREMOVE, FULL, YOBI6, YOBI7, HPREMOVE }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                List<int> DispPCS = new List<int>();            //指示枚数、計数枚数を表示するための枚数データ格納リスト
                DispPCS.Clear();
                int pcs;

                int[] CountPcs_para = new int[CmdP.Maisu.Count];
                int[] CountPcs_resp = new int[CmdP.Maisu.Count];

                for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                {
                    //コマンドのデータCmdP.Maisu[a]から指示枚数を取得
                    if (!int.TryParse(CmdP.Maisu[a], out pcs)) { pcs = 0; }
                    DispPCS.Add(pcs);
                    CountPcs_para[a] = pcs;
                }
                OwnerP.ChangeMaisu(DispPCS, 0);                 //指示枚数を表示
                for (int a = 0; a < CmdP.Maisu.Count; a++)      //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                {
                    DispPCS[a] = 0;                             //０クリアして計数枚数表示に使用
                }
                OwnerP.ChangeMaisu(DispPCS, 1);                 //計数枚数を表示

                //現金戻し開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.Modoshiire);             //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, true))               //レスポンスチェック（ENQ待ちあり）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時に計数停止コマンドと計数終了コマンドを送信するようにする

                byte[] ReceiveData;
                bool Firstflg = false;
                bool Endflg = false;
                do
                {
                    if (OwnerP.ForceStopFlg)
                    {
                        err = true;
                        break;
                    }
                    //計数データリードコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.CountdataRead);             //コマンド（データ長０のもの）
                    //（ここだけ他の通信と並行になるのでタイムアウト（１０倍）を延ばす）
                    SgNet.COM.Time_s.Sleep(500);                                //0.5秒スリープ
                    recv = OwnerP.Send(data, 15000);                            //送信
                    ReceiveData = OwnerP.RecvCheckAndGetData(recv);             //recvからデータだけ取り出す

                    if (ReceiveData == null)
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;  //whileを抜ける
                    }

                    DispPCS.Clear();
                    for (int a = 0; a < CmdP.Maisu.Count; a++)  //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        //計数枚数のデータ部
                        //D 7~D 9 　10000円合計枚数
                        //D10~D12　  5000円合計枚数
                        //D13~D15　  2000円合計枚数
                        //D16~D18    1000円合計枚数
                        //計数枚数を取得
                        pcs = (ReceiveData[a * 3 + 7] & 0x0F) * 100
                            + (ReceiveData[a * 3 + 8] & 0x0F) * 10
                            + (ReceiveData[a * 3 + 9] & 0x0F);
                        DispPCS.Add(pcs);
                        CountPcs_resp[a] = pcs;
                    }
                    OwnerP.ChangeMaisu(DispPCS, 1);             //計数枚数を表示

                    //Firstflg：実際に計数を開始したかどうか（D3でみる）　指示枚数０の場合は１回計数で終了
                    if ((Firstflg == false) && (ReceiveData[3] == (byte)HopperInfo.EXIST))
                    {
                        Firstflg = true;
                        Endflg = false;
                        continue;
                    }
                    //Endflg：計数中かどうか（D4でみる）　計数動作中、抜き取り待ちの場合はfalseとする
                    Endflg = true;
                    if (ReceiveData[4] == (byte)DetailInfo.MOVE
                        || ReceiveData[4] == (byte)DetailInfo.RJREMOVE
                        || ReceiveData[4] == (byte)DetailInfo.HPREMOVE)
                    {
                        Endflg = false;
                    }
                    for (int a = 0; a < CmdP.Maisu.Count; a++)                  //金種番号　処理は10000円,5000円,2000円,1000円の順に行う
                    {
                        if (CountPcs_resp[a] < CountPcs_para[a])                //計数枚数に達していなければfalseとする
                        {
                            Endflg = false;
                        }
                    }

                } while ((Firstflg == false) || (Endflg == false));

                //ここまで（エラー時にコマンド送信）

                if (recv != null)               //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //計数停止コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.CountStop); //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))           //レスポンスチェック（ENQ待ちなし）ENQ判定は下で行う
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                    }

                    //ここだけ個別にENQを送信し、計数停止を待つ
                    data = OwnerP.MakeSingleChar((byte)SQMain.CtrlChar.ENQ);
                    while (true)
                    {
                        SgNet.COM.Time_s.Sleep(50);       //0.05秒スリープ（反応を早くしてみる）
                        recv = OwnerP.Send(data, 1500);   //送信

                        if (recv == null)                 //無応答
                        {
                            //エラー終了
                            err = true;
                            OwnerP.GetErrorByConditionRead();
                            break;
                        }
                        else
                        {
                            if (recv[0] == (byte)SQMain.CtrlChar.SOH)  //SOH・計数中
                            {
                                continue;
                            }
                            else if (recv[0] == (byte)SQMain.CtrlChar.EM)   //EM・計数停止中
                            {
                                break;
                            }
                            else
                            {
                                err = true;
                                OwnerP.GetErrorByConditionRead();
                                break;
                            }
                        }
                    }

                    //計数終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.CountEnd);  //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, true))           //レスポンスチェック（ENQ待ちあり）
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                    }
                }
                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
