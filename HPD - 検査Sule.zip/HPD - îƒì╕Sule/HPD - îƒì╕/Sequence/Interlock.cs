﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class Interlock
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public Interlock(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                byte addr = 23;
                byte bit = 2;
                int now = 0;

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);   //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                //ポートリードコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASportread);       //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                if (err == false)
                {
                    byte[] ReceiveData;
                    bool Firstflg = false;
                    int changetimes = 0;
                    while(true)
                    {
                        if (OwnerP.ForceStopFlg)
                        {
                            err = true;
                            break;
                        }
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);      //コマンド（データ長０のもの）
                        SgNet.COM.Time_s.Sleep(500);                //0.5秒スリープ
                        recv = OwnerP.Send(data, 1500);             //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);                 //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;  //whileを抜ける
                        }
                        if (Firstflg == false)
                        {
                            now = ReceiveData[addr] & bit;
                            Firstflg = true;
                        }
                        if (now != (ReceiveData[addr] & bit))   //対象ポートデータが変化した
                        {
                            now = ReceiveData[addr] & bit;      //状態を更新
                            changetimes++;
                            if (changetimes >= 2) { break; }    //規定回数変わったら終了（１往復２回に設定））
                        }
                        if ((ReceiveData[addr] & bit) != 0)
                        {
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 2, "(SSWC) 关", System.Drawing.Color.Green);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 2, "(SSWC) 閉", System.Drawing.Color.Green);
                                    break;
                            }
                        }
                        else
                        {
                            switch (OwnerP.Lang)
                            {
                                case "CN":
                                    OwnerP.ChangeInfo(0, 2, "(SSWC) 开", System.Drawing.Color.YellowGreen);
                                    break;
                                case "JP":
                                    OwnerP.ChangeInfo(0, 2, "(SSWC) 開", System.Drawing.Color.YellowGreen);
                                    break;
                            }
                        }
                    }
                    OwnerP.ChangeInfo(0, 2, " ", System.Drawing.Color.White);

                    if (recv != null)           //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                    {
                        //ＲＡＳ継続動作終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);           //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);                 //送信
                        if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                    }
                }

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (recv != null)       //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);            //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);                 //送信
                    if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                break;
            }
            EndSyori(err);
            //**************************
        }
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
