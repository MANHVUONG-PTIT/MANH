﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Simulator
{
    //機種毎に変更必要********
    public class CassetteIC
    {
        Cmd CmdP = null;
        SQMain OwnerP = null;
        int ThreadNo = 0;
        //コンストラクタ
        public CassetteIC(Cmd cmd, SQMain frm, int threadNo)
        {
            CmdP = cmd;
            OwnerP = frm;
            ThreadNo = threadNo;
        }

        int datanum = 48 * 2;
        byte[] dataval_resp = new byte[48 * 2];
        byte[] dataval_back = new byte[48 * 2];
        byte[] ReceiveData;

        private enum ReadResult { NONE, READING, NORMAL_END, READERR, KEYERR, DATAERR }

        //スレッド ※シーケンス処理
        public void MainFunc()
        {
            bool err = false;
            while (true)
            {
                if (OwnerP.ForceStopFlg)
                {
                    break;
                }
                //機種毎に変更必要**********
                //処理を書く
                OwnerP.dispclear();

                //ＲＡＳ開始コマンド
                byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);               //コマンド（データ長０のもの）
                byte[] recv = OwnerP.Send(data, 1500);          //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                    break;
                }

                //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                //ＩＣリーダライタの接続を確認し、接続がなければエラーとする
                //ポートリードコマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASportread);   //コマンド（データ長０のもの）
                recv = OwnerP.Send(data, 1500);                 //送信
                if (OwnerP.RespCheck(recv, false))              //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }

                if (err == false)
                {
                    //ＲＡＳセンスコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);  //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    ReceiveData = OwnerP.RecvCheckAndGetData(recv);             //recvからデータだけ取り出す
                    if (ReceiveData == null)
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }

                    if (recv != null)           //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                    {
                        //ＲＡＳ継続動作終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstop);                   //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);             //送信
                        if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                    }
                }

                if (err == false)
                {
                    if ((ReceiveData[24] & 0x08) != 0)          //ＩＣリーダライタの接続がなければ処理しない
                    {
                        err = true;
                        //ＲＡＳ終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);         //送信
                        if (OwnerP.RespCheck(recv, false))      //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                        break;
                    }
                }
                //（ここまで）・ＩＣリーダライタの接続を確認し、接続がなければエラーとする

                //ここまで（エラー時にＲＡＳ終了コマンド送信）

                if (err == false)
                {
                    err = CassetteICInit();                     //ＩＣカード初期化コマンド
                }

                if (recv != null)               //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                {
                    //ＲＡＳ終了コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                    //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                        break;
                    }
                }

                err = CassetteICRead();                         //カセットＩＣ情報読取コマンド

                if (err == false)
                {
                    for (int i = 0; i < datanum; i++)
                    {
                        dataval_back[i] = dataval_resp[i];      //現在値をバックアップ
                    }

                    int len = 100;
                    byte[] dt = new byte[len];                  //データ部仮配列

                    dt[0] = 0x30;                               //D0・カセットNo.
                    dt[1] = 0x31;                               //D1・カセットNo.（１～３）
                    dt[2] = 0x30;                               //D2・セクタNo.
                    dt[3] = 0x35;                               //D3・セクタNo.（０～１５）

                    for (int i = 0; i < datanum; i++)
                    {
                        dt[4 + i] = 0x31;                       //設定データ　すべて１にする
                    }

                    //カセットＩＣ情報書換コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.ICInfoWrite, len, dt);      //コマンド,データ長,データ部配列
                    recv = OwnerP.Send(data, 1500);             //送信
                    err = OwnerP.RespCheck(recv, true);         //レスポンスチェック（ENQ待ちあり）

                    if (err == false)
                    {
                        err = CassetteICRead();                 //カセットＩＣ情報読取コマンド

                        if (err == false)
                        {
                            for (int n = 0; n < datanum; n++)
                            {
                                if (dataval_resp[n] != 0x01) 
                                {
                                    err = true;
                                    switch (OwnerP.Lang)
                                    {
                                        case "CN":
                                            OwnerP.ChangeInfo(0, 0, "数据不一样 : No." + n, System.Drawing.Color.Red);
                                            break;
                                        case "JP":
                                            OwnerP.ChangeInfo(0, 0, "データ不一致 : No." + n, System.Drawing.Color.Red);
                                            break;
                                    }
                                    break;  //forを抜ける
                                }
                            }
                            if (err == true) { break; }

                            for (int i = 0; i < datanum; i++)
                            {
                                dt[4 + i] = (byte)(0x30 | dataval_back[i]);     //設定データ　バックアップした値に戻す
                            }

                            //dt[0]からdt[3]までは同じ

                            //カセットＩＣ情報書換コマンド
                            data = OwnerP.MakeSendData((byte)SQMain.CmdCode.ICInfoWrite, len, dt);  //コマンド,データ長,データ部配列
                            recv = OwnerP.Send(data, 1500);                     //送信
                            err = OwnerP.RespCheck(recv, true);                 //レスポンスチェック（ENQ待ちあり）

                            if (err == false)
                            {
                                err = CassetteICRead();         //カセットＩＣ情報読取コマンド

                                if (err == false)
                                {
                                    for (int n = 0; n < datanum; n++)
                                    {
                                        if (dataval_resp[n] != dataval_back[n])
                                        {
                                            err = true;
                                            switch (OwnerP.Lang)
                                            {
                                                case "CN":
                                                    OwnerP.ChangeInfo(0, 0, "数据不一样 : No." + n, System.Drawing.Color.Red);
                                                    break;
                                                case "JP":
                                                    OwnerP.ChangeInfo(0, 0, "データ不一致 : No." + n, System.Drawing.Color.Red);
                                                    break;
                                            }
                                            break;  //forを抜ける
                                        }
                                    }
                                    if (err == true) { break; }
                                }
                            }
                            else
                            {
                                err = true;
                                OwnerP.GetErrorByConditionRead();
                                break;
                            }
                        }
                    }
                    else
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;
                    }
                }

                if (err == false)
                {
                    //ＲＡＳ開始コマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASstart);                  //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);             //送信
                    if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                    {
                        err = true;
                        OwnerP.GetErrorByConditionRead();
                        break;
                    }

                    //ここからは（タイムアウト以外の）エラー時にＲＡＳ終了コマンドを送信するようにする

                    err = CassetteICInit();                     //ＩＣカード初期化コマンド

                    //ここまで（エラー時にＲＡＳ終了コマンド送信）

                    if (recv != null)           //タイムアウトでなければ（何らかの応答があるならば）コマンド送信
                    {
                        //ＲＡＳ終了コマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASend);                //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);         //送信
                        if (OwnerP.RespCheck(recv, false))      //レスポンスチェック（ENQ待ちなし）
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                            break;
                        }
                    }
                }

                break;
            }
            EndSyori(err);
        }

        bool CassetteICInit()
        {
            bool err = false;

            int len = 1;
            byte[] dt = new byte[len];                  //データ部仮配列

            //ＩＣカード初期化コマンド
            dt[0] = 0x30;                               //D0・ＲＷ番号（０：基板）
            byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASICinit, len, dt);        //コマンド,データ長,データ部配列
            byte[] recv = OwnerP.Send(data, 1500);      //送信
            if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
            {
                err = true;
                OwnerP.GetErrorByRASsense();
            }
            if (err == false)
            {
                do
                {
                    //ＲＡＳセンスコマンド
                    data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);  //コマンド（データ長０のもの）
                    recv = OwnerP.Send(data, 1500);     //送信
                    ReceiveData = OwnerP.RecvCheckAndGetData(recv);             //recvからデータだけ取り出す
                    if (ReceiveData == null)
                    {
                        err = true;
                        OwnerP.GetErrorByRASsense();
                    }
                } while (ReceiveData[1] == 1);
            }

            if (err == false)
            {
                //ＩＣカード初期化コマンド
                dt[0] = 0x31;                               //D0・ＲＷ番号（１：カセット１）
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASICinit, len, dt);        //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);             //送信
                if (OwnerP.RespCheck(recv, false))          //レスポンスチェック（ENQ待ちなし）
                {
                    err = true;
                    OwnerP.GetErrorByRASsense();
                }
                if (err == false)
                {
                    do
                    {
                        //ＲＡＳセンスコマンド
                        data = OwnerP.MakeSendData((byte)SQMain.CmdCode.RASsense);  //コマンド（データ長０のもの）
                        recv = OwnerP.Send(data, 1500);     //送信
                        ReceiveData = OwnerP.RecvCheckAndGetData(recv);             //recvからデータだけ取り出す
                        if (ReceiveData == null)
                        {
                            err = true;
                            OwnerP.GetErrorByRASsense();
                        }
                    } while (ReceiveData[1] == 1);
                }
            }

            return err;
        }

        bool CassetteICRead()
        {
            bool err = false;
            byte[] dt = new byte[4];
            int len = 2;
            dt[0] = 0x30;                               //D0・カセットNo.
            dt[1] = 0x31;                               //D1・カセットNo.（１～３）

            //カセットＩＣ情報読取コマンド
            byte[] data = OwnerP.MakeSendData((byte)SQMain.CmdCode.ICInfoRead, len, dt);        //コマンド,データ長,データ部配列
            byte[] recv = OwnerP.Send(data, 1500);      //送信
            err = OwnerP.RespCheck(recv, true);         //レスポンスチェック（ENQ待ちあり）

            if (err == false)
            {
                len = 4;
                dt[0] = 0x30;                           //D0・カセットNo.
                dt[1] = 0x31;                           //D1・カセットNo.（１～３）
                dt[2] = 0x30;                           //D2・セクタNo.
                dt[3] = 0x35;                           //D3・セクタNo.（０～１５）
                //カセットＩＣ情報取得コマンド
                data = OwnerP.MakeSendData((byte)SQMain.CmdCode.ICInfoSend, len, dt);           //コマンド,データ長,データ部配列
                recv = OwnerP.Send(data, 1500);         //送信
                byte[] ReceiveData = OwnerP.RecvCheckAndGetData(recv);                          //recvからデータだけ取り出す

                if ((ReceiveData != null) && (ReceiveData[0] == (byte)ReadResult.NORMAL_END))
                {
                    //設定値を取得
                    for (int i = 0; i < datanum; i++)
                    {
                        dataval_resp[i] = ReceiveData[i + 2];
                    }
                }
                else
                {
                    err = true;
                    OwnerP.GetErrorByConditionRead();
                }
            }
            else
            {
                err = true;
                OwnerP.GetErrorByConditionRead();
            }
            return err;
        }
        //**************************
        private void EndSyori(bool error)
        {
            switch (ThreadNo)
            {
                case 1:
                    OwnerP.ThreadStatus1 = (error ? -1 : 0);
	                OwnerP.MainThread1 = null;
                	break;//0=完了 -1=エラー
                case 2:
                    OwnerP.ThreadStatus2 = (error ? -1 : 0);
	                OwnerP.MainThread2 = null;
	                break;//0=完了 -1=エラー
                case 3:
                    OwnerP.ThreadStatus3 = (error ? -1 : 0); 
	                OwnerP.MainThread3 = null;
	                break;//0=完了 -1=エラー
            }
        }
    }
}
