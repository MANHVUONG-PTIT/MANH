﻿namespace Simulator
{
    partial class AgingMain
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.StartBtn = new System.Windows.Forms.Button();
            this.DebugCheckBox = new System.Windows.Forms.CheckBox();
            this.StopBtn = new System.Windows.Forms.Button();
            this.ResetBtn = new System.Windows.Forms.Button();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.InfomationLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.KinsyuInfoGrid = new System.Windows.Forms.DataGridView();
            this.InfomationTextBox = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Info2_1_1 = new System.Windows.Forms.Label();
            this.Info2_2_4 = new System.Windows.Forms.Label();
            this.Info2_2_5 = new System.Windows.Forms.Label();
            this.Info2_2_3 = new System.Windows.Forms.Label();
            this.Info2_3_8 = new System.Windows.Forms.Label();
            this.Info2_2_6 = new System.Windows.Forms.Label();
            this.Info2_3_7 = new System.Windows.Forms.Label();
            this.Info2_2_2 = new System.Windows.Forms.Label();
            this.Info2_2_1 = new System.Windows.Forms.Label();
            this.Info2_2_8 = new System.Windows.Forms.Label();
            this.Info2_1_6 = new System.Windows.Forms.Label();
            this.Info2_3_6 = new System.Windows.Forms.Label();
            this.Info2_1_5 = new System.Windows.Forms.Label();
            this.Info2_2_7 = new System.Windows.Forms.Label();
            this.Info2_3_1 = new System.Windows.Forms.Label();
            this.Info2_1_8 = new System.Windows.Forms.Label();
            this.Info2_1_4 = new System.Windows.Forms.Label();
            this.Info2_3_5 = new System.Windows.Forms.Label();
            this.Info2_3_2 = new System.Windows.Forms.Label();
            this.Info2_1_7 = new System.Windows.Forms.Label();
            this.Info2_1_3 = new System.Windows.Forms.Label();
            this.Info2_3_3 = new System.Windows.Forms.Label();
            this.Info2_3_4 = new System.Windows.Forms.Label();
            this.Info2_1_2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Info1_1 = new System.Windows.Forms.Label();
            this.Info1_3 = new System.Windows.Forms.Label();
            this.Info1_2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KinsyuInfoGrid)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // StartBtn
            // 
            this.StartBtn.Location = new System.Drawing.Point(3, 3);
            this.StartBtn.Name = "StartBtn";
            this.StartBtn.Size = new System.Drawing.Size(128, 27);
            this.StartBtn.TabIndex = 4;
            this.StartBtn.Text = "Start [F1]";
            this.StartBtn.UseVisualStyleBackColor = true;
            this.StartBtn.Click += new System.EventHandler(this.StartBtn_Click);
            // 
            // DebugCheckBox
            // 
            this.DebugCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DebugCheckBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.DebugCheckBox.Location = new System.Drawing.Point(6, 42);
            this.DebugCheckBox.Name = "DebugCheckBox";
            this.DebugCheckBox.Size = new System.Drawing.Size(179, 19);
            this.DebugCheckBox.TabIndex = 10;
            this.DebugCheckBox.Text = "more information";
            this.DebugCheckBox.UseVisualStyleBackColor = true;
            this.DebugCheckBox.CheckedChanged += new System.EventHandler(this.DebugCheckBox_CheckedChanged);
            // 
            // StopBtn
            // 
            this.StopBtn.Location = new System.Drawing.Point(25, 3);
            this.StopBtn.Name = "StopBtn";
            this.StopBtn.Size = new System.Drawing.Size(128, 27);
            this.StopBtn.TabIndex = 10;
            this.StopBtn.Text = "Stop [F2]";
            this.StopBtn.UseVisualStyleBackColor = true;
            this.StopBtn.Click += new System.EventHandler(this.StopBtn_Click);
            // 
            // ResetBtn
            // 
            this.ResetBtn.Location = new System.Drawing.Point(64, 3);
            this.ResetBtn.Name = "ResetBtn";
            this.ResetBtn.Size = new System.Drawing.Size(128, 27);
            this.ResetBtn.TabIndex = 11;
            this.ResetBtn.Text = "Reset [F3]";
            this.ResetBtn.UseVisualStyleBackColor = true;
            this.ResetBtn.Click += new System.EventHandler(this.ResetBtn_Click);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.label4);
            this.splitContainer2.Panel1.Controls.Add(this.label3);
            this.splitContainer2.Panel1.Controls.Add(this.label2);
            this.splitContainer2.Panel1.Controls.Add(this.label1);
            this.splitContainer2.Panel1.Controls.Add(this.ResetBtn);
            this.splitContainer2.Panel1.Controls.Add(this.DebugCheckBox);
            this.splitContainer2.Panel1.Controls.Add(this.StopBtn);
            this.splitContainer2.Panel1.Controls.Add(this.StartBtn);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.button3);
            this.splitContainer2.Panel2.Controls.Add(this.button2);
            this.splitContainer2.Panel2.Controls.Add(this.InfomationLabel);
            this.splitContainer2.Panel2.Controls.Add(this.button1);
            this.splitContainer2.Panel2.Controls.Add(this.panel3);
            this.splitContainer2.Panel2.Controls.Add(this.panel2);
            this.splitContainer2.Panel2.Controls.Add(this.panel1);
            this.splitContainer2.Size = new System.Drawing.Size(537, 341);
            this.splitContainer2.SplitterDistance = 66;
            this.splitContainer2.SplitterWidth = 1;
            this.splitContainer2.TabIndex = 19;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(381, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(144, 17);
            this.label2.TabIndex = 19;
            this.label2.Text = "Address=0";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("ＭＳ ゴシック", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(143, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 38);
            this.label1.TabIndex = 17;
            this.label1.Text = "XXXXX/YYYYY";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.button3.Location = new System.Drawing.Point(240, 1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(48, 21);
            this.button3.TabIndex = 50;
            this.button3.Text = "Comm";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.button2.Location = new System.Drawing.Point(294, 1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(111, 21);
            this.button2.TabIndex = 49;
            this.button2.Text = "Forced outage";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // InfomationLabel
            // 
            this.InfomationLabel.Location = new System.Drawing.Point(3, 4);
            this.InfomationLabel.Name = "InfomationLabel";
            this.InfomationLabel.Size = new System.Drawing.Size(268, 16);
            this.InfomationLabel.TabIndex = 16;
            this.InfomationLabel.Text = "Information";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.button1.Location = new System.Drawing.Point(411, 1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 21);
            this.button1.TabIndex = 18;
            this.button1.Text = "Address reset";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.KinsyuInfoGrid);
            this.panel3.Controls.Add(this.InfomationTextBox);
            this.panel3.Location = new System.Drawing.Point(23, 161);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(500, 110);
            this.panel3.TabIndex = 48;
            // 
            // KinsyuInfoGrid
            // 
            this.KinsyuInfoGrid.AllowUserToAddRows = false;
            this.KinsyuInfoGrid.AllowUserToDeleteRows = false;
            this.KinsyuInfoGrid.AllowUserToResizeRows = false;
            this.KinsyuInfoGrid.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.KinsyuInfoGrid.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.Disable;
            this.KinsyuInfoGrid.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.KinsyuInfoGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.KinsyuInfoGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.KinsyuInfoGrid.Enabled = false;
            this.KinsyuInfoGrid.GridColor = System.Drawing.Color.Black;
            this.KinsyuInfoGrid.Location = new System.Drawing.Point(2, 2);
            this.KinsyuInfoGrid.MultiSelect = false;
            this.KinsyuInfoGrid.Name = "KinsyuInfoGrid";
            this.KinsyuInfoGrid.ReadOnly = true;
            this.KinsyuInfoGrid.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.KinsyuInfoGrid.RowHeadersVisible = false;
            this.KinsyuInfoGrid.RowTemplate.Height = 21;
            this.KinsyuInfoGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.KinsyuInfoGrid.Size = new System.Drawing.Size(308, 105);
            this.KinsyuInfoGrid.TabIndex = 17;
            // 
            // InfomationTextBox
            // 
            this.InfomationTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InfomationTextBox.BackColor = System.Drawing.Color.White;
            this.InfomationTextBox.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.InfomationTextBox.Location = new System.Drawing.Point(311, 0);
            this.InfomationTextBox.Multiline = true;
            this.InfomationTextBox.Name = "InfomationTextBox";
            this.InfomationTextBox.ReadOnly = true;
            this.InfomationTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.InfomationTextBox.Size = new System.Drawing.Size(186, 110);
            this.InfomationTextBox.TabIndex = 45;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.Info2_1_1);
            this.panel2.Controls.Add(this.Info2_2_4);
            this.panel2.Controls.Add(this.Info2_2_5);
            this.panel2.Controls.Add(this.Info2_2_3);
            this.panel2.Controls.Add(this.Info2_3_8);
            this.panel2.Controls.Add(this.Info2_2_6);
            this.panel2.Controls.Add(this.Info2_3_7);
            this.panel2.Controls.Add(this.Info2_2_2);
            this.panel2.Controls.Add(this.Info2_2_1);
            this.panel2.Controls.Add(this.Info2_2_8);
            this.panel2.Controls.Add(this.Info2_1_6);
            this.panel2.Controls.Add(this.Info2_3_6);
            this.panel2.Controls.Add(this.Info2_1_5);
            this.panel2.Controls.Add(this.Info2_2_7);
            this.panel2.Controls.Add(this.Info2_3_1);
            this.panel2.Controls.Add(this.Info2_1_8);
            this.panel2.Controls.Add(this.Info2_1_4);
            this.panel2.Controls.Add(this.Info2_3_5);
            this.panel2.Controls.Add(this.Info2_3_2);
            this.panel2.Controls.Add(this.Info2_1_7);
            this.panel2.Controls.Add(this.Info2_1_3);
            this.panel2.Controls.Add(this.Info2_3_3);
            this.panel2.Controls.Add(this.Info2_3_4);
            this.panel2.Controls.Add(this.Info2_1_2);
            this.panel2.Location = new System.Drawing.Point(24, 92);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(499, 69);
            this.panel2.TabIndex = 47;
            // 
            // Info2_1_1
            // 
            this.Info2_1_1.BackColor = System.Drawing.Color.White;
            this.Info2_1_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_1.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_1.Location = new System.Drawing.Point(1, 1);
            this.Info2_1_1.Name = "Info2_1_1";
            this.Info2_1_1.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_1.TabIndex = 20;
            this.Info2_1_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_4
            // 
            this.Info2_2_4.BackColor = System.Drawing.Color.White;
            this.Info2_2_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_4.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_4.Location = new System.Drawing.Point(187, 23);
            this.Info2_2_4.Name = "Info2_2_4";
            this.Info2_2_4.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_4.TabIndex = 31;
            this.Info2_2_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_5
            // 
            this.Info2_2_5.BackColor = System.Drawing.Color.White;
            this.Info2_2_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_5.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_5.Location = new System.Drawing.Point(249, 23);
            this.Info2_2_5.Name = "Info2_2_5";
            this.Info2_2_5.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_5.TabIndex = 32;
            this.Info2_2_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_3
            // 
            this.Info2_2_3.BackColor = System.Drawing.Color.White;
            this.Info2_2_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_3.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_3.Location = new System.Drawing.Point(125, 23);
            this.Info2_2_3.Name = "Info2_2_3";
            this.Info2_2_3.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_3.TabIndex = 30;
            this.Info2_2_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_8
            // 
            this.Info2_3_8.BackColor = System.Drawing.Color.White;
            this.Info2_3_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_8.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_8.Location = new System.Drawing.Point(435, 45);
            this.Info2_3_8.Name = "Info2_3_8";
            this.Info2_3_8.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_8.TabIndex = 44;
            this.Info2_3_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_6
            // 
            this.Info2_2_6.BackColor = System.Drawing.Color.White;
            this.Info2_2_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_6.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_6.Location = new System.Drawing.Point(311, 23);
            this.Info2_2_6.Name = "Info2_2_6";
            this.Info2_2_6.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_6.TabIndex = 33;
            this.Info2_2_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_7
            // 
            this.Info2_3_7.BackColor = System.Drawing.Color.White;
            this.Info2_3_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_7.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_7.Location = new System.Drawing.Point(373, 45);
            this.Info2_3_7.Name = "Info2_3_7";
            this.Info2_3_7.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_7.TabIndex = 43;
            this.Info2_3_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_2
            // 
            this.Info2_2_2.BackColor = System.Drawing.Color.White;
            this.Info2_2_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_2.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_2.Location = new System.Drawing.Point(63, 23);
            this.Info2_2_2.Name = "Info2_2_2";
            this.Info2_2_2.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_2.TabIndex = 29;
            this.Info2_2_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_1
            // 
            this.Info2_2_1.BackColor = System.Drawing.Color.White;
            this.Info2_2_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_1.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_1.Location = new System.Drawing.Point(1, 23);
            this.Info2_2_1.Name = "Info2_2_1";
            this.Info2_2_1.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_1.TabIndex = 28;
            this.Info2_2_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_8
            // 
            this.Info2_2_8.BackColor = System.Drawing.Color.White;
            this.Info2_2_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_8.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_8.Location = new System.Drawing.Point(435, 23);
            this.Info2_2_8.Name = "Info2_2_8";
            this.Info2_2_8.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_8.TabIndex = 35;
            this.Info2_2_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_6
            // 
            this.Info2_1_6.BackColor = System.Drawing.Color.White;
            this.Info2_1_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_6.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_6.Location = new System.Drawing.Point(311, 1);
            this.Info2_1_6.Name = "Info2_1_6";
            this.Info2_1_6.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_6.TabIndex = 25;
            this.Info2_1_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_6
            // 
            this.Info2_3_6.BackColor = System.Drawing.Color.White;
            this.Info2_3_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_6.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_6.Location = new System.Drawing.Point(311, 45);
            this.Info2_3_6.Name = "Info2_3_6";
            this.Info2_3_6.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_6.TabIndex = 42;
            this.Info2_3_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_5
            // 
            this.Info2_1_5.BackColor = System.Drawing.Color.White;
            this.Info2_1_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_5.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_5.Location = new System.Drawing.Point(249, 1);
            this.Info2_1_5.Name = "Info2_1_5";
            this.Info2_1_5.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_5.TabIndex = 24;
            this.Info2_1_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_2_7
            // 
            this.Info2_2_7.BackColor = System.Drawing.Color.White;
            this.Info2_2_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_2_7.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_2_7.Location = new System.Drawing.Point(373, 23);
            this.Info2_2_7.Name = "Info2_2_7";
            this.Info2_2_7.Size = new System.Drawing.Size(61, 21);
            this.Info2_2_7.TabIndex = 34;
            this.Info2_2_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_1
            // 
            this.Info2_3_1.BackColor = System.Drawing.Color.White;
            this.Info2_3_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_1.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_1.Location = new System.Drawing.Point(1, 45);
            this.Info2_3_1.Name = "Info2_3_1";
            this.Info2_3_1.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_1.TabIndex = 37;
            this.Info2_3_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_8
            // 
            this.Info2_1_8.BackColor = System.Drawing.Color.White;
            this.Info2_1_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_8.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_8.Location = new System.Drawing.Point(435, 1);
            this.Info2_1_8.Name = "Info2_1_8";
            this.Info2_1_8.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_8.TabIndex = 27;
            this.Info2_1_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_4
            // 
            this.Info2_1_4.BackColor = System.Drawing.Color.White;
            this.Info2_1_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_4.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_4.Location = new System.Drawing.Point(187, 1);
            this.Info2_1_4.Name = "Info2_1_4";
            this.Info2_1_4.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_4.TabIndex = 23;
            this.Info2_1_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_5
            // 
            this.Info2_3_5.BackColor = System.Drawing.Color.White;
            this.Info2_3_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_5.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_5.Location = new System.Drawing.Point(249, 45);
            this.Info2_3_5.Name = "Info2_3_5";
            this.Info2_3_5.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_5.TabIndex = 41;
            this.Info2_3_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_2
            // 
            this.Info2_3_2.BackColor = System.Drawing.Color.White;
            this.Info2_3_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_2.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_2.Location = new System.Drawing.Point(63, 45);
            this.Info2_3_2.Name = "Info2_3_2";
            this.Info2_3_2.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_2.TabIndex = 38;
            this.Info2_3_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_7
            // 
            this.Info2_1_7.BackColor = System.Drawing.Color.White;
            this.Info2_1_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_7.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_7.Location = new System.Drawing.Point(373, 1);
            this.Info2_1_7.Name = "Info2_1_7";
            this.Info2_1_7.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_7.TabIndex = 26;
            this.Info2_1_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_3
            // 
            this.Info2_1_3.BackColor = System.Drawing.Color.White;
            this.Info2_1_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_3.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_3.Location = new System.Drawing.Point(125, 1);
            this.Info2_1_3.Name = "Info2_1_3";
            this.Info2_1_3.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_3.TabIndex = 22;
            this.Info2_1_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_3
            // 
            this.Info2_3_3.BackColor = System.Drawing.Color.White;
            this.Info2_3_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_3.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_3.Location = new System.Drawing.Point(125, 45);
            this.Info2_3_3.Name = "Info2_3_3";
            this.Info2_3_3.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_3.TabIndex = 39;
            this.Info2_3_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_3_4
            // 
            this.Info2_3_4.BackColor = System.Drawing.Color.White;
            this.Info2_3_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_3_4.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_3_4.Location = new System.Drawing.Point(187, 45);
            this.Info2_3_4.Name = "Info2_3_4";
            this.Info2_3_4.Size = new System.Drawing.Size(61, 21);
            this.Info2_3_4.TabIndex = 40;
            this.Info2_3_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info2_1_2
            // 
            this.Info2_1_2.BackColor = System.Drawing.Color.White;
            this.Info2_1_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info2_1_2.Font = new System.Drawing.Font("ＭＳ ゴシック", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Info2_1_2.Location = new System.Drawing.Point(63, 1);
            this.Info2_1_2.Name = "Info2_1_2";
            this.Info2_1_2.Size = new System.Drawing.Size(61, 21);
            this.Info2_1_2.TabIndex = 21;
            this.Info2_1_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.Info1_1);
            this.panel1.Controls.Add(this.Info1_3);
            this.panel1.Controls.Add(this.Info1_2);
            this.panel1.Location = new System.Drawing.Point(24, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(499, 68);
            this.panel1.TabIndex = 46;
            // 
            // Info1_1
            // 
            this.Info1_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Info1_1.BackColor = System.Drawing.Color.White;
            this.Info1_1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info1_1.Location = new System.Drawing.Point(1, 1);
            this.Info1_1.Name = "Info1_1";
            this.Info1_1.Size = new System.Drawing.Size(496, 21);
            this.Info1_1.TabIndex = 18;
            this.Info1_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info1_3
            // 
            this.Info1_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Info1_3.BackColor = System.Drawing.Color.White;
            this.Info1_3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info1_3.Location = new System.Drawing.Point(1, 45);
            this.Info1_3.Name = "Info1_3";
            this.Info1_3.Size = new System.Drawing.Size(496, 21);
            this.Info1_3.TabIndex = 36;
            this.Info1_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Info1_2
            // 
            this.Info1_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Info1_2.BackColor = System.Drawing.Color.White;
            this.Info1_2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Info1_2.Location = new System.Drawing.Point(1, 23);
            this.Info1_2.Name = "Info1_2";
            this.Info1_2.Size = new System.Drawing.Size(496, 21);
            this.Info1_2.TabIndex = 19;
            this.Info1_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("ＭＳ ゴシック", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(154, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 24);
            this.label3.TabIndex = 20;
            this.label3.Text = "Aging2:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("ＭＳ ゴシック", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.Location = new System.Drawing.Point(256, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 24);
            this.label4.TabIndex = 21;
            this.label4.Text = "XXXX/YYYY";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AgingMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.LightYellow;
            this.ClientSize = new System.Drawing.Size(537, 341);
            this.ControlBox = false;
            this.Controls.Add(this.splitContainer2);
            this.Font = new System.Drawing.Font("ＭＳ ゴシック", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AgingMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "ProductName  CheckerName";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KinsyuInfoGrid)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button StartBtn;
        private System.Windows.Forms.CheckBox DebugCheckBox;
        private System.Windows.Forms.Button StopBtn;
        private System.Windows.Forms.Button ResetBtn;
        private System.Windows.Forms.DataGridView KinsyuInfoGrid;
        private System.Windows.Forms.Label Info2_1_7;
        private System.Windows.Forms.Label Info2_1_6;
        private System.Windows.Forms.Label Info2_1_5;
        private System.Windows.Forms.Label Info2_1_4;
        private System.Windows.Forms.Label Info2_1_3;
        private System.Windows.Forms.Label Info2_1_2;
        private System.Windows.Forms.Label Info2_1_1;
        private System.Windows.Forms.Label Info1_2;
        private System.Windows.Forms.Label Info1_1;
        private System.Windows.Forms.TextBox InfomationTextBox;
        private System.Windows.Forms.Label Info2_3_8;
        private System.Windows.Forms.Label Info2_3_7;
        private System.Windows.Forms.Label Info2_3_6;
        private System.Windows.Forms.Label Info2_3_5;
        private System.Windows.Forms.Label Info2_3_4;
        private System.Windows.Forms.Label Info2_3_3;
        private System.Windows.Forms.Label Info2_3_2;
        private System.Windows.Forms.Label Info2_3_1;
        private System.Windows.Forms.Label Info1_3;
        private System.Windows.Forms.Label Info2_2_8;
        private System.Windows.Forms.Label Info2_2_7;
        private System.Windows.Forms.Label Info2_2_6;
        private System.Windows.Forms.Label Info2_2_5;
        private System.Windows.Forms.Label Info2_2_4;
        private System.Windows.Forms.Label Info2_2_3;
        private System.Windows.Forms.Label Info2_2_2;
        private System.Windows.Forms.Label Info2_2_1;
        private System.Windows.Forms.Label Info2_1_8;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label InfomationLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}

