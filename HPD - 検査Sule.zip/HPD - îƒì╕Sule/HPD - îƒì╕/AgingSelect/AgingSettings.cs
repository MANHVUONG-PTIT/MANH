﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Simulator
{
    public partial class AgingSettings : Form
    {
        public AgingSettings()
        {
            InitializeComponent();
        }

        //フォームロード
        private void Settings_Load(object sender, EventArgs e)
        {
            //debug******初期のファイルを作成するとき*************
            //SgNet.COM.Form_s.SaveString(Application.StartupPath + "\\FormString.ini", this);
            //****************************************************

            //画面のフォント・文字変更
            SgNet.COM.Form_s.LoadString(Application.StartupPath + "\\FormStringJ.ini", this);
            
            SgNet.COM.File_s.IniFile_s iniP = new SgNet.COM.File_s.IniFile_s(SgNet.COM.Dir_s.Path_s.StartupPath() + "\\Settings.ini");

            textBox1.Text = iniP.ReadString("Aging", "Count", "0");
            int count  = iniP.ReadInt("Aging", "ConnectionCount", 1);
            textBox2.Text = count.ToString();
            textBox3.Text = iniP.ReadString("Aging", "Aging2Count", "500");
            textBox4.Text = iniP.ReadString("Aging", "Aging2Interval", "1");

            String ss = "";
            for (int i = 0; i < count; i++)
            {
                ss = iniP.ReadString("Aging", "Address" + i.ToString(), i.ToString());
                listBox1.Items[i] = i.ToString() + "=" + ss;
            }

            checkBox1.Checked = (iniP.ReadInt("Settings", "GloryDLL", 0) == 0 ? false : true);
            checkBox5.Checked = (iniP.ReadInt("Aging", "AddressChange", 0) == 0 ? false : true); 

            checkBox2.Checked = (iniP.ReadInt("Settings", "Infomation_BigPanel", 0) == 0 ? false : true);
            checkBox3.Checked = (iniP.ReadInt("Settings", "Infomation_LittlePanel", 0) == 0 ? false : true);
            checkBox4.Checked = (iniP.ReadInt("Settings", "Infomation_MaisuPanel", 0) == 0 ? false : true);

            checkBox5_CheckedChanged(null, null);
        }

        //保存
        private void button5_Click(object sender, EventArgs e)
        {
            //Save
            SgNet.COM.File_s.IniFile_s iniP2 = new SgNet.COM.File_s.IniFile_s(SgNet.COM.Dir_s.Path_s.StartupPath() + "\\Settings.ini");

            iniP2.WriteString("Aging", "Count", textBox1.Text);
            iniP2.WriteString("Aging", "ConnectionCount", textBox2.Text);
            iniP2.WriteString("Aging", "Aging2Count", textBox3.Text);
            iniP2.WriteString("Aging", "Aging2Interval", textBox4.Text);
            String[] sp = null;
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                sp = SgNet.COM.String_s.Sprit(listBox1.Items[i].ToString(), "=");
                if (sp[1] != "")
                {
                    iniP2.WriteString("Aging", "Address" + i.ToString(), sp[1]);
                }
            }
            iniP2.WriteInt("Aging", "AddressChange", (checkBox5.Checked ? 1 : 0));
            iniP2.WriteInt("Settings", "GloryDLL", (checkBox1.Checked ? 1 : 0));

            iniP2.WriteInt("Settings", "Infomation_BigPanel", (checkBox2.Checked ? 1 : 0));
            iniP2.WriteInt("Settings", "Infomation_LittlePanel", (checkBox3.Checked ? 1 : 0));
            iniP2.WriteInt("Settings", "Infomation_MaisuPanel", (checkBox4.Checked ? 1 : 0));
 
            iniP2.Save();

            SgNet.COM.MessageBox_s.ShowInfomation(Application.StartupPath + "\\MsgString.ini", "Msg", "1", "Complete");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            int count = 0;
            int.TryParse(textBox2.Text, out count);

            //削除
            for (int a = listBox1.Items.Count - 1; a >= 0; a--)
            {
                if (listBox1.Items.Count <= count) break;
                listBox1.Items.RemoveAt(listBox1.Items.Count - 1);
            }
            //追加
            for (int a = listBox1.Items.Count; a < count; a++)
            {
                listBox1.Items.Add(a.ToString() + "=" + a.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sel = listBox1.SelectedIndex;
            if (sel == -1) return;
            String ss = listBox1.Items[sel].ToString();
            String[] sp = SgNet.COM.String_s.Sprit(ss, "=");
            bool okFlg = false;
            ss = SgNet.COM.Form_s.InputForm(sp[1], "Please input connection address", "Address", false, out okFlg);
            if (okFlg) listBox1.Items[sel] = sp[0] + "=" + ss;
        }
        //Reset
        private void button2_Click(object sender, EventArgs e)
        {
            EditCmd("Reset");
        }
        //Aging
        private void button3_Click(object sender, EventArgs e)
        {
            EditCmd("Aging");
        }
        //ChangeAddress
        private void button4_Click(object sender, EventArgs e)
        {
            EditCmd("ChangeAddress");
        }
        private void EditCmd(String fileName)
        {
            String path = Application.StartupPath + "\\Command";
            SgNet.COM.Dir_s.Create(path);
            path += "\\" + fileName + ".xml";
            if (SgNet.COM.File_s.Exists(path))
            {
                //ダブってなければ、コマンドクラスをnewして、起動する
                Cmd cmd = CmdCommon.ReadCmdXML(Application.StartupPath + "\\Command\\" + fileName + ".xml");

                //変更フォームを起動
                CmdSettingForm dlgP = new CmdSettingForm(cmd, 0, checkBox1.Checked);
                if (dlgP.ShowDialog() == DialogResult.Cancel)
                {
                    return;
                }

                //ファイルの保存
                bool ret = CmdCommon.WriteCmdXML(Application.StartupPath + "\\Command\\" + fileName + ".xml", dlgP.SettingCmd);
                if (ret == false)
                {
                    SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + "\\MsgString.ini", "Msg", "2", "False!");
                    return;
                }
            }
            else
            {
                //コマンドクラスをnewして、起動する
                Cmd cmd = new Cmd();
                cmd.FileName = fileName;
                cmd.SequenceName = fileName;

                //変更フォームを起動
                CmdSettingForm dlgP = new CmdSettingForm(cmd, 0, checkBox1.Checked);
                if (dlgP.ShowDialog() == DialogResult.Cancel)
                {
                    return;
                }
                //ファイルの保存
                bool ret = CmdCommon.WriteCmdXML(Application.StartupPath + "\\Command\\" + fileName + ".xml", dlgP.SettingCmd);
                if (ret == false)
                {
                    SgNet.COM.MessageBox_s.ShowError(Application.StartupPath + "\\MsgString.ini", "Msg", "2", "False!");
                    return;
                }
            }
        }
        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked) button4.Visible = true;
            else button4.Visible = false;
        }
    }
}
